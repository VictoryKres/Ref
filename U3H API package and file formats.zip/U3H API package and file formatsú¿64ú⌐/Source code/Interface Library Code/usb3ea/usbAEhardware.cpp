#include <stdio.h>
#include "usbAEhardware.h"
//#include "UsbaeHardware18Bit.h"
#include "UsbaeHardware16BitNew.h"

//#ifdef SINGLE_POINT_BUS_INTERFACE
#ifdef _DEBUG
__declspec(dllexport) void _stdcall WriteMainboardRegister(short ChassisId,UCHAR addr, UINT value);
__declspec(dllexport) void _stdcall ReadMainboardRegister(short ChassisId, UCHAR addr, UINT *value);
#else
void WriteMainboardRegister(short ChassisId,UCHAR addr, UINT value);
void ReadMainboardRegister(short ChassisId, UCHAR addr, UINT *value);
#endif // _DEBUG

//#endif
//#define SPEED_STATISTICS_DEBUG  //�ٶȲ���

//#define STREAMING_DEBUG //�����ɼ�����
#ifdef STREAMING_DEBUG
    DWORD SampleCycle, SampleLength;
#endif

//#define REGISTER_DEBUG  //�Ĵ���ֵ����
//#define DEBUG_FILE		//ԭʼ�ɼ����ݴ����ļ�

DWORD  WINAPI InterruptAttachThreadLocalInt( LPVOID pParam );
BOOL SetCardNumberNo(unsigned short index, UCHAR CardNO);

//ȡ����ֵx��������1�ĸ���
//##ModelId=4C22CB3B01A5
unsigned long GetOneCount(unsigned long x)
{
    x = (x & 0x55555555UL) + ((x >> 1) & 0x55555555UL);
    x = (x & 0x33333333UL) + ((x >> 2) & 0x33333333UL);
    x = (x & 0x0f0f0f0fUL) + ((x >> 4) & 0x0f0f0f0fUL);
    x = (x & 0x00ff00ffUL) + ((x >> 8) & 0x00ff00ffUL);
    x = (x & 0x0000ffffUL) + ((x >> 16) & 0x0000ffffUL);
    return x;
}

//##ModelId=4C22CB3B00EB
usbAEhardware::usbAEhardware()
{
	rawBuf = new char[MAX_RAWDATA_BUF_LENGTH];
    fftBuf = new char[MAX_FFTDATA_BUF_LENGTH];

	memset(&hEventArray, 0, sizeof(hEventArray));
	SampleLen = 1024;

	dataMutex[0]=CreateMutex(NULL, FALSE, "rawmutex");
	dataMutex[1]=CreateMutex(NULL, FALSE, "fftmutex");
	dataMutex[2]=CreateMutex(NULL, FALSE, "paramutex");

	bOpenCardStatus = FALSE;
    bQueryCardStatus = FALSE;

	usbGain = 0;
	usbChNum = 4; 

	FirFilterOrder = FIR_ORDER;

	memset(mb_ver, 0, sizeof(mb_ver));
	memset(card_ver, 0, sizeof(card_ver));

	//memset(tempChannelParaBuf, 0, sizeof(tempChannelParaBuf));
    memset(&m_DriverVersion, 0, sizeof(m_DriverVersion));

    ChSampMode = new DWORD[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD];
    ChPrePostSampLen = new DWORD[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD];
    int i;
    for (i = 0; i < MAX_CARDNUM*CHANNEL_NUMBER_PERCARD; i++)
    {
        ChSampMode[i] = enuNormalSamp;
        ChPrePostSampLen[i] = 0;
    }

    bChEnabled = new BOOL[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 2];
    memset( bChEnabled, 0, sizeof(BOOL) * (MAX_CARDNUM*CHANNEL_NUMBER_PERCARD+2) );
}

//##ModelId=4C22CB3B00FA
usbAEhardware::~usbAEhardware()
{
	int i;
	bQueryCardStatus = FALSE;

	for (i=0;i<3;i++)
	{
		if (dataMutex[i])
		{
			CloseHandle(dataMutex[i]);
			dataMutex[i]=NULL;
		}
	}

	for (i=0;i<MAX_CARDNUM*2;i++)
	{
		if (hEventArray[i])
		{
			CloseHandle(hEventArray[i]);
			hEventArray[i]=NULL;
		}
	}

	for (i=0;i<MAX_CARDNUM*CHANNEL_NUMBER_PERCARD+1;i++)
	{
		chParamFIFO[i].ReleaseBuf();
	}

	if(rawBuf)
		delete []rawBuf;

    if (fftBuf)
    {
        delete []fftBuf;
    }
    if (ChSampMode)
    {
        delete []ChSampMode;
    }
    if (ChPrePostSampLen)
    {
        delete []ChPrePostSampLen;
    }
	if (ThreadHandle)
	{
		CloseHandle(ThreadHandle);
		ThreadHandle = NULL;
	}

    if (bChEnabled)
    {
        delete []bChEnabled;
        bChEnabled = NULL;
    }
}

//##ModelId=4C22CB3B02AF
BOOL usbAEhardware::SetExnTrig(unsigned short CardNo, BOOL bStatus)
{

	return FALSE;
}

/*--------------------
Read Version configration Information
Format:
reg[31:20]   Memory Size for Waveform, unit : 2^(this value) KByte
reg[19:16]   AE Channel Sum every card
reg[15:8]    version Max
reg[7:0]     version Min

---------------------------*/

//##ModelId=4C22CB3B034B
UINT usbAEhardware::GetVersionConf(unsigned short cardNo)
{
	UINT regvalue;
	if(cardNo >= MAX_CARDNUM)
		return FALSE;
    ReadRegister(cardNo,AE_VERSION_CONFIGRATION,&regvalue);
	return regvalue;
}

//sysTimer, Unit : 100ns
// every sysTimer, system will output a timer param
//##ModelId=4C22CB3B032C
BOOL usbAEhardware::EnableSysTimer(unsigned short cardNo, DWORD sysTimer)
{
	int i, j;
#ifdef SINGLE_POINT_BUS_INTERFACE
	//��ǰ����ʽϵͳ�����߰�FPGA������λ�ã�Ĭ�ϰ忨�ǰ��մ�0��(MAX_CARD_NUM_PER_CHASSIS-1)��˳���
	//��������࿪ʼ���ã�����ϣ��������FPGA������ӿ��Ķ�ʱ������˰��մ����ĵ������˳������������
	//���MAX_CARD_NUM_PER_CHASSIS = 10�����ǰ���4,5;3,6;2,7;1,8;0,9��˳����Ұ忨��ѡ������ʵİ忨��������
	//���MAX_CARD_NUM_PER_CHASSIS = 11�����ǰ���5,5;4,6;3,7;2,8;1,9;0,10��˳����Ұ忨��ѡ������ʵİ忨��������

	cardNo = MAX_CARDNUM;
	USHORT tmp_id;

	for(i = 0; i < MAX_CHASSIS; i++){	
		//for (j = 0; j < min(MAX_CARD_NUM_PER_CHASSIS, MAX_CARDNUM - MAX_CARD_NUM_PER_CHASSIS * i); j++)
		for (j = 0; j < (MAX_CARD_NUM_PER_CHASSIS + 1) / 2; j++)
		{
			//��࿨
			tmp_id = (MAX_CARD_NUM_PER_CHASSIS - 1) / 2 - j + (MAX_CARD_NUM_PER_CHASSIS * i);
			if ((tmp_id < MAX_CARDNUM) && bDeviceOpenFlag[tmp_id])
			{
				cardNo = tmp_id;
				break;
			}
			//�Ҳ࿨
			tmp_id = MAX_CARD_NUM_PER_CHASSIS / 2 + j + (MAX_CARD_NUM_PER_CHASSIS * i);
			if ((tmp_id < MAX_CARDNUM) && bDeviceOpenFlag[tmp_id])
			{
				cardNo = tmp_id;
				break;
			}
		}
		if (cardNo < MAX_CARDNUM)
		{
			break;
		}
	}
#else
// 	//����ÿ5�鿨����һ��sysTimer���ã���ͼ����࿨ʱ�������������
// 	int tot_opened_card = 0;
// 
// 	for (i = 0; i < MAX_CARDNUM; i++)
// 	{
// 		if (bDeviceOpenFlag[i])
// 		{
// 			tot_opened_card++;
// 		}
// 	}
// 	if (tot_opened_card > 0)
// 	{
// 		sysTimer *= ((tot_opened_card - 1) / 5 + 1);
// 	}
#endif

     //sysTimer = 0;

	if(cardNo >= MAX_CARDNUM)
		return FALSE;
    if (sysTimer > 0)
    {
        WriteRegister(cardNo,AE_SYSTIMER_SETTING, sysTimer | 0x80000000);
    }
    else
    {
        WriteRegister(cardNo,AE_SYSTIMER_SETTING, 0);
    }
	return TRUE;
}

// dwExparamAttri[3:0] = 0x04 ->ext parameter sample frequency divisor
//                        Frq(ex) = 40M /2(n+1)/16 , here n = dwExparamAttri[7:0]
//exparamAttri[16:27]  = 0xFFFF  ext Parameter 0 - 11  enable/disable bit.
//##ModelId=4C22CB3B030D
BOOL usbAEhardware::SetExparamAttri(unsigned short cardNo, DWORD dwExparamAttri)
{
	if(cardNo >= MAX_CARDNUM)
		return FALSE;
#ifdef FPGA_VERSION_1_3
	UINT regValue;
	short chassis, card;
	chassis = cardNo / MAX_CARD_NUM_PER_CHASSIS;
	card = cardNo % MAX_CARD_NUM_PER_CHASSIS;
	ReadMainboardRegister(chassis, MB_EXPARAM_ATTRIB_REG, &regValue);
	if (dwExparamAttri & 0xff)
	{
		WriteMainboardRegister(chassis, MB_EXPARAM_ATTRIB_REG, EXPARAM_ENABLE | (regValue & 0xffffff00) | dwExparamAttri);
	}
	else	//�ر���βɼ�
	{
		WriteMainboardRegister(chassis, MB_EXPARAM_ATTRIB_REG, (~EXPARAM_ENABLE) & regValue);
	}
#else
#ifdef BGA_18BITS_40M_VERSION
    WriteRegister(cardNo,AE_EXPARAM_ATTRI,dwExparamAttri & (~0x30));
    switch((dwExparamAttri & 0x30) >> 4)
    {
    case 0:
       dwExparamAttri = 4;  //0dB
        break;
    case 1 :
        dwExparamAttri = 1; //-6dB
        break;
    case 2:
        dwExparamAttri = 8; //+6dB
        break;
    case  3:
        dwExparamAttri = 2; //GND
        break;
    default:
        dwExparamAttri = 4;
        break;
	}
    WriteRegister(cardNo, AE_EXPARAM_GAIN_REG, dwExparamAttri);
#else
	WriteRegister(cardNo,AE_EXPARAM_ATTRI,dwExparamAttri);
#endif
    //ReadRegister(cardNo, AE_EXPARAM_ATTRI, (PUINT)&dwExparamAttri);
#endif
	return TRUE;
}

//##ModelId=4C22CB3B031C
BOOL usbAEhardware::SetExparamFixed(unsigned short chanNo, DWORD outInterval)
{
    unsigned short	cardNo;

	cardNo = chanNo/CHANNEL_NUMBER_PERCARD;
	chanNo = chanNo%CHANNEL_NUMBER_PERCARD;
	if(cardNo >= MAX_CARDNUM || chanNo < 0)
		return FALSE;

	WriteRegister(cardNo,AE_EXPARAM_FIXED + chanNo,outInterval);

	return TRUE;
}

// mode :  sample mode
// SAMPLE_MODE_NORMAL    0
// SAMPLE_MODE_PRE       1
// SAMPLE_MODE_POST      2
//##ModelId=4C22CB3B02EE
BOOL usbAEhardware::SetSampleMode(unsigned short chanNo, int mode, int SampleSum )
{
    short	cardNo;
	UINT regValue;

	cardNo = chanNo/CHANNEL_NUMBER_PERCARD;
	chanNo = chanNo%CHANNEL_NUMBER_PERCARD;
	if(cardNo >= MAX_CARDNUM || chanNo < 0)
		return FALSE;
	
	regValue = ((mode & 0x3 ) << 30 ) | (SampleSum & 0x3FFFFFFF);
	WriteRegister(cardNo,AE_SAMPLE_MODE + chanNo,regValue);

    ChSampMode[cardNo * CHANNEL_NUMBER_PERCARD + chanNo] = mode;
    ChPrePostSampLen[cardNo * CHANNEL_NUMBER_PERCARD + chanNo] = SampleSum & 0x0FFFFFFF;

	return TRUE;
}

//##ModelId=4C22CB3B0290
BOOL usbAEhardware::SetFilterGain(unsigned short chanNo, unsigned short filter, unsigned short gain)
{
	short	cardNo;

	cardNo = chanNo/CHANNEL_NUMBER_PERCARD;
	chanNo = chanNo%CHANNEL_NUMBER_PERCARD;
	if(cardNo >= MAX_CARDNUM || chanNo < 0)
		return FALSE;

#ifdef BGA_18BITS_40M_VERSION
    GLB_ANALOG_PROP RegVal;
    CH_ANALOG_CFG_PROP* pChannel;


    if (chanNo == 0)
    {
        pChannel = &RegVal.spec.Ch0;
    }
    else if (chanNo == 1)
    {
        pChannel = &RegVal.spec.Ch1;
    }
    else
    {
        return FALSE;
    }

    ReadRegister(cardNo, CH_CFG_DATA_REG_H, (unsigned int*)&RegVal.cmd.CmdH);
    ReadRegister(cardNo, CH_CFG_DATA_REG_L, (unsigned int*)&RegVal.cmd.CmdL);

    switch (filter)
    {
    case 0:
        pChannel->ChHighPass = enHp20;
        pChannel->ChLowPass = enLp100;
        break;
    case 1:
        pChannel->ChHighPass = enHp20;
        pChannel->ChLowPass = enLp400;
        break;
    case 2:
        pChannel->ChHighPass = enHp20;
        pChannel->ChLowPass = enLp1200;
        break;
    case 3:
        pChannel->ChHighPass = enHp20;
        pChannel->ChLowPass = enLpBypass;
        break;
    case 4:
        pChannel->ChHighPass = enHp100;
        pChannel->ChLowPass = enLp400;
        break;
    case 5:
        pChannel->ChHighPass = enHp100;
        pChannel->ChLowPass = enLp1200;
        break;
    case 6:
        pChannel->ChHighPass = enHp100;
        pChannel->ChLowPass = enLpBypass;
        break;
    case 7:
        pChannel->ChHighPass = enHp400;
        pChannel->ChLowPass = enLp1200;
        break;
    case 8:
        pChannel->ChHighPass = enHp400;
        pChannel->ChLowPass = enLpBypass;
        break;
    default:
        pChannel->ChHighPass = enHpBypass;
        pChannel->ChLowPass = enLpBypass;
        break;
    }

    switch (gain)
    {
    case 0:
        pChannel->ChGain = enGain0;
        break;
    case 1:
        pChannel->ChGain = enGainNeg12;
        break;
    case 2:
        pChannel->ChGain = enGainNeg9;
        break;
    case 3:
        pChannel->ChGain = enGainNeg6;
        break;
    case 4:
        pChannel->ChGain = enGain6;
        break;
    case 5:
        pChannel->ChGain = enGain9;
        break;
    case 6:
        pChannel->ChGain = enGain12;
        break;
    case 7:
        pChannel->ChGain = enGainGnd;
        break;
    }

    WriteRegister(cardNo, CH_CFG_DATA_REG_H, RegVal.cmd.CmdH);
    WriteRegister(cardNo, CH_CFG_DATA_REG_L, RegVal.cmd.CmdL);
    WriteRegister(cardNo, CH_CFG_CTR_REG, 0);
    WriteRegister(cardNo, CH_CFG_CTR_REG, 1);
#else
    UCHAR	bufOutput[33];
    UCHAR  m_ch_l,m_ch_h;

	bufOutput[0] = 1 ;
    
	if(filter < 4) {
		m_ch_l = (UCHAR)filter;
		m_ch_h = 0;
	}else if(filter < 7){
		m_ch_l = filter - 3;
		m_ch_h = 1;	
	}else if(filter < 9){
		m_ch_l = filter - 5;
		m_ch_h = 2;	
	}
	else {
		m_ch_l = 3;
		m_ch_h = 3;		
	}
	   
	bufOutput[1] = m_ch_l +1 ;
	bufOutput[2] = m_ch_h +1 ;
	bufOutput[3] = gain+1 ;

	memcpy(&bufOutput[4], &bufOutput[1], 3);
	bufOutput[7] = chanNo ;							

	USBWriteEP(cardNo,0,8,bufOutput);		
#endif

	return TRUE;
}

BOOL usbAEhardware::SetCardFilterGain(unsigned short CardNo, unsigned short ch0_filter, unsigned short ch0_gain,
                                      unsigned short ch1_filter, unsigned short ch1_gain){
    UCHAR	bufOutput[33];
	short	cardNo = CardNo;
	UCHAR  m_ch_l,m_ch_h;

    unsigned short filter;
	unsigned short gain;

    if(CardNo >= MAX_CARDNUM)
        return FALSE;

#ifdef BGA_18BITS_40M_VERSION
    GLB_ANALOG_PROP RegVal;
    CH_ANALOG_CFG_PROP* pChannel;
	
    ReadRegister(cardNo, CH_CFG_DATA_REG_H, (unsigned int*)&RegVal.cmd.CmdH);
    ReadRegister(cardNo, CH_CFG_DATA_REG_L, (unsigned int*)&RegVal.cmd.CmdL);
	
	pChannel = &RegVal.spec.Ch0;
    switch (ch0_filter)
    {
    case 0:
        pChannel->ChHighPass = enHp20;
        pChannel->ChLowPass = enLp100;
        break;
    case 1:
        pChannel->ChHighPass = enHp20;
        pChannel->ChLowPass = enLp400;
        break;
    case 2:
        pChannel->ChHighPass = enHp20;
        pChannel->ChLowPass = enLp1200;
        break;
    case 3:
        pChannel->ChHighPass = enHp20;
        pChannel->ChLowPass = enLpBypass;
        break;
    case 4:
        pChannel->ChHighPass = enHp100;
        pChannel->ChLowPass = enLp400;
        break;
    case 5:
        pChannel->ChHighPass = enHp100;
        pChannel->ChLowPass = enLp1200;
        break;
    case 6:
        pChannel->ChHighPass = enHp100;
        pChannel->ChLowPass = enLpBypass;
        break;
    case 7:
        pChannel->ChHighPass = enHp400;
        pChannel->ChLowPass = enLp1200;
        break;
    case 8:
        pChannel->ChHighPass = enHp400;
        pChannel->ChLowPass = enLpBypass;
        break;
    default:
        pChannel->ChHighPass = enHpBypass;
        pChannel->ChLowPass = enLpBypass;
        break;
    }
	
    switch (ch0_gain)
    {
    case 0:
        pChannel->ChGain = enGain0;
        break;
    case 1:
        pChannel->ChGain = enGainNeg12;
        break;
    case 2:
        pChannel->ChGain = enGainNeg9;
        break;
    case 3:
        pChannel->ChGain = enGainNeg6;
        break;
    case 4:
        pChannel->ChGain = enGain6;
        break;
    case 5:
        pChannel->ChGain = enGain9;
        break;
    case 6:
        pChannel->ChGain = enGain12;
        break;
    case 7:
        pChannel->ChGain = enGainGnd;
        break;
    }
	
	pChannel = &RegVal.spec.Ch1;
    switch (ch1_filter)
    {
    case 0:
        pChannel->ChHighPass = enHp20;
        pChannel->ChLowPass = enLp100;
        break;
    case 1:
        pChannel->ChHighPass = enHp20;
        pChannel->ChLowPass = enLp400;
        break;
    case 2:
        pChannel->ChHighPass = enHp20;
        pChannel->ChLowPass = enLp1200;
        break;
    case 3:
        pChannel->ChHighPass = enHp20;
        pChannel->ChLowPass = enLpBypass;
        break;
    case 4:
        pChannel->ChHighPass = enHp100;
        pChannel->ChLowPass = enLp400;
        break;
    case 5:
        pChannel->ChHighPass = enHp100;
        pChannel->ChLowPass = enLp1200;
        break;
    case 6:
        pChannel->ChHighPass = enHp100;
        pChannel->ChLowPass = enLpBypass;
        break;
    case 7:
        pChannel->ChHighPass = enHp400;
        pChannel->ChLowPass = enLp1200;
        break;
    case 8:
        pChannel->ChHighPass = enHp400;
        pChannel->ChLowPass = enLpBypass;
        break;
    default:
        pChannel->ChHighPass = enHpBypass;
        pChannel->ChLowPass = enLpBypass;
        break;
    }
	
    switch (ch1_gain)
    {
    case 0:
        pChannel->ChGain = enGain0;
        break;
    case 1:
        pChannel->ChGain = enGainNeg12;
        break;
    case 2:
        pChannel->ChGain = enGainNeg9;
        break;
    case 3:
        pChannel->ChGain = enGainNeg6;
        break;
    case 4:
        pChannel->ChGain = enGain6;
        break;
    case 5:
        pChannel->ChGain = enGain9;
        break;
    case 6:
        pChannel->ChGain = enGain12;
        break;
    case 7:
        pChannel->ChGain = enGainGnd;
        break;
    }

    WriteRegister(cardNo, CH_CFG_DATA_REG_H, RegVal.cmd.CmdH);
    WriteRegister(cardNo, CH_CFG_DATA_REG_L, RegVal.cmd.CmdL);
    WriteRegister(cardNo, CH_CFG_CTR_REG, 0);
    WriteRegister(cardNo, CH_CFG_CTR_REG, 1);
#else
    bufOutput[0] = 1 ;
    
    UINT val = 0;

    //ͨ��2
    filter = ch1_filter;
    gain = ch1_gain;
	
    if(filter < 4) {
        m_ch_l = (UCHAR)filter;
        m_ch_h = 0;
    }else if(filter < 7){
        m_ch_l = filter - 3;
        m_ch_h = 1;	
    }else if(filter < 9){
        m_ch_l = filter - 5;
        m_ch_h = 2;	
    }
    else {
        m_ch_l = 3;
        m_ch_h = 3;		
    }

    bufOutput[4] = m_ch_l +1 ;
    bufOutput[5] = m_ch_h +1 ;
    bufOutput[6] = gain+1 ;

#ifdef SINGLE_POINT_BUS_INTERFACE
    switch(bufOutput[4])
    { 
    case 1: bufOutput[4] = 0x08 ; break;   
    case 2: bufOutput[4] = 0x04 ; break; 
    case 3: bufOutput[4] = 0x02 ; break; 
    case 4: bufOutput[4] = 0x01 ; break;       
    default:bufOutput[4] = 0x00 ;
    }
    val = bufOutput[4];

    switch(bufOutput[5])
    { 
    case 1: bufOutput[5] = 0x08 ; break;   
    case 2: bufOutput[5] = 0x04 ; break; 
    case 3: bufOutput[5] = 0x02 ; break; 
    case 4: bufOutput[5] = 0x01 ; break;       
    default:bufOutput[5] = 0x00 ;
    }  
    
    switch(bufOutput[6])
    { 
    case 1: bufOutput[6] = 0x80 ; break;   
    case 2: bufOutput[6] = 0xC0 ; break; 
    case 3: bufOutput[6] = 0xA0 ; break; 
    case 4: bufOutput[6] = 0x10 ; break;       
    default:bufOutput[6] = 0x00 ;
    }
    val = val | (((UINT)(bufOutput[5] | bufOutput[6])) << 8);
#endif

    //ͨ��1
    filter = ch0_filter;
    gain = ch0_gain;
	
    if(filter < 4) {
        m_ch_l = (UCHAR)filter;
        m_ch_h = 0;
    }else if(filter < 7){
        m_ch_l = filter - 3;
        m_ch_h = 1;	
    }else if(filter < 9){
        m_ch_l = filter - 5;
        m_ch_h = 2;	
    }
    else {
        m_ch_l = 3;
        m_ch_h = 3;		
    }

    bufOutput[1] = m_ch_l +1 ;
    bufOutput[2] = m_ch_h +1 ;
    bufOutput[3] = gain+1 ;

#ifdef SINGLE_POINT_BUS_INTERFACE
    switch(bufOutput[1])
    { 
    case 1: bufOutput[1] = 0x08 ; break;   
    case 2: bufOutput[1] = 0x04 ; break; 
    case 3: bufOutput[1] = 0x02 ; break; 
    case 4: bufOutput[1] = 0x01 ; break;       
    default:bufOutput[1] = 0x00 ;
    }
    val = val | (((UINT)(bufOutput[1])) << 16);
    
    switch(bufOutput[2])
    { 
    case 1: bufOutput[2] = 0x08 ; break;   
    case 2: bufOutput[2] = 0x04 ; break; 
    case 3: bufOutput[2] = 0x02 ; break; 
    case 4: bufOutput[2] = 0x01 ; break;       
    default:bufOutput[2] = 0x00 ;
    }  
    
    switch(bufOutput[3])
    { 
    case 1: bufOutput[3] = 0x80 ; break;   
    case 2: bufOutput[3] = 0xC0 ; break; 
    case 3: bufOutput[3] = 0xA0 ; break; 
    case 4: bufOutput[3] = 0x10 ; break;       
    default:bufOutput[3] = 0x00 ;
    }
    val = val | (((UINT)(bufOutput[2] | bufOutput[3])) << 24);
#endif

#ifdef SINGLE_POINT_BUS_INTERFACE
	//���
    WriteRegister(cardNo, AE_595_DATA_REG, val);
    WriteRegister(cardNo, AE_595_CTRL_REG, 0);
    
    WriteRegister(cardNo, AE_595_CTRL_REG, START_595_CONFIG);
#else
    USBWriteEP(cardNo,0,8,bufOutput);
#endif

#endif
	return TRUE;
}

//##ModelId=4C22CB3B02BF
BOOL usbAEhardware::SetCardSample(unsigned short CardNo, BOOL bStatus)
{    
    UINT regvalue,value;
	if(CardNo >= MAX_CARDNUM)
		return FALSE;

 	ReadRegister(CardNo,AE_COMMAND,&regvalue);
	if(bStatus)
		value = ( regvalue & 0xFFFFFFFC) | 0x3;
	else
		value = regvalue & 0xFFFFFFFC;

   	WriteRegister(CardNo,AE_COMMAND,value);
	
	return TRUE;
}

//##ModelId=4C22CB3B02CE
BOOL usbAEhardware::SetCardPause(unsigned short CardNo, BOOL bStatus)
{
	UINT regvalue, value;
 
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
		return FALSE;

	ReadRegister(CardNo,AE_COMMAND,&regvalue);
	
#ifdef BGA_18BITS_40M_VERSION
	if(bStatus)
		value = regvalue | 0x10;  //������ͣ����    
	else
		value = regvalue & (~0x10);  //ȡ����ͣ����
#else
	if(bStatus)
		value = regvalue & 0xFFFFFFFE;//( regvalue & 0xFFFFFFFE) & (~0x1);
	else
		value = (regvalue & 0xFFFFFFFE) | 0x1;
#endif

	WriteRegister(CardNo,AE_COMMAND,value);

	return TRUE;
}

//##ModelId=4C22CB3B0280
BOOL usbAEhardware::SetCardschControl(unsigned short CardNo, WORD schControl)
{
   UINT regValue;
	if(CardNo >= MAX_CARDNUM)
		return FALSE;
	ReadRegister(CardNo,AE_COMMAND,&regValue);
	WriteRegister(CardNo,AE_COMMAND, ( regValue & 0xFFFFC0FF) | ((schControl & 0x3F) << 8));
	return TRUE;
}

//##ModelId=4C22CB3B0271
BOOL usbAEhardware::SetCardSelectLight(unsigned short CardNo, WORD bSelect)
{
    UINT regValue;
	if(CardNo >= MAX_CARDNUM)
		return FALSE;
	ReadRegister(CardNo,AE_COMMAND,&regValue);
	WriteRegister(CardNo,AE_COMMAND, ( regValue & 0xFFF03FFF) | ((bSelect & 0x3F) << 14));
	return TRUE;
}

//##ModelId=4C22CB3B0261
BOOL usbAEhardware::SetCardEnableWaveformParam(unsigned short CardNo, WORD EnableWavefrom, WORD EnableParam)
{
	UINT regvalue,value;

	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
		return FALSE;

	value = ((EnableWavefrom & 0x3F) << 6 ) + (EnableParam & 0x3F);

	ReadRegister(CardNo,AE_COMMAND,&regvalue);
	WriteRegister(CardNo,AE_COMMAND, ( regvalue & 0x000FFFFF) |(value << 20));  

#ifdef BGA_18BITS_40M_VERSION
    int i;
    for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
    {
        if ((EnableWavefrom & (1 << i)) == 0)
        {
            ReadRegister(CardNo, AE_SAMPLE_MODE + i, &regvalue);
            WriteRegister(CardNo, AE_SAMPLE_MODE + i, regvalue & 0x3FFFFFFF);   //��������Ϊ�����ɼ�ģʽ��ȡ��ǰ�ɻ���ģʽ
        }
    }
#endif

    return TRUE;
}

/*--------------------
Set Sameple length

Format for register : AE_SAMPLE_LENGTH_FREQ0
reg[31:8]   --> sample Length, unit byte
reg[7:0]    --> sample freq factor
             Actually sample Freq = 40M /(2 *(reg[7:0] + 1))
---------------------------*/

//##ModelId=4C22CB3B0223
BOOL usbAEhardware::SetCardSampleLength(unsigned short  CardNo, DWORD value)
{
	UINT regvalue;

	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
		return FALSE;

#ifdef STREAMING_DEBUG
    SampleLength = value;
#endif

	ReadRegister(CardNo,AE_SAMPLE_LENGTH_FREQ0,&regvalue);
#ifdef CONVENTIONAL_16BITS_10M_WITHOUT_FFT
    WriteRegister(CardNo, AE_SAMPLE_LENGTH_FREQ0, (value << 16) | (regvalue & 0xffff));
#else
    WriteRegister(CardNo, AE_SAMPLE_LENGTH_FREQ0, (value << 8) | (regvalue & 0xff));
#endif

#ifdef SINGLE_POINT_BUS_INTERFACE
    //(ceil(N/512)-1)*256��NΪ����֡���ȵ��ֽ��������������Ϊ2044����N=4096�����������Ϊ2048����N=4104
    WriteRegister(CardNo, AE_PKG_TAIL_FRM_LEN_REG, ((((value << 1) + 511 + 8) >> 9) - 1) << 8);
#endif

    //only for continuous sampling test
//     ReadRegister(CardNo, AE_STREAM_MODE_REG, &regvalue);
//     WriteRegister(CardNo, AE_STREAM_MODE_REG, 0x0f | regvalue);   //����Ϊ�����ɼ�ģʽ
    //end

	return TRUE;
}

BOOL usbAEhardware::GetCardSampleFreq(unsigned short CardNo, WORD *value)
{
    UINT regvalue;
    
    if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
        return FALSE;
    
    regvalue = 0;

    ReadRegister(CardNo,AE_SAMPLE_LENGTH_FREQ0,&regvalue);
#ifdef CONVENTIONAL_16BITS_10M_WITHOUT_FFT
    *value = regvalue & 0x0000ffff;
#else
    *value = regvalue & 0x000000ff;
#endif
    
    if (*value == 0)
    {
        return FALSE;
    }
    
#ifdef STREAMING_DEBUG
    SampleCycle = 25 * (*value);//ns
#endif
    
    return TRUE;

}

/*--------------------
Set Sameple Freq

Format for register : AE_SAMPLE_LENGTH_FREQ0
reg[31:8]   --> sample Length, unit byte
reg[7:0]    --> sample freq factor
             Actually sample Freq = 40M /(2 *(reg[7:0] + 1))
---------------------------*/

//##ModelId=4C22CB3B0232
BOOL usbAEhardware::SetCardSampleFreq(unsigned short  CardNo, WORD value)
{
	UINT regvalue;

	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
		return FALSE;

#ifdef STREAMING_DEBUG
    SampleCycle = 25 * value;//ns
#endif

	ReadRegister(CardNo,AE_SAMPLE_LENGTH_FREQ0,&regvalue);
#ifdef CONVENTIONAL_16BITS_10M_WITHOUT_FFT
    WriteRegister(CardNo,AE_SAMPLE_LENGTH_FREQ0,(regvalue & 0xffff0000) |value);  
#else
    WriteRegister(CardNo,AE_SAMPLE_LENGTH_FREQ0,(regvalue & 0xffffff00) | (value & 0xFF));
#endif

#ifdef BGA_18BITS_40M_VERSION
    //��������ADC��ֵ�����л�ʱ���л���
//     if ((value & 0xFF) == 1)    //40M������
//     {
//         WriteRegister(CardNo, AE_ADC_CFG_REG, ( 8191 << 16 ) | ( -2000 & 0x0000ffff ));
//     }
//     else
    {
        WriteRegister(CardNo, AE_ADC_CFG_REG, ( 8191 << 16 ) | ( -8192 & 0x0000ffff ));
    }
#endif

	
	return TRUE;
}


//##ModelId=4C22CB3B0206
BOOL usbAEhardware::SetCardParamEventInterval(unsigned short  CardNo, DWORD value)
{
	UINT regvalue;
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
		return FALSE;

#ifdef BGA_18BITS_40M_VERSION
    WriteRegister(CardNo, AE_PARM_EVENT_INTERVAL, value);  
#else
    ReadRegister(CardNo,AE_PARM_EVENT_INTERVAL_LOCKOUT,&regvalue);
	WriteRegister(CardNo,AE_PARM_EVENT_INTERVAL_LOCKOUT, (value << 16 ) | (regvalue & 0xffff));  
#endif
    
	return TRUE;
}

//##ModelId=4C22CB3B0215
BOOL usbAEhardware::SetCardParamEventLockOut(unsigned short  CardNo, DWORD value)
{
  	UINT regvalue;
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
		return FALSE;

#ifdef BGA_18BITS_40M_VERSION
    WriteRegister(CardNo, AE_PARM_EVENT_LOCKOUT, value);
#else
	ReadRegister(CardNo,AE_PARM_EVENT_INTERVAL_LOCKOUT,&regvalue);
	WriteRegister(CardNo,AE_PARM_EVENT_INTERVAL_LOCKOUT,(regvalue & 0xffff0000) | (value & 0xffff));  
#endif

	return TRUE;
}

BOOL usbAEhardware::SetCardParamEventPdt(unsigned short CardNo, DWORD value)
{
	return FALSE;
}

//##ModelId=4C22CB3B0242
BOOL usbAEhardware::SetCardParamThreshold(unsigned short chanNo, DWORD value)
{
	UINT regvalue;
	unsigned short CardNo;
	CardNo = chanNo /CHANNEL_NUMBER_PERCARD;
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
		return FALSE;

#ifdef BGA_18BITS_40M_VERSION
    WriteRegister(CardNo,AE_HIT_THRESHOLD_CH0 + chanNo % CHANNEL_NUMBER_PERCARD, value & 0x3ffff);  
#else
	ReadRegister(CardNo,AE_THRESHOLD_PARAM_SAMPLE0 + chanNo % CHANNEL_NUMBER_PERCARD,&regvalue);
	WriteRegister(CardNo,AE_THRESHOLD_PARAM_SAMPLE0 + chanNo % CHANNEL_NUMBER_PERCARD, (value << 16 ) | (regvalue & 0xffff));  
#endif

	return TRUE;
}

//##ModelId=4C22CB3B0251
BOOL usbAEhardware::SetCardSampleThreshold(unsigned short chanNo, DWORD value)
{
	UINT regvalue;

	unsigned short CardNo;
	CardNo = chanNo /CHANNEL_NUMBER_PERCARD;
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE )
		return FALSE;

#ifdef BGA_18BITS_40M_VERSION
	WriteRegister(CardNo,AE_WAVE_THRESHOLD_CH0 + chanNo % CHANNEL_NUMBER_PERCARD, value & 0x3ffff);  
#else
	ReadRegister(CardNo,AE_THRESHOLD_PARAM_SAMPLE0 + chanNo % CHANNEL_NUMBER_PERCARD,&regvalue);
// 	WriteRegister(CardNo,AE_THRESHOLD_PARAM_SAMPLE0 + chanNo % CHANNEL_NUMBER_PERCARD,(regvalue & 0xffff0000) |value);  
	WriteRegister(CardNo,AE_THRESHOLD_PARAM_SAMPLE0 + chanNo % CHANNEL_NUMBER_PERCARD,(regvalue & 0xffff0000) | (value & 0xffff));  
#endif
 
	return TRUE;
}

/*--------------------
Issue Pluse , namely AST function
Description:
chan:    Pluse Channel NO
TrigPara[7:0] --   Pluse Number
TrigPara[15:8] --  PluseWidth ,Unit 1us;
TrigPara[23:16] -- PluseInter, Unit 50ms;
TrigPara[31:24] -- Not used
---------------------------*/

//##ModelId=4C22CB3B01B5
BOOL usbAEhardware::OnPluseTrig(int chanNo,int TrigPara)
{
	short	cardNo;
	UINT	Trigvalue;
	UINT    regValue;

	cardNo = chanNo/CHANNEL_NUMBER_PERCARD;
	chanNo = chanNo%CHANNEL_NUMBER_PERCARD;
	if(cardNo >= MAX_CARDNUM || chanNo < 0)
		return FALSE;

	if(cardNo >= MAX_CARDNUM || bDeviceOpenFlag[cardNo] == FALSE)
	{
		return -1;
	}

	Trigvalue =  chanNo | ( TrigPara << 4);
	
   //seting chno, pulse value;
	WriteRegister(cardNo,AE_OUTER_TRIG,Trigvalue);  
   // start trig.....
 	WriteRegister(cardNo,	AE_OUTER_TRIG,Trigvalue | 0x80000000 );
	do{
	    ReadRegister(cardNo,AE_OUTER_TRIG,&regValue);
	}while((regValue & 0x40000000 ) == 0);

	   // stop trig....
	WriteRegister(cardNo,AE_OUTER_TRIG,Trigvalue);  
	return TRUE;
}


//##ModelId=4C22CB3B01C5
BOOL usbAEhardware::OnPluseTrigStop(int chanNo)
{
	short	cardNo;
	UINT    regValue,regValueOld;

	cardNo = chanNo/CHANNEL_NUMBER_PERCARD;
	chanNo = chanNo%CHANNEL_NUMBER_PERCARD;
	if(cardNo >= MAX_CARDNUM || chanNo < 0)
		return FALSE;

	ReadRegister(cardNo,AE_OUTER_TRIG,&regValue);
    WriteRegister(cardNo,AE_OUTER_TRIG,regValue & (~0x80000000)); 
	
	ReadRegister(cardNo,AE_COMMAND,&regValueOld);
	// close all waveform , parameter sampling, for the hardware switch
	WriteRegister(cardNo,AE_COMMAND,regValueOld & ~(0xFFF00000));

	regValue = regValueOld & (~(0xFFF00000 | (1 << (chanNo + 8))));
	WriteRegister(cardNo,AE_COMMAND,regValue);

	Sleep(100);
	regValue = regValueOld & (~(1 << (chanNo + 8)));
	WriteRegister(cardNo,AE_COMMAND,regValue);
	return TRUE;
}

//##ModelId=4C22CB3B01D6
DWORD usbAEhardware::GetCardStatus(BOOL *bDeviceFlag, BOOL reset)
{
    int OpenCardNum = 0;

	if(bDeviceFlag)
		memset(bDeviceFlag,0,MAX_CARDNUM*sizeof(BOOL));
	memset(&bDeviceStaus,0,MAX_CARDNUM*sizeof(BOOL));

#ifdef SINGLE_POINT_BUS_INTERFACE
    OpenCardNum = FindAllSinglePointCard(bDeviceFlag);
#else
	int i;
	ZT_PCIBOARD zt;
    for(i =0; i < MAX_CARDNUM; i++){
		zt.lIndex = i;
		if(OpenUSB7kC(&zt) == 0){
			if(bDeviceFlag)
				bDeviceFlag[zt.nChNo] = TRUE;
			bDeviceStaus[zt.nChNo] = TRUE;
			OpenCardNum++;
			CloseUSB7kC(zt.nChNo);
		}
	}
#endif
    bQueryCardStatus = TRUE;
	//return 0;
	return OpenCardNum;
}

BOOL usbAEhardware::GetCardDriverVersion(unsigned short cardNo, PEZUSB_DRIVER_VERSION pDriverVersion)
{
	BOOL status;
	status = GetDriverVersion(cardNo, &m_DriverVersion);
    if (status)
    {
        *pDriverVersion = m_DriverVersion;
    }

	return status;
}


//##ModelId=4C22CB3B00CB
void usbAEhardware::ConfigDDR(short nIndex)
{
   UINT regvalue;
   UINT dwReadValue;
   UINT dwDDR_DATA[8];
   int i;

   ReadRegister(nIndex,AE_DDR_PARAMETER,&regvalue);
   regvalue &= ~0x10;
   WriteRegister(nIndex,AE_DDR_PARAMETER,regvalue & ~0x8000);
   Sleep(20);
   WriteRegister(nIndex,AE_DDR_PARAMETER,regvalue | 0x8000);

   ReadRegister(nIndex,AE_DDR_PARAMETER,&regvalue);
   WriteRegister(nIndex,AE_DDR_PARAMETER,regvalue | 0x4000);

   ReadRegister(nIndex,0xd,&dwReadValue);

   WriteRegister(nIndex,AE_DDR_PARAMETER,regvalue & ~0x4000);
    WriteRegister(nIndex,AE_DDR_PARAMETER,regvalue | 0x2000);
   return ;
   for(i= 0; i < 8; i++)
       ReadRegister(nIndex,AE_DDR_READ_DATA_ADDR + i,&dwDDR_DATA[i]);
  
   for( int j = 0; j < 8; j++) {
      WriteRegister(nIndex,AE_DDR_PARAMETER,regvalue & ~0x2000);
      WriteRegister(nIndex,AE_DDR_ADDRESS,0x000 +  0x100000 + j*8);
      WriteRegister(nIndex,AE_DDR_PARAMETER,regvalue | 0x2000);
  
     for(i = 0; i < 8; i++)
        ReadRegister(nIndex,AE_DDR_READ_DATA_ADDR +i,&dwDDR_DATA[i]);
      WriteRegister(nIndex,AE_DDR_PARAMETER,regvalue & ~0x2000);

   }

   for(i= 0; i < 8; i++)
        ReadRegister(nIndex,AE_DDR_READ_DATA_ADDR +i,&dwDDR_DATA[i]);

}

//##ModelId=4C22CB3B01C7
void usbAEhardware::OpenCard(BOOL *bDeviceFlag, DWORD SampleLength, BOOL reset)
{
    UCHAR bufOutput[32];
    DWORD dwOpenSum = 0;
	UINT regvalue=0;
	int i;

 
	if(bOpenCardStatus)
		return;
	bOpenCardStatus = TRUE;

    if(bQueryCardStatus == FALSE) {
	   GetCardStatus();
	   bQueryCardStatus = TRUE;
	}

#ifdef SINGLE_POINT_BUS_INTERFACE
	int j;
	bool bChassisOpened;
	for(i = 0; i < MAX_CHASSIS; i++){	
		bChassisOpened = false;
		for (j = 0; j < min(MAX_CARD_NUM_PER_CHASSIS, MAX_CARDNUM - MAX_CARD_NUM_PER_CHASSIS * i); j++)
		{
			if (bDeviceStaus[i * MAX_CARD_NUM_PER_CHASSIS + j] && bDeviceFlag[i * MAX_CARD_NUM_PER_CHASSIS + j])
			{
				if ((!bChassisOpened) && (OpenUSB7kC_ByCardNo(i) == 0))
				{
					bChassisOpened = true;
				}

				if (bChassisOpened)
				{
					bDeviceOpenFlag[i * MAX_CARD_NUM_PER_CHASSIS + j] = TRUE;
				}
				else
				{
					bDeviceOpenFlag[i * MAX_CARD_NUM_PER_CHASSIS + j] = FALSE;
				}
			}
			else
			{
				bDeviceOpenFlag[i * MAX_CARD_NUM_PER_CHASSIS + j] = FALSE;
			}
		}
	}
#else
	for(i =0; i < MAX_CARDNUM; i++){
		// device is exist and to be opened
		if(bDeviceStaus[i] && bDeviceFlag[i] && OpenUSB7kC_ByCardNo(i) == 0)
		{
			if (reset)
			{
				bufOutput[0] = 11 ;				//RST_FPGA
				USBWriteEP(i,0,8,bufOutput);
				bufOutput[0] = 12 ;
				USBWriteEP(i,0,8,bufOutput);
			}
			dwOpenSum ++;
			SetCardNumberNo(i,i);
			bDeviceOpenFlag[i] = TRUE;
			//	ConfigDDR(i);
            GetCardDriverVersion(i, &m_DriverVersion);

            bufOutput[0] = 3 ;
            bufOutput[7] = 0 ;							// reset fifo
            USBWriteEP(i,0,8,bufOutput);
		}
		else 
			bDeviceOpenFlag[i] = FALSE;
	}
	openCardNum = dwOpenSum;

#endif

	SampleLen = SampleLength;
	curRawBufLength = 0;
	//curParaBufLength = 0;

	//Ϊͨ��chParamFIFO����ռ�
	if (dwOpenSum != 0)
	{
		for (i=0;i<MAX_CARDNUM*CHANNEL_NUMBER_PERCARD;i++)
		{
			chParamFIFO[i].ReleaseBuf();
			if (bDeviceOpenFlag[i/CHANNEL_NUMBER_PERCARD])		
			{
				chParamFIFO[i].AllocateBuf(HIT_PARAM_BUF_LENGTH/(dwOpenSum*CHANNEL_NUMBER_PERCARD));
                bChEnabled[i] = TRUE;
			}
            else
            {
                bChEnabled[i] = FALSE;
            }
		}
		chParamFIFO[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD    ].ReleaseBuf();
		chParamFIFO[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD    ].AllocateBuf(SYSTIME_PARAM_BUF_LENGTH);
        bChEnabled[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD] = TRUE;
	}

	singleChannelBufLen = (SampleLen << 2 ) + 8;
    singleChannelRawDataLen = (SampleLen << 1) + 8;
	maxRawBufLength = MAX_RAWDATA_BUF_LENGTH/singleChannelRawDataLen;
	singlePackageSum = singleChannelRawDataLen % BLOCK_SIZE ?  singleChannelRawDataLen/BLOCK_SIZE + 1: singleChannelRawDataLen/BLOCK_SIZE;

	restPackageData[0] = new UCHAR[singleChannelRawDataLen * MAX_CARDNUM];
    for(i =0; i < MAX_CARDNUM; i++){
	   restPackageCard[i] = singlePackageSum;
	   restPackageData[i] = restPackageData[0] + i* singleChannelRawDataLen;
	}

    curFftBufLength = 0;
    singleFftBufLen = (MAX_FFTDATA_LENGTH << 1) + 8;
    singleFftRawDataLen = (MAX_FFTDATA_LENGTH << 1) + 8;
    maxFftBufLength = MAX_FFTDATA_BUF_LENGTH / singleFftRawDataLen;
    singleFftPackageSum = singleFftRawDataLen % BLOCK_SIZE ?  singleFftRawDataLen/BLOCK_SIZE + 1: singleFftRawDataLen/BLOCK_SIZE;
    restFftPackageData[0] = new UCHAR[singleFftRawDataLen * MAX_CARDNUM];
    for(i =0; i < MAX_CARDNUM; i++)
    {
        restFftPackageCard[i] = singleFftPackageSum;
        restFftPackageData[i] = restFftPackageData[0] + i* singleFftRawDataLen;
	}

//	return dwOpenSum;
}

//##ModelId=4C22CB3B01E4
BOOL usbAEhardware::StartSample()
{
    UINT     regvalue;
    DWORD    pThreadId;
    int      i;

	memset(ovRead,0,sizeof(ovRead));

    //sysCurTime = 0;

#ifdef SINGLE_POINT_BUS_INTERFACE
	int j;

	//step1:stop all sub-card
	for(i = 0; i < MAX_CARDNUM; i++){
		if(bDeviceOpenFlag[i]){
			hEventArray[i] = CreateEvent(NULL,  TRUE, FALSE,  NULL);
            ovRead[i].hEvent = hEventArray[i];

			ReadRegister(i,AE_COMMAND,&regvalue);
			WriteRegister(i,AE_COMMAND,regvalue & (~0x1));   //reset all
			WriteRegister(i,AE_COMMAND,regvalue | 0x1);
		}
	}

	for(i = 0; i < MAX_CHASSIS; i++){	
		for (j = 0; j < min(MAX_CARD_NUM_PER_CHASSIS, MAX_CARDNUM - MAX_CARD_NUM_PER_CHASSIS * i); j++)
		{
			if (bDeviceOpenFlag[i * MAX_CARD_NUM_PER_CHASSIS + j])
			{
				break;
			}
		}
		if( j < min(MAX_CARD_NUM_PER_CHASSIS, MAX_CARDNUM - MAX_CARD_NUM_PER_CHASSIS * i))
		{
	//step2:stop mainboard
			ReadMainboardRegister(i, MB_CTRL_REG, &regvalue);
            WriteMainboardRegister(i, MB_CTRL_REG, regvalue & (~START_ALL_SUBCARD) & (~RESET_MAINBOARD));
			WriteMainboardRegister(i, MB_CTRL_REG, regvalue & (~START_ALL_SUBCARD) | RESET_MAINBOARD);

	//step3: reset usb chip fifo
			UCHAR bufOutput[33];
			
			memset(&bufOutput,0,sizeof(bufOutput));
			bufOutput[0] = 3 ;					// USB��������
			bufOutput[1] = 1 ;					// FPGA��������
			bufOutput[2] = 0;		            // �Ĵ�����ַ
			
			bufOutput[1] |= 0x80;   //����Ϊ�����߰�Ĵ�������
#ifdef SINGLE_POINT_OPTIM
			USBWriteEP(i, 1, 8, bufOutput);	
#else
			USBWriteEP(i, 0, 8, bufOutput);	
#endif
		}
	}

	Sleep(500);	//�ȴ�reset fifo���

	//step4:start mainboard
	for(i = 0; i < MAX_CHASSIS; i++){	
		for (j = 0; j < min(MAX_CARD_NUM_PER_CHASSIS, MAX_CARDNUM - MAX_CARD_NUM_PER_CHASSIS * i); j++)
		{
			if (bDeviceOpenFlag[i * MAX_CARD_NUM_PER_CHASSIS + j])
			{
				break;
			}
		}
		if( j < min(MAX_CARD_NUM_PER_CHASSIS, MAX_CARDNUM - MAX_CARD_NUM_PER_CHASSIS * i))
		{
			ReadMainboardRegister(i, MB_CTRL_REG, &regvalue);
            WriteMainboardRegister(i, MB_CTRL_REG, regvalue | START_ALL_SUBCARD);        //normal state
		}
	}
	/*-----------------------------------------------------------------------*/
#else
		
	char tempStr[12];
	int k = 0;

	GLB_ANALOG_PROP AnaRegVal[MAX_CARDNUM];
	GLB_ANALOG_PROP tmpAnaRegVal;
	UINT cmdRegVal[MAX_CARDNUM];
	CH_ANALOG_CFG_PROP* pChannel;
	UINT SampFreqDiv[MAX_CARDNUM];
			
	for(i = 0; i < MAX_CARDNUM; i++){
		if(bDeviceOpenFlag[i]){
            sprintf(tempStr, "CardEvent%u", i);
			hEventArray[k] = CreateEvent(NULL, TRUE, FALSE, tempStr);
			ovRead[i].hEvent = hEventArray[k];
			EventIndexTOCardIndex[k] = i;
			k++;

			ReadRegister(i,AE_COMMAND,&regvalue);
			WriteRegister(i,AE_COMMAND,0x0);   //reset all
#ifdef BGA_18BITS_40M_VERSION
            UINT     SampFreqDiv1;
            //��ȡ������
//             ReadRegister(i, AE_SAMPLE_LENGTH_FREQ0, &SampFreqDiv1);
//             SampFreqDiv1 &= 0xff;
            ReadRegister(i, AE_SAMPLE_LENGTH_FREQ0, &SampFreqDiv[i]);
            SampFreqDiv[i] &= 0xff;
			cmdRegVal[i] = regvalue;
//             if (SampFreqDiv[i] < 4)   //����1M
//             {
				ReadRegister(i, CH_CFG_DATA_REG_H, (unsigned int*)&tmpAnaRegVal.cmd.CmdH);
				ReadRegister(i, CH_CFG_DATA_REG_L, (unsigned int*)&tmpAnaRegVal.cmd.CmdL);
				AnaRegVal[i] = tmpAnaRegVal;
				pChannel = &tmpAnaRegVal.spec.Ch0;
				pChannel->ChGain = enGainGnd;
				pChannel = &tmpAnaRegVal.spec.Ch1;
				pChannel->ChGain = enGainGnd;
				WriteRegister(i, CH_CFG_DATA_REG_H, tmpAnaRegVal.cmd.CmdH);
				WriteRegister(i, CH_CFG_DATA_REG_L, tmpAnaRegVal.cmd.CmdL);
				WriteRegister(i, CH_CFG_CTR_REG, 0);
 				WriteRegister(i, CH_CFG_CTR_REG, 1);

				WriteRegister(i,AE_COMMAND, 0x3     //����
					& (~0x10)  //ȡ����ͣ����
					& 0x3FFFFFFF);  //�򿪲��������Զ��������Ư�ƹ���
 //           }
			
#else
            WriteRegister(i,AE_COMMAND,regvalue | 0x3);
#endif
			//	ReadRegister(i,AE_COMMAND,&regvalue);
			/************************************************************************/

#ifdef REGISTER_DEBUG
			char* pFileName = "regfile.txt";
			UINT u32Tmp;
			
			FILE* fp = fopen(pFileName, "ab+");
			
			fseek(fp, 0, SEEK_END);   char str[200];
			sprintf(str, "Card %d\r\n", i);
			fwrite(str, strlen(str), 1, fp);
			sprintf(str, "Register Address \t Register Value\r\n");
			fwrite(str, strlen(str), 1, fp);
			
			for (int j = 0; j < 0xff; j++)
			{
				ReadRegister(i, j, &u32Tmp);
				sprintf(str, "0x%x \t\t\t 0x%x\r\n", j, u32Tmp);
				fwrite(str, strlen(str), 1, fp);
			}
			fclose(fp);
			//    WriteRegister(i, AE_COMMAND, 0xc300003);
#endif
			/************************************************************************/
		}
	}

#ifdef BGA_18BITS_40M_VERSION
	Sleep(2000);            //�ȴ���Ư�������
	for(i = 0; i < MAX_CARDNUM; i++)
	{
		if(bDeviceOpenFlag[i])
		{
//  			if (SampFreqDiv[i] < 40) //����1M
//  			{
			WriteRegister(i, CH_CFG_DATA_REG_H, AnaRegVal[i].cmd.CmdH);
			WriteRegister(i, CH_CFG_DATA_REG_L, AnaRegVal[i].cmd.CmdL);
			WriteRegister(i, CH_CFG_CTR_REG, 0);
			WriteRegister(i, CH_CFG_CTR_REG, 1);
			WriteRegister(i,AE_COMMAND,(cmdRegVal[i] | 0x3)     //����
				& (~0x10)  //ȡ����ͣ����
				& 0x3FFFFFFF);  //�򿪲��������Զ��������Ư�ƹ���
			testTime[2] = GetTickCount();
// 			}
// 			else
//             {
//                 WriteRegister(i,AE_COMMAND,(cmdRegVal[i] | 0x3)     //����
// 					& (~0x10)  //ȡ����ͣ����
// 					| (~0x3FFFFFFF));  //�رղ��������Զ��������Ư�ƹ���
//             }
		}
	}
#endif


   ThreadFlag = TRUE;
   ThreadStatus = 0;
   preSysTime = 0;
   curSysTime = 0;

   ThreadHandle = CreateThread(
            NULL,                         
            0,                             
            InterruptAttachThreadLocalInt, 
            (LPVOID)this,               
            0,                             
            &pThreadId                     
            );

   for (i = 0; i < openCardNum; i++)
   {
	   sprintf(tempStr, "CardEvent%u", EventIndexTOCardIndex[i]);
	   hEventArray[i + k] = OpenEvent(EVENT_ALL_ACCESS, NULL, tempStr);
   }
   for (i = openCardNum * 2; i < MAX_CARDNUM * 2; i++)
   {
	   hEventArray[i] = NULL;
   }
   
#endif

#ifdef _DEBUG
#ifdef REGISTER_DEBUG
   /************************************************************************/
//    char* pFileName = "regfile.dat";
//    UINT u32Tmp;
//    
//    FILE* fp = fopen(pFileName, "ab+");
//    
//    fseek(fp, 0, SEEK_END);   char str[200];
//    sprintf(str, "Register Address \t Register Value\r\n");
//    fwrite(str, strlen(str), 1, fp);
//    
//    for (i = 0; i < 0x30; i++)
//    {
//        ReadRegister(0, i, &u32Tmp);
//        sprintf(str, "0x%x \t\t\t 0x%x\r\n", i, u32Tmp);
//        fwrite(str, strlen(str), 1, fp);
//    }
//    fclose(fp);
   /************************************************************************/

   UINT aeCmd, eventLockout, paramThresSamp0, paramThresSamp1, lenFreq, outerTrig, outStat;
   UINT sysTime, exParamFixed, mode, version, streaming;
   ReadRegister(0, AE_COMMAND, &aeCmd);
   ReadRegister(0, AE_PARM_EVENT_INTERVAL_LOCKOUT, &eventLockout);
   ReadRegister(0, AE_THRESHOLD_PARAM_SAMPLE0, &paramThresSamp0);
   ReadRegister(0, AE_THRESHOLD_PARAM_SAMPLE1, &paramThresSamp1);
   ReadRegister(0,AE_SAMPLE_LENGTH_FREQ0, &lenFreq);
   ReadRegister(0, AE_OUTER_TRIG, &outerTrig);
   ReadRegister(0, AE_OUT_STATUS_FLAG, &outStat);
   ReadRegister(0, AE_SYSTIMER_SETTING, &sysTime);
#ifndef FPGA_VERSION_1_3
   UINT exParamAttr;
   ReadRegister(0, AE_EXPARAM_ATTRI, &exParamAttr);
#endif
   ReadRegister(0, AE_EXPARAM_FIXED, &exParamFixed);
   ReadRegister(0, AE_SAMPLE_MODE, &mode);
   ReadRegister(0, AE_VERSION_CONFIGRATION, &version);

//    ReadRegister(0, AE_STREAM_MODE_REG, &streaming);

//    char* pFileName = "datafile.dat";
//    
//    FILE* fp = fopen(pFileName, "ab+");
//    
//    fseek(fp, 0, SEEK_END);
//    
//    fwrite(&aeCmd, sizeof(UINT), 1, fp);
//    fwrite(&eventLockout, sizeof(UINT), 1, fp);
//    fwrite(&paramThresSamp0, sizeof(UINT), 1, fp);
//    fwrite(&paramThresSamp1, sizeof(UINT), 1, fp);
//    fwrite(&lenFreq, sizeof(UINT), 1, fp);
//    fwrite(&outerTrig, sizeof(UINT), 1, fp);
//    fwrite(&outStat, sizeof(UINT), 1, fp);
//    fwrite(&sysTime, sizeof(UINT), 1, fp);
//    fwrite(&exParamAttr, sizeof(UINT), 1, fp);
//    fwrite(&exParamFixed, sizeof(UINT), 1, fp);
//    fwrite(&mode, sizeof(UINT), 1, fp);
//    fwrite(&version, sizeof(UINT), 1, fp);
//    fwrite(&streaming, sizeof(UINT), 1, fp);
//   
// 	fclose(fp);
#endif
#endif
 
	return TRUE;
}

//##ModelId=4C22CB3B01E5
void usbAEhardware::StopSample()
{
 	int i, j;



/*	for(i = 0; i < MAX_CARDNUM; i++)
		if(hDeviceArray[i] == NULL){
			SetEvent(hEventArray[i]);
	//		break;
		}
		*/
    for(i = 0; i < MAX_CARDNUM; i++){	
        if( bDeviceOpenFlag[i])
            SetCardSample(i, FALSE);
    }

#ifdef SINGLE_POINT_BUS_INTERFACE
	UINT regvalue;
// 	for(i = 0; i < MAX_CHASSIS; i++){	
	for(i = MAX_CHASSIS - 1; i >= 0; i--) {
		for (j = 0; j < min(MAX_CARD_NUM_PER_CHASSIS, MAX_CARDNUM - MAX_CARD_NUM_PER_CHASSIS * i); j++)
		{
			if (bDeviceOpenFlag[i * MAX_CARD_NUM_PER_CHASSIS + j])
			{
				break;
			}
		}
		if( j < min(MAX_CARD_NUM_PER_CHASSIS, MAX_CARDNUM - MAX_CARD_NUM_PER_CHASSIS * i))
		{
			ReadMainboardRegister(i, MB_CTRL_REG, &regvalue);
			WriteMainboardRegister(i, MB_CTRL_REG, regvalue & (~START_ALL_SUBCARD));        //normal state


// 			//reset mainboard fifo
// 			UCHAR bufOutput[33];
// 			
// 			memset(&bufOutput,0,sizeof(bufOutput));
// 			bufOutput[0] = 3 ;					// USB��������
// 			bufOutput[1] = 1 ;					// FPGA��������
// 			bufOutput[2] = 0;		            // �Ĵ�����ַ
// 			
// 			bufOutput[1] |= 0x80;   //����Ϊ�����߰�Ĵ�������
// #ifdef SINGLE_POINT_OPTIM
// 			USBWriteEP(i, 1, 8, bufOutput);	
// #else
// 			USBWriteEP(i, 0, 8, bufOutput);	
// #endif
		}
	}

#endif
	
	ThreadFlag = FALSE;

    while (ThreadStatus != 2)
       Sleep(1);

	for(i = 0; i < MAX_CARDNUM; i++){	
		if( bDeviceOpenFlag[i]){
			CloseHandle(hEventArray[i]);
			hEventArray[i]	=	NULL;
		}
	} 
}

//##ModelId=4C22CB3B01F4
void usbAEhardware::CloseCard()
{
 	int i;
	if(bOpenCardStatus == FALSE)
		return;
	for( i=0; i < MAX_CARDNUM; i++){
		if(bDeviceOpenFlag[i])
#ifdef SINGLE_POINT_BUS_INTERFACE
            CloseUSB7kC(i / MAX_CARD_NUM_PER_CHASSIS);
#else
            CloseUSB7kC(i);
#endif
		 bDeviceOpenFlag[i] = FALSE;
	}
	if(restPackageData[0])
		delete restPackageData[0];
    if (restFftPackageData[0])
    {
        delete restFftPackageData[0];
    }
	bOpenCardStatus = FALSE;
}

/*++
����:
	WAE��dll��ȡ�������ݣ��ڲ�������ǰ�Ƚ�������
	�����飺
			1.��ͨ���Ĳ����Ѵ洢����Ӧ��ParamFIFO�У���ͨ��FIFO�еĲ���������ã�������ʱ�䣩
			2.ͨ�����ȡ�鲢���򣬼��Ƚϸ�ͨ������pop���Ĳ����ĵ���ʱ�䣬��С��pop��
			3.pop��ʱ�䲻�����������߳̽���ʱ������100��������ݣ��߳�ֹͣʱ��ȫ��pop�������pop
			4.Ϊ��߲���ͨ���ʣ���һ���ӳٻ��ƣ���ǰ����С��10Wʱ�������в�������ʹ��ݣ�
			  ����ʱ����Ʊ�֤������������������������ʱ��ÿ200������������ʹ���һ�β�����
����:
	__out  pBuf - Ŀ�껺������ַ
����ֵ:
	���ض�ȡ�Ĳ�������
--*/
DWORD usbAEhardware::GetParamFromBuf(PARAM *pBuf)
{
	int i;
	DWORD retnlength =0;
//	if(WAIT_OBJECT_0 != WaitForSingleObject(dataMutex[2], 1000))
//		return 0;
//    DWORD curParaBufLength = 0;
//	for (i = 0; i < MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1; i++)
//	{
//		curParaBufLength += chParamFIFO[i].GetDataLength();
//	}
//
//    for (i = 0; i < MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1; i++)
//    {
//        if (chParamFIFO[i].GetSysTime() > curSysTime)
//            curSysTime = chParamFIFO[i].GetSysTime();
//    }
//
//	if(curParaBufLength> 100000 || (curSysTime - preSysTime > 2000000))
//	{
//		preSysTime = curSysTime;
//// 		for (int i = 0; i < MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1; i++)
//// 		{
//// 			if (chParamFIFO[i].GetSysTime() > sysCurTime)
//// 				sysCurTime = chParamFIFO[i].GetSysTime();
//// 		}
//		ULONGLONG tempTime = 0;
//		if (ThreadFlag)
//		{
//			while ((tempTime + PARAM_OUTPUT_DELAY) < curSysTime)
//			{
//				tempTime = PARAM_TIME_MASK;
//				int temp = -1;
//				for (int i=0; i< MAX_CARDNUM*CHANNEL_NUMBER_PERCARD+1; i++)
//				{
//					if (chParamFIFO[i].ArriveTime < tempTime)
//					{
//						temp = i;
//						tempTime = chParamFIFO[i].ArriveTime;
//					}
//				}
//				if (temp != -1)
//				{
//					chParamFIFO[temp].popsingle(pBuf+retnlength);
//					retnlength++;
//				}			
//			}
//		}
//		else
//		{
//			while (tempTime < curSysTime)
//			{
//				tempTime = PARAM_TIME_MASK;
//				int temp = -1;
//				for (int i = 0; i < MAX_CARDNUM*CHANNEL_NUMBER_PERCARD+1; i++)
//				{
//					if (chParamFIFO[i].ArriveTime < tempTime)
//					{
//						temp = i;
//						tempTime = chParamFIFO[i].ArriveTime;
//					}
//				}
//				if (temp != -1)
//				{
//					chParamFIFO[temp].popsingle(pBuf+retnlength);
//					retnlength++;
//				}			
//			}
//		}
//	}
//	//curParaBufLength = 0;
//	ReleaseMutex(dataMutex[2]);
	return retnlength;
}

//##ModelId=4C22CB3B01F7
DWORD usbAEhardware::GetRawDataFromBuf(char *rBuf)
{
	testTime[4] = GetTickCount();
	DWORD curRawBufLength1 =0;
//	if(WAIT_OBJECT_0 != WaitForSingleObject(rawMutex, 1000))
	if(WAIT_OBJECT_0 != WaitForSingleObject(dataMutex[0], 1000))
		return 0;
	if(curRawBufLength){
// 		memcpy(rBuf, rawBuf, curRawBufLength * singleChannelBufLen);
// 		curRawBufLength1 = curRawBufLength;
// 		curRawBufLength = 0;

        int i, j;
        DWORD samp_len = (singleChannelRawDataLen - 8) >> 1;
        int *data_buf;// = (int*)rBuf;
        short *orig_data;// = (short*)rawBuf;
        int wave_data;
        DWORD ch_no;

        for (i = 0; i < curRawBufLength; i++)
        {
            data_buf = (int*)(rBuf + singleChannelBufLen * i);
            orig_data = (short *)(rawBuf + singleChannelRawDataLen * i);
            memcpy(data_buf, orig_data, 8);
#ifdef BGA_18BITS_40M_VERSION
#if 0
            wave_data = ((int)(((*orig_data) & 0x30) << 2)) >> 14;
            ch_no = (*orig_data) & 0x0FFF;
            data_buf += 2;
            orig_data += 4;

            if (ch_no >= MAX_CARDNUM*CHANNEL_NUMBER_PERCARD)
            {
                break;
//                 for (j = 0; j < samp_len; j++)
//                 {
// 
//                     data_buf[j] = 0;
//                 }
            }

            if (enuPreSamp == ChSampMode[ch_no])
            {
                wave_data |= (unsigned short)orig_data[ChPrePostSampLen[ch_no] + 1];
                data_buf[ChPrePostSampLen[ch_no] + 1] = wave_data;
                for (j = ChPrePostSampLen[ch_no]; j >= 0; j--)
                {
//                     wave_data -= orig_data[j];
//                     data_buf[j] = wave_data;
                    data_buf[j] = data_buf[j + 1] - orig_data[j];
                }
                //wave_data = data_buf[ChPrePostSampLen[ch_no] + 1];
                j = ChPrePostSampLen[ch_no] + 2;
            }
            else
            {
                data_buf[0] = wave_data | (unsigned short)orig_data[0];
                //wave_data = data_buf[0];
                j = 1;
            }

            for (/*j = 0*/; j < samp_len; j++)
            {
//                 wave_data += orig_data[j];
//                 data_buf[j] = wave_data;
                data_buf[j] = data_buf[j - 1] + orig_data[j];
            }
#else
            data_buf += 2;
            orig_data += 4;
            for (j = 0; j < samp_len; j++, data_buf++, orig_data++)
            {
                //*data_buf = (((int)(*orig_data)) << 16) >> 14;
                *data_buf = (((int)(*orig_data & 0xFFF8)) << 16) >> (19 - (*orig_data & 0x07));
            }
#endif
#else
            data_buf += 2;
            orig_data += 4;
            for (j = 0; j < samp_len; j++, data_buf++, orig_data++)
            {
                *data_buf = *orig_data;
            }
#endif
        }

#ifdef STREAMING_DEBUG
        //int j;
        WORD chno;
        unsigned __int64 tm;
        unsigned __int64 tend;
        FRAME_FLAG *pFrmFlag = NULL;
        PDWORD buf;
        FILE *fp;
        
        fp = fopen("streaming_time.txt", "ab+");
        
        for (j = 0; j < curRawBufLength; j++)
        {
            buf = (PDWORD)&rawBuf[j * singleChannelRawDataLen];
            chno = (*buf) & 0x0FFF;
            tm = ((((unsigned __int64)buf[1]) << 16) | (buf[0] >> 16)) * 100;
            tend = tm + SampleCycle * SampleLength;
            fprintf(fp, "CH%u %08x%08x-%08x%08x\r\n", chno, (DWORD)(tm >> 32), (DWORD)(tm & 0xFFFFFFFF),
                (DWORD)(tend >> 32), (DWORD)(tend & 0xFFFFFFFF));
        }
        fclose(fp);
#endif

		curRawBufLength1 = i;//curRawBufLength;
		curRawBufLength = 0;
	}
//	ReleaseMutex(rawMutex);
	ReleaseMutex(dataMutex[0]);
	return curRawBufLength1;
}

//##ModelId=4C22CB3B0204
DWORD usbAEhardware::GetFftDataFromBuf(char *rBuf)
{
    DWORD curFftBufLength1 =0;
 //   if(WAIT_OBJECT_0 != WaitForSingleObject(fftMutex, 1000))
	if(WAIT_OBJECT_0 != WaitForSingleObject(dataMutex[1], 1000))
        return 0;
    if(curFftBufLength){
//         memcpy(rBuf, fftBuf, curFftBufLength * singleFftBufLen);
//         curFftBufLength1 = curFftBufLength;
//         curFftBufLength = 0;
        int i, j;
        DWORD samp_len = (singleFftRawDataLen - 8) >> 1;
        int *data_buf;// = (int*)rBuf;
        short *orig_data;// = (short*)rawBuf;
        int wave_data;
        DWORD ch_no;

        for (i = 0; i < curFftBufLength; i++)
        {
            data_buf = (int*)(rBuf + (singleFftBufLen * 2 - 8) * i);
            orig_data = (short *)(fftBuf + singleFftRawDataLen * i);
            memcpy(data_buf, orig_data, 8);

            data_buf += 2;
            orig_data += 4;
            for (j = 0; j < samp_len; j++, data_buf++, orig_data++)
            {
                *data_buf = *orig_data;
            }
        }
        curFftBufLength1 = i;
        curFftBufLength = 0;
    }

//  ReleaseMutex(fftMutex);
	ReleaseMutex(dataMutex[1]);
    return curFftBufLength1;
}

//���FIR�˲�������
//##ModelId=4C22CB3B036B
DWORD usbAEhardware::GetFirFilterOrder()
{
	return FirFilterOrder;
}

//����FIR�˲���ϵ��
//short CardNo  -- ����
//double* pPara -- ϵ�������ַ
//int order     -- ���� 
//����ֵ        -- ��ȷִ�з���0������ִ�з���-1
//##ModelId=4C22CB3B036C
int usbAEhardware::SetFirFilter(short CardNo, double* pPara, int order)
{
	int i, j;

	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}

	if (order != FIR_ORDER)
	{
		return -1;
	}

	short *filter_coef = new short[FIR_ORDER / 2 + 1];

	if (filter_coef == NULL)
	{
		return -1;
	}

	for (i = 0; i < FIR_ORDER / 2 + 1; i++)
	{
		filter_coef[i] = (short)(pPara[i] * 32767);
	}
/************************************************************************/
//     char* pFileName;
//     FILE *fp;
//     double sum = 0;
//     pFileName = "fir_coeff.txt";
//     
//     fp = fopen(pFileName, "ab+");
//     
//     fseek(fp, 0, SEEK_END);
//     
//     char info[40];
//     for (i = 0; i < FIR_ORDER / 2 + 1; i++)
//     {
//         fprintf(fp, "%f\r\n", pPara[i]);
//         sum += pPara[i] * 2;
//     }
//     sum -= pPara[i - 1];
//     fprintf(fp, "sum = %f\r\n\r\n", sum);
//     
// 	fclose(fp);
/************************************************************************/

	//�������˲���ϵ��������˳��
#if (FIR_ORDER == 159)
	//159���˲���ϵ������˳��
	unsigned coef_seq_80 [FIR_ORDER / 2 + 1] = {79, 9, 19, 29, 39, 49, 59, 69, 78, 8, 18, 28, 38, 48, 58, 68, 77, 7, 17, 27, 37, 47,
		57, 67, 76, 6, 16, 26, 36, 46, 56, 66, 75, 5, 15, 25, 35, 45, 55, 65, 74, 4, 14, 24,
		34, 44, 54, 64, 73, 3, 13, 23, 33, 43, 53, 63, 72, 2, 12, 22, 32, 42, 52, 62, 71, 1,
        11, 21, 31, 41, 51, 61, 70, 0, 10, 20, 30, 40, 50, 60};
#elif (FIR_ORDER == 63)
	//63���˲���ϵ������˳��
#ifdef BGA_18BITS_40M_VERSION
#ifdef BGA_18BITS_HUB_NEW
    unsigned coef_seq_32 [FIR_ORDER / 2 + 1] = {31, 15, 30, 14, 29, 13, 28, 12, 27, 11, 26, 10, 25, 9, 24, 8, 23, 7, 
        22, 6, 21, 5, 20, 4, 19, 3, 18, 2, 17, 1, 16, 0};
#else
    unsigned coef_seq_32 [FIR_ORDER / 2 + 1] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 
        18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31};
#endif
#else
	unsigned coef_seq_32 [FIR_ORDER / 2 + 1] = {31, 3, 7, 11, 15, 19, 23, 27, 30, 2, 6, 10, 14, 18, 22, 26, 29, 1, 5,
		9, 13, 17, 21, 25, 28, 0, 4, 8, 12, 16, 20, 24};
#endif
#elif (FIR_ORDER == 59)
	//59���˲���ϵ������˳��
	unsigned coef_seq_32 [FIR_ORDER / 2 + 3] = {29, 1, 5, 9, 13, 17, 21, 25, 28, 0, 4, 8, 12, 16, 20,
		24, 27, 0, 3, 7, 11, 15, 19, 23, 26, 0, 2, 6, 10, 14, 18, 22};
#endif
	//��λ�˲���ģ��
	WriteRegister(CardNo, AE_FIR_CFG_REG, 0);
	Sleep(1);

	//��ϵ��д��ϵ����������
	for (j = 0; j < CHANNEL_NUMBER_PERCARD; j++)
	{
#if (FIR_ORDER == 159)
		unsigned *coef_seq = coef_seq_80;
		for (i = 0; i < FIR_ORDER / 2 + 1; i++)
#elif (FIR_ORDER == 63)
		unsigned *coef_seq = coef_seq_32;
		for (i = 0; i < FIR_ORDER / 2 + 1; i++)
#elif (FIR_ORDER == 59)
		unsigned *coef_seq = coef_seq_32;
		for (i = 0; i < FIR_ORDER / 2 + 3; i++)
#endif
		{
			WriteRegister(CardNo, AE_FIR_CFG_REG, AE_FIR_CFG_RSTN);
			WriteRegister(CardNo, AE_FIR_CFG_REG, AE_FIR_CFG_RSTN | AE_FIR_CFG_COEF_WR | (filter_coef[ coef_seq[ i ] ] & AE_FIR_CFG_COEF_DATA_MASK));
		}
		WriteRegister(CardNo, AE_FIR_CFG_REG, AE_FIR_CFG_RSTN | (AE_FIR_CFG_COEF_CFG_CH0 << j)); //��ϵ���������е�����д���˲�����  
		Sleep(1);
	}

    WriteRegister(CardNo, AE_FIR_CFG_REG, AE_FIR_CFG_RSTN | AE_FIR_CFG_EN_CH0 | AE_FIR_CFG_EN_CH1 ); //ʹ���˲���

	delete []filter_coef;

	return 0;
}

//##ModelId=4C22CB3B037C
int usbAEhardware::DisableFirFilter(short CardNo)
{
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}
	WriteRegister(CardNo, AE_FIR_CFG_REG, 0);

	return 0;
}

//����FFT����ģʽ
//##ModelId=4C22CB3B038A
int usbAEhardware::SetFFTWorkMode(short CardNo, DWORD mode)
{
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}

	WriteRegister(CardNo, AE_FFT_MODE_REG, mode);

	return 0;
}

//����fft��������
//DWORD CardNo -- ����
//DWORD fftWaveThreshold -- FFT��������ֵ
int usbAEhardware::SetFFTWaveTrigPara(DWORD CardNo, DWORD fftWaveThreshold)
{
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}

	return 0;
}

//����ͨ��FFT�������ϵ��
//##ModelId=4C22CB3B0399
int usbAEhardware::SetChFFTResultScale(unsigned short ChanNo, double scale)
{
	unsigned short CardNo;
	unsigned char addr;
	unsigned int uScale = 0;

	CardNo = ChanNo / CHANNEL_NUMBER_PERCARD;
	ChanNo = ChanNo % CHANNEL_NUMBER_PERCARD;

	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}

	addr = AE_HIT_CFG_BASEADDR_CH0;
	addr <<= ChanNo;
	
	//Scale����ת��
	uScale = (unsigned int)(scale * 32768) & AE_HIT_CFG_FFTSCALE_DATAMASK;
	WriteRegister(CardNo, addr + AE_HIT_CFG_FFTSCALE_REG, uScale);
	
	return 0;
}

//����ͨ��FFT������
//unsigned short ChanNo -- Channel No, begin from 0 to (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
//BOOL bEnableWindow	-- Set TRUE if you want to enable Window Function, otherwise Clear to FALSE
//double *pWinFunCoef   -- Pointer to window function coefficient array
//int len				-- The size of Window function coefficient
//##ModelId=4C22CB3B03A9
int usbAEhardware::SetChFFTWindowFunction(unsigned short ChanNo, BOOL bEnableWindow, double *pWinFunCoef, int len)
{
	int i;

	unsigned short CardNo;
	unsigned char addr;
	
	CardNo = ChanNo / CHANNEL_NUMBER_PERCARD;
	ChanNo = ChanNo % CHANNEL_NUMBER_PERCARD;
	
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}

	addr = AE_HIT_CFG_BASEADDR_CH0;
	addr <<= ChanNo;

	if (bEnableWindow)
	{
		if (len > WIN_FUNC_COEF_SIZE)
		{
			return -1;
		}

		//������ϵ��ת��
		int *pTmpCoef = new int[len];
		int tmpCoef  = (1L << (GetOneCount(AE_HIT_CFG_WIN_COEF_DATA_MASK) - 1)) - 1;
		for (i = 0; i < len; i++)
		{
			pTmpCoef[i] = (int)(pWinFunCoef[i] * tmpCoef);
		}

		//��λ������
		WriteRegister(CardNo, addr + AE_HIT_CFG_WINFUNC_REG, 0);

		//дϵ��
		for (i = 0; i < len; i++)
		{
			WriteRegister(CardNo, addr + AE_HIT_CFG_WINFUNC_REG, 0);
			WriteRegister(CardNo, addr + AE_HIT_CFG_WINFUNC_REG,
				/*~AE_HIT_CFG_WIN_EN & */(AE_HIT_CFG_WIN_WR | (i & AE_HIT_CFG_WIN_COEF_ADDR_MASK) | ((pTmpCoef[i] * (AE_HIT_CFG_WIN_COEF_ADDR_MASK + 1)) & AE_HIT_CFG_WIN_COEF_DATA_MASK)));
		}

		//ʹ�ܴ�����
		//WriteRegister(CardNo, addr + AE_HIT_CFG_WINFUNC_REG, AE_HIT_CFG_WIN_EN);

		delete []pTmpCoef;
	}
	else
	{
		WriteRegister(CardNo, addr + AE_HIT_CFG_WINFUNC_REG, 0);
	}
	
	return 0;
}

//����ͨ��FFT���������泤��
//unsigned short ChanNo -- Channel No, begin from 0 to (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
//int len               -- ����
//return				-- return 0 when succeed, return -1 when fail.
//##ModelId=4C22CB3B03B9
int usbAEhardware::SetChFFTSaveLen(unsigned short ChanNo, int len)
{
	unsigned short CardNo;
	unsigned char addr;

	CardNo = ChanNo / CHANNEL_NUMBER_PERCARD;
	ChanNo = ChanNo % CHANNEL_NUMBER_PERCARD;
	
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}
	
	addr = AE_HIT_CFG_BASEADDR_CH0;
	addr <<= ChanNo;

	WriteRegister(CardNo, addr + AE_HIT_CFG_FFT_SAVELEN_REG, len & AE_HIT_CFG_FFT_SAVELEN_MASK);

	return 0;
}

//����ͨ��FFT�źų�ȡ�ʣ����Ϊ65535����СΪ1��ע����Ҫͬ�˲������õ����
//##ModelId=4C22CB3B03C9
int usbAEhardware::SetChFFTDecimateRate(unsigned short ChanNo, int val)
{
	unsigned short CardNo;
	unsigned char addr;
	
	CardNo = ChanNo / CHANNEL_NUMBER_PERCARD;
	ChanNo = ChanNo % CHANNEL_NUMBER_PERCARD;
	
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}
	
	addr = AE_HIT_CFG_BASEADDR_CH0;
	addr <<= ChanNo;
	
	WriteRegister(CardNo, addr + AE_HIT_CFG_FFT_DECIMATE_RATE_REG, val & AE_HIT_CFG_FFT_DECIMATE_RATE_MASK);
	
	return 0;
}

//����ͨ��FFT�ֲ���������ֵ
//unsigned int id  -- �����, 0 ~ (MAX_FFT_PARTIAL_POW_SEGMENTS - 1)
//int StartBin     -- ��ʼBIN���
//int EndBin       -- �յ�BIN���
//##ModelId=4C22CB3B03D8
int usbAEhardware::SetChFFTPartialPowerSegment(unsigned short ChanNo, unsigned int id, int StartBin, int EndBin)
{
	unsigned short CardNo;
	unsigned char addr;
	
	CardNo = ChanNo / CHANNEL_NUMBER_PERCARD;
	ChanNo = ChanNo % CHANNEL_NUMBER_PERCARD;
	
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}

	if (id >= MAX_FFT_PARTIAL_POW_SEGMENTS)
	{
		return -1;
	}
	
	addr = AE_HIT_CFG_BASEADDR_CH0;
	addr <<= ChanNo;
#ifdef SINGLE_POINT_BUS_INTERFACE	
	WriteRegister(CardNo, addr + AE_HIT_CFG_FFT_PARTIALPOW_REG0 + id, 
		(StartBin & AE_HIT_CFG_FFT_PARTIALPOW_MIN_MASK) | ((EndBin << 16) & AE_HIT_CFG_FFT_PARTIALPOW_MAX_MASK));
#else
	WriteRegister(CardNo, addr + AE_HIT_CFG_FFT_PARTIALPOW_REG0 + id, 
		(StartBin & AE_HIT_CFG_FFT_PARTIALPOW_MIN_MASK) | ((EndBin << 9) & AE_HIT_CFG_FFT_PARTIALPOW_MAX_MASK));
#endif	
	return 0;
}

//##ModelId=4C22CB3C0001
BOOL usbAEhardware::SetChStreamingMode(unsigned short chanNo, BOOL bEnabled, int TrigMode)
{
    UINT regvalue;
    
    unsigned short CardNo;
    CardNo = chanNo /CHANNEL_NUMBER_PERCARD;
    if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE )
        return FALSE;
#ifdef BGA_18BITS_40M_VERSION
    chanNo = chanNo % CHANNEL_NUMBER_PERCARD;
    ReadRegister(CardNo, AE_SAMPLE_MODE + chanNo, &regvalue);
    if (bEnabled)
    {
        WriteRegister(CardNo, AE_SAMPLE_MODE + chanNo, (STREAMING_ENABLE | regvalue) & 0x3FFFFFFF);   //����Ϊ�����ɼ�ģʽ���ұ�������Ϊ�����ɼ�ģʽ��ȡ��ǰ�ɻ���ģʽ
    }
    else
    {
        WriteRegister(CardNo, AE_STREAM_MODE_REG, (~STREAMING_ENABLE) & regvalue);
    }
#endif
    
    return TRUE;
}

BOOL usbAEhardware::StartChStreamingInternalTrig(unsigned short chanNo)
{
    return FALSE;
}

BOOL usbAEhardware::SetAdg1439(DWORD CardNo, unsigned long dat_l, unsigned long dat_h)
{
#ifdef BGA_18BITS_40M_VERSION
    UINT regvalue;
    
    if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE )
        return FALSE;

    WriteRegister(CardNo, CH_CFG_DATA_REG_L, dat_l);
    WriteRegister(CardNo, CH_CFG_DATA_REG_H, dat_h);
    WriteRegister(CardNo, CH_CFG_CTR_REG, 0);
    WriteRegister(CardNo, CH_CFG_CTR_REG, 1);
    return TRUE;
#else
    return FALSE;
#endif
}


//##ModelId=4C22CB3B00CD
void usbAEhardware::AnalysisPacket(short nIndex,UCHAR *recvbuffer, UINT recvcount)
{
//	UINT allPackageSum = recvcount / BLOCK_SIZE;
//
//	UINT restPackageSum;// = restPackageCard[nIndex];
//	//PUINT pRestPackageSum = NULL;
//
//	int j;
//
//
//#ifdef DEBUG_FILE
//	//���屣��FFT���ݵ��ļ�·��
//	char* pFileName;
//	switch (nIndex)
//	{
//	case 0:
//		pFileName = "datafile_0.dat";
//		break;
//	case 1:
//		pFileName = "datafile_1.dat";
//		break;
//	case 2:
//		pFileName = "datafile_2.dat";
//		break;
//	case 3:
//		pFileName = "datafile_3.dat";
//		break;
//	default:
//		pFileName = "datafile.dat";
//		break;
//	}
//
//	FILE* fp = fopen(pFileName, "ab+");
//
//	fseek(fp, 0, SEEK_END);
//
//	fwrite(recvbuffer, recvcount, 1, fp);
//
//	fclose(fp);
//	//////////////////////////////////////////////////////////////////////////
//
//	pFileName = "statistic.txt";
//
//	fp = fopen(pFileName, "ab+");
//
//	fseek(fp, 0, SEEK_END);
//
//	char info[40];
//	fprintf(fp, "chassis No.%d  received bytes 0x%0x\r\n", nIndex + 1, recvcount);
//
//	fclose(fp);
//#endif
//
//	for(UINT i = 0; i < allPackageSum; )
//	{
//#ifdef CONVENTIONAL_16BITS_10M_WITHOUT_FFT
//		if((restPackageCard[nIndex] < singlePackageSum)
//			|| ((*(unsigned short *)&recvbuffer[i*BLOCK_SIZE]) & 0x8000)) // waveform
//#else
//		if ((restPackageCard[nIndex] < singlePackageSum)
//			|| ((restFftPackageCard[nIndex] >= singleFftPackageSum)
//			&& (((*(unsigned short *)&recvbuffer[i*BLOCK_SIZE]) & 0xC000) == 0x8000)))   //Realtime Wave
//#endif
//		{
//			//pRestPackageSum = &restPackageCard[nIndex];
//			restPackageSum = restPackageCard[nIndex];
//
//			while(curRawBufLength >= maxRawBufLength)
//			{
//				if (!ThreadFlag)
//				{
//					return;
//				}
//			}
//			if(WAIT_OBJECT_0 != WaitForSingleObject(dataMutex[0], 1000))
//				continue;
//			if(i + restPackageSum <= allPackageSum) {  // copy all singlerawbuf
//				if(restPackageSum == singlePackageSum)
//				{
//					memcpy(&rawBuf[curRawBufLength * singleChannelRawDataLen], &recvbuffer[i*BLOCK_SIZE],singleChannelRawDataLen);
//				}
//				else {
//					memcpy(&rawBuf[curRawBufLength * singleChannelRawDataLen], restPackageData[nIndex], (singlePackageSum - restPackageSum) * BLOCK_SIZE );
//					memcpy(&rawBuf[curRawBufLength * singleChannelRawDataLen + (singlePackageSum - restPackageSum)* BLOCK_SIZE], &recvbuffer[i*BLOCK_SIZE],singleChannelRawDataLen - (singlePackageSum - restPackageSum) * BLOCK_SIZE );				
//				}
//				curRawBufLength ++;
//				i +=  restPackageSum;
//				restPackageSum = singlePackageSum;
//			}
//			else {  // not enough a singleraw buf
//				memcpy(restPackageData[nIndex] + (singlePackageSum - restPackageSum)* BLOCK_SIZE, &recvbuffer[i*BLOCK_SIZE], (allPackageSum -i) * BLOCK_SIZE );
//				restPackageSum -= (allPackageSum -i);
//				i = allPackageSum;
//			}
//			restPackageCard[nIndex] = restPackageSum;
//			ReleaseMutex(dataMutex[0]);
//		}
//#ifndef CONVENTIONAL_16BITS_10M_WITHOUT_FFT
//		else if ((restFftPackageCard[nIndex] < singleFftPackageSum)
//			|| ((restPackageCard[nIndex] >= singlePackageSum)
//			&& (((*(unsigned short *)&recvbuffer[i*BLOCK_SIZE]) & 0xC000) == 0xC000)))   //FFT Wave
//		{
//			UINT tmp1 = restFftPackageCard[nIndex];
//			//pRestPackageSum = &restFftPackageCard[nIndex];
//			restPackageSum = restFftPackageCard[nIndex];
//
//			while(curFftBufLength >= maxFftBufLength)
//			{
//				if (!ThreadFlag)
//				{
//					return;
//				}
//			}
//			if(WAIT_OBJECT_0 != WaitForSingleObject(dataMutex[1], 1000))
//				continue;
//			if(i + restPackageSum <= allPackageSum) {  // copy all singlerawbuf
//				if(restPackageSum == singleFftPackageSum)
//					memcpy(&fftBuf[curFftBufLength * singleFftRawDataLen], &recvbuffer[i*BLOCK_SIZE],singleFftRawDataLen);
//				else {
//					memcpy(&fftBuf[curFftBufLength * singleFftRawDataLen], restFftPackageData[nIndex], (singleFftPackageSum - restPackageSum) * BLOCK_SIZE );
//					memcpy(&fftBuf[curFftBufLength * singleFftRawDataLen + (singleFftPackageSum - restPackageSum)* BLOCK_SIZE], &recvbuffer[i*BLOCK_SIZE],singleFftRawDataLen - (singleFftPackageSum - restPackageSum) * BLOCK_SIZE );				
//				}
//				curFftBufLength ++;
//				i +=  restPackageSum;
//				restPackageSum = singleFftPackageSum;
//			}
//			else {  // not enough a singleraw buf
//				memcpy(restFftPackageData[nIndex] + (singleFftPackageSum - restPackageSum)* BLOCK_SIZE, &recvbuffer[i*BLOCK_SIZE], (allPackageSum -i) * BLOCK_SIZE );
//				restPackageSum -= (allPackageSum -i);
//				i = allPackageSum;
//			}
//			restFftPackageCard[nIndex] = restPackageSum;
//			ReleaseMutex(dataMutex[1]);			
//		}
//#endif
//		else// if (((*(unsigned short *)&recvbuffer[i*BLOCK_SIZE]) & 0xC000) == 0x4000)   //Hit Data
//		{
//			WaitForSingleObject(dataMutex[2], 1000);			
//			PARAM *curParam =(PARAM*)&recvbuffer[i*BLOCK_SIZE];
//			for( j= 0;  j < PARAM_SUM_EACH_PACKAGE; j++,curParam ++)
//			{
//				if(curParam->Energy  == 0 && curParam->ChNo == 0)
//					break;
//				unsigned short tempChannel;
//				if (curParam->ChNo == SYSTIME_FLAG)
//				{
//					tempChannel = MAX_CARDNUM*CHANNEL_NUMBER_PERCARD;			
//// 					curSysTime = *(ULONGLONG*)(&curParam->ArriveTime) & PARAM_TIME_MASK;
//				}
//				else
//                {
//					tempChannel = curParam->ChNo;
//                }
//                if ((tempChannel > MAX_CARDNUM*CHANNEL_NUMBER_PERCARD) || (!bChEnabled[tempChannel]))
//                {
//                    continue;
//                }
//				chParamFIFO[tempChannel].pushsingle(curParam);
//
////                 if (curSysTime < *(ULONGLONG*)(&curParam[j].ArriveTime) & PARAM_TIME_MASK)
////                 {
////                     curSysTime = *(ULONGLONG*)(&curParam->ArriveTime) & PARAM_TIME_MASK;
////                 }
//            }
//			i++;
//
//			ReleaseMutex(dataMutex[2]);
//		}
//	}
}

//##ModelId=4C22CB3B00E1
void usbAEhardware::WriteRegister(short CardId,UCHAR addr, UINT value)
{
#ifdef SINGLE_POINT_BUS_INTERFACE
    short chassis, card;
    chassis = CardId / MAX_CARD_NUM_PER_CHASSIS;
    card = CardId % MAX_CARD_NUM_PER_CHASSIS;
#endif

	UCHAR bufOutput[33];

	memset(&bufOutput,0,sizeof(bufOutput));
	bufOutput[0] = 10 ;					// USB��������
	bufOutput[1]  = 1 ;					// FPGA��������
	bufOutput[2]  = addr;		        // �Ĵ�����ַ
	
	char *valuebuf =(char*)&value;
    
	bufOutput[3] = valuebuf[3];
	bufOutput[4] = valuebuf[2];
	bufOutput[5] = valuebuf[1];
	bufOutput[6] = valuebuf[0];

#ifdef SINGLE_POINT_BUS_INTERFACE
    bufOutput[1] |= card << 2;
    #ifdef SINGLE_POINT_OPTIM
        USBWriteEP(chassis,1,33,bufOutput);	
    #else
        USBWriteEP(chassis,0,33,bufOutput);	
    #endif
#else
    USBWriteEP(CardId,0,33,bufOutput);	
#endif

#ifdef FPGA_VERSION_1_3
#else
    if(addr == 0 && (*(unsigned long *)&bufOutput[3] == 0) ) {
		bufOutput[0] = 3 ;
	    bufOutput[7] = 0 ;							// reset fifo
#ifdef SINGLE_POINT_BUS_INTERFACE
    #ifdef SINGLE_POINT_OPTIM
        USBWriteEP(chassis,1,8,bufOutput);	
    #else
        USBWriteEP(chassis,0,8,bufOutput);	
    #endif
#else
        USBWriteEP(CardId,0,8,bufOutput);	
#endif
	}
#endif
}

//##ModelId=4C22CB3B00DD
void usbAEhardware::ReadRegister(short CardId,UCHAR addr, UINT *value)
{
#ifdef SINGLE_POINT_BUS_INTERFACE
    short chassis, card;
    chassis = CardId / MAX_CARD_NUM_PER_CHASSIS;
    card = CardId % MAX_CARD_NUM_PER_CHASSIS;
#endif
    
    UCHAR bufOutput[33];

	memset(&bufOutput,0,sizeof(bufOutput));	
	
	bufOutput[0] = 13 ;
	bufOutput[1] = 2 ;
	bufOutput[2] = addr;

#ifdef SINGLE_POINT_BUS_INTERFACE
    bufOutput[1] |= card << 2;
    #ifdef SINGLE_POINT_OPTIM
        USBWriteEP(chassis,1,10,bufOutput);
    #else
        USBWriteEP(chassis,0,10,bufOutput);
    #endif
#else
    USBWriteEP(CardId,0,10,bufOutput);
#endif

    memset(&bufOutput,0,sizeof(bufOutput));	

#ifdef SINGLE_POINT_BUS_INTERFACE
    USBReadEP(chassis,2,4,bufOutput);
#else
	USBReadEP(CardId,2,4,bufOutput);
#endif
	*value = *(UINT *)&bufOutput[0];
}

//�������еĵ���ʽ�忨
int usbAEhardware::FindAllSinglePointCard(BOOL *bDeviceFlag)
{
    ZT_PCIBOARD zt;
    int i, j;
    UINT val = 0;
	int CardNum = 0;

	memset(mb_ver, 0, sizeof(mb_ver));
	memset(card_ver, 0, sizeof(card_ver));

    for(i =0; i < MAX_CHASSIS; i++){
        zt.lIndex = i;
        if(OpenUSBChassis(&zt) == 0){
#ifdef FPGA_VERSION_1_3
			//��ȡ�汾��
			ReadMainboardRegister(zt.nChNo, MB_VERSION_REG, &mb_ver[i]);
#else
            //ȷ�������ӿ����ڸ�λ״̬
            ReadMainboardRegister(zt.nChNo, MB_CTRL_REG, &val);
            WriteMainboardRegister(zt.nChNo, MB_CTRL_REG, val & (~RESET_ALL_SUBCARD));
            WriteMainboardRegister(zt.nChNo, MB_CTRL_REG, val | RESET_ALL_SUBCARD);
#endif
//#ifdef _DEBUG
//            ReadMainboardRegister(zt.nChNo, MB_CTRL_REG, &val);
//
//            //�������FPGA����汾
//            ReadMainboardRegister(zt.nChNo, MB_VERSION_REG, &fpgaVersion);
//#endif // _DEBUG
            for (j = 0; j < MAX_CARD_NUM_PER_CHASSIS; j++)
            {
				if (j + zt.nChNo * MAX_CARD_NUM_PER_CHASSIS >= MAX_CARDNUM)
				{
					break;
				}

				val = 0;
#ifdef FPGA_VERSION_1_3
				ReadRegister(j + zt.nChNo * MAX_CARD_NUM_PER_CHASSIS, AE_PID_REG, &val);
				if (GET_PID(val) == AE_PRODUCT_ID)
				{
					ReadRegister(j + zt.nChNo * MAX_CARD_NUM_PER_CHASSIS, AE_CARDID_REG, &val);
					if (GET_CARD_NUM(val) != j)
					{
						continue;
					}
					//Get AE Card Version
					ReadRegister(j + zt.nChNo * MAX_CARD_NUM_PER_CHASSIS, AE_VERSION_REG, &card_ver[j + zt.nChNo * MAX_CARD_NUM_PER_CHASSIS]);
					//val = GET_CARD_NUM(val) + i * MAX_CARD_NUM_PER_CHASSIS;
					val = GET_CARD_NUM(val) + ((val >> 6) & 0x03) * MAX_CARD_NUM_PER_CHASSIS;
#else
                ReadRegister(j + zt.nChNo * MAX_CARD_NUM_PER_CHASSIS, AE_CARDID_REG, &val);
                if (IS_CARD_EXIST(val))
				{
					val = GET_CARD_NUM(val) + zt.nChNo * MAX_CARD_NUM_PER_CHASSIS;
#endif
//#ifdef _DEBUG
//                    //����ӿ�FPGA����汾
//                    ReadRegister(j + zt.nChNo * MAX_CARD_NUM_PER_CHASSIS, AE_VERSION_REG, &fpgaVersion);
//#endif // _DEBUG

                    if (val < MAX_CARDNUM)
                    {
                        if(bDeviceFlag)
                            bDeviceFlag[val] = TRUE;
                        bDeviceStaus[val] = TRUE;
						CardNum++;
#ifndef FPGA_VERSION_1_3
                        //�����ӿ�����ַ
                        WriteRegister(j + zt.nChNo * MAX_CARD_NUM_PER_CHASSIS, AE_CARD_BASEID_REG, zt.nChNo * MAX_CARD_NUM_PER_CHASSIS);
#endif
                    }
                }
            }

            CloseUSB7kC(zt.nChNo);
        }
    }
	return CardNum;
}

//���ͨ�������ɼ�״̬������ֵ��16λ��ʾCH0��ʧ����������16λ��ʾCH1��ʧ������
BOOL usbAEhardware::GetCardStreamingState(DWORD CardNo, unsigned long *states)
{
#ifdef BGA_18BITS_40M_VERSION
    UINT regvalue;
    
    if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE )
        return FALSE;
    
    ReadRegister(CardNo, AE_STREAM_ERROR_REG, (unsigned int *)states);
    return TRUE;
#else
    return FALSE;
#endif
}

//�������
//DWORD ChNo  -- ͨ����
//DWORD mode  -- ����ģʽ
int usbAEhardware::OutputChAlarm(DWORD ChNo, DWORD mode)
{
//     if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
//     {
//         return -1;
//     }
//     
//     UINT val;
//     //ReadRegister(CardNo, AE_ALARM_CTRL_REG, &val);
//     val = AlarmDurationTime;
//     
//     //     WriteRegister(CardNo, AE_ALARM_CTRL_REG, val & (~AE_ALARM_CTRL_BIT));
//     //     WriteRegister(CardNo, AE_ALARM_CTRL_REG, val | AE_ALARM_CTRL_BIT);
//     WriteRegister(CardNo, AE_ALARM_CTRL_REG, 0);
//     WriteRegister(CardNo, AE_ALARM_CTRL_REG, 0xFFFFFFFF);
    
    return 0;
}

//���ñ���ʧЧʱ��
//DWORD CardNo  -- ����
//DWORD ms      -- ����ʱ�䣬��λms
int usbAEhardware::SetCardAlarmTimeout(DWORD CardNo, DWORD ms)
{
    return 0;    
}

//ֹͣͨ���������
int usbAEhardware::StopChAlarm(DWORD ChNo)
{
    return 0;
}

//��ò���ת����ģ�����
PWAVETOHIT_STRUCT usbAEhardware::GetWaveToHitEntry()
{
    return NULL;
}


//�������̼��汾��
BOOL usbAEhardware::GetMbFwVersion(short ChassisId, UINT *val)
{
#ifdef SINGLE_POINT_BUS_INTERFACE
    // 	*val = 0;
    // 	ReadMainboardRegister(ChassisId, MB_VERSION_REG, val);
    *val = mb_ver[ChassisId];

	if (*val == 0)
	{
		return FALSE;
	}

	return true;
#else
	return FALSE;
#endif
}

//����ӿ��̼��汾��
BOOL usbAEhardware::GetAECardFwVersion(short CardId, UINT *val)
{
#ifdef SINGLE_POINT_BUS_INTERFACE
// 	*val = 0;
// 	ReadRegister(CardId, AE_VERSION_REG, val);
	*val = card_ver[CardId];

	if (*val == 0)
	{
		return FALSE;
	}

	return true;
#else
	return FALSE;
#endif
}

//���ָ���忨�Ĵ���ͳ������
BOOL usbAEhardware::GetTransmitStatisticData(unsigned short CardNo, unsigned __int64 val[4])
{
#ifdef SINGLE_POINT_BUS_INTERFACE
    UINT tmpVal;
    int i;

    for (i = 0; i < 4; i++)
    {
        ReadRegister(CardNo, AE_LOW_WRONG_FRM_REG + i * 2 + 1, &tmpVal);

        val[i] = tmpVal;

        ReadRegister(CardNo, AE_LOW_WRONG_FRM_REG + i * 2, &tmpVal);

        val[i] = (val[i] << 32) | tmpVal;
    }

    return TRUE;
#else
    return FALSE;
#endif
}


//���ָ���忨�Ĵ���ͳ������
BOOL usbAEhardware::ClearTransmitStatisticData(unsigned short CardNo)
{
#ifdef SINGLE_POINT_BUS_INTERFACE
    UINT tmpVal;

    ReadRegister(CardNo, AE_STATISTIC_CTRL_REG, &tmpVal);
    WriteRegister(CardNo, AE_STATISTIC_CTRL_REG, tmpVal | RESET_ALL_STATISTIC_VAL);
    WriteRegister(CardNo, AE_STATISTIC_CTRL_REG, tmpVal & (~RESET_ALL_STATISTIC_VAL));
    
    return TRUE;
#else
    return FALSE;
#endif
}

//input[10] -- ������Ϣ
//pStrBuf -- �����Ϣ���ַ���buffer
//bufSize -- �����Ϣbuffer�ĳ��ȣ���λ���ֽ�
void usbAEhardware::GetOutputInfo(UINT input[10], PCHAR pStrBuf, int bufSize)
{
    memset(pStrBuf, 0, bufSize);

    //����
    UINT val = 0;
    
    ReadRegister(0, 0, &val);

    //�����Ϣ�ַ������ȱ���С��bufSize
    sprintf(pStrBuf, "%x \n", val);
}

//input[10] -- ������Ϣ
//����ֵ    -- �ַ�����Ϣͷָ�룬ʹ������Ҫ�ⲿ�ͷ��ַ���ռ�õ��ڴ�
char * usbAEhardware::GetOutputInfo(UINT input[10])
{
    PCHAR pStrBuf;
    int bufSize;

    bufSize = 1024 * 4;

    pStrBuf = (char*)GlobalAlloc(GPTR, bufSize);

    memset(pStrBuf, 0, bufSize);

    //����
    UINT val = 0;
    
    ReadRegister(0, 0, &val);

    //�����Ϣ�ַ������ȱ���С��bufSize
    sprintf(pStrBuf, "%x \n", val);

    return pStrBuf;
}

//��StartSample����֮ǰ����
void usbAEhardware::ConfigureBeforeStart()
{
    
}

//��StartSample����֮�����
void usbAEhardware::ConfigureAfterStart()
{
    
}

void usbAEhardware::SetEncoding(unsigned short CardNo, DWORD PackingVer, DWORD FramingVer, DWORD encoding, DWORD bits)
{
    return;
}


DWORD WINAPI InterruptAttachThreadLocalInt( LPVOID pParam )
{
    unsigned long recvcount;
	DWORD recvcount_d;
#ifdef BGA_18BITS_HUB_NEW
    class UsbaeHardware18Bit  *hardware;
    hardware = (UsbaeHardware18Bit*)pParam;
#else
#ifdef BGA_16BITS_10M_NEW_VERSION
	class UsbaeHardware16BitNew *hardware;
	hardware = (UsbaeHardware16BitNew *)pParam;
#else
    class usbAEhardware  *hardware;
    hardware = (usbAEhardware*)pParam;
#endif
#endif

	UCHAR* recvbuffer[MAX_CARDNUM];

	UCHAR* recvSwap = new UCHAR[BLOCK_BUFFER_SUM_SIZE];

	int i;
	for(i=0; i < MAX_CARDNUM; i++)
		if(hardware->bDeviceOpenFlag[i])
			recvbuffer[i]= new UCHAR[BLOCK_BUFFER_SUM_SIZE];
        else
            recvbuffer[i] = NULL;
	UCHAR bufOutput[33];

    bufOutput[0] = 4 ;									//������
#ifdef SINGLE_POINT_OPTIM
    USBWriteEP(0,1,5,bufOutput);
#else
    USBWriteEP(0,0,5,bufOutput);
#endif
   
	hardware->ThreadStatus = 1;

#ifdef SPEED_STATISTICS_DEBUG
    DWORD start, end;
//     unsigned __int64 total_bytes = 0;
    double total_bytes = 0;
    start = GetTickCount();
#endif

    //������а忨�Ƿ��
    UINT nOpenedDevNum = 0;
    for (i = 0; i < MAX_CARDNUM; i++)
    {
        if (hardware->bDeviceOpenFlag[i])
        {
            nOpenedDevNum++;
        }
    }
    if (nOpenedDevNum == 0)
    {
        hardware->ThreadStatus = 2;
        return 0;
    }

    USBReadDataFuncPtr USBReadData;

//     if (hardware->m_DriverVersion.MajorVersion > EZUSB_MAJOR_VERSION)
//     {
//         USBReadData = USBReadBulk;
//     }
//     else
    {
        USBReadData = USBReadEP_ASY;
    }


// 	int firsthalf_OpenCardNum = 0;
// 	int secondhalf_OpenCardNum = 0;
	for(i=0; i < MAX_CARDNUM; i++)
	{
		if(hardware->bDeviceOpenFlag[i] == FALSE)
			continue;
// 		if (i<MAXIMUM_WAIT_OBJECTS)
// 			firsthalf_OpenCardNum++;
// 		else
// 			secondhalf_OpenCardNum++;
		//   hardware->ReadRegister(i,0x6,&regvalue);
#ifdef SINGLE_POINT_BUS_INTERFACE
#ifdef SINGLE_POINT_OPTIM
		USBReadData(i / MAX_CARD_NUM_PER_CHASSIS,0,BLOCK_BUFFER_SUM_SIZE,recvbuffer[i],&(hardware->ovRead[i / MAX_CARD_NUM_PER_CHASSIS]));
#else
		USBReadData(i / MAX_CARD_NUM_PER_CHASSIS,3,BLOCK_BUFFER_SUM_SIZE,recvbuffer[i],&(hardware->ovRead[i / MAX_CARD_NUM_PER_CHASSIS]));
#endif
#else
		USBReadData(i,3,BLOCK_BUFFER_SUM_SIZE,recvbuffer[i],&(hardware->ovRead[i]));
#endif
	}
	int offset = 0;
	while(hardware->ThreadFlag)
	{
		if (nOpenedDevNum <= MAXIMUM_WAIT_OBJECTS)
		{
			DWORD dwEvent = WaitForMultipleObjects(nOpenedDevNum,hardware->hEventArray+offset,FALSE,1000);
			DWORD m_error = GetLastError();
			int i = (dwEvent - WAIT_OBJECT_0 + offset)%nOpenedDevNum;
			if (dwEvent >= WAIT_OBJECT_0 && dwEvent < WAIT_OBJECT_0+nOpenedDevNum)
			{
				BOOL IOComplete = GetOverlappedResult(GetUSBDevByID(hardware->EventIndexTOCardIndex[i]),
					&hardware->ovRead[hardware->EventIndexTOCardIndex[i]],&recvcount,FALSE);
				ResetEvent(hardware->hEventArray[i]);
				offset = (i+1)%nOpenedDevNum;
				i = hardware->EventIndexTOCardIndex[i];
#ifdef SPEED_STATISTICS_DEBUG
           if( recvcount != 0xFFFFFFFF)
           {
               total_bytes += recvcount;           
           }
#endif
		   if( recvcount == 0xFFFFFFFF || recvcount / BLOCK_SIZE < 1)
		   {
               USBReadData(i,3,BLOCK_BUFFER_SUM_SIZE,recvbuffer[i],&(hardware->ovRead[i]));
               continue;
		   }
		        memcpy(recvSwap, recvbuffer[i],recvcount); 
				USBReadData(i,3,BLOCK_BUFFER_SUM_SIZE,recvbuffer[i],&(hardware->ovRead[i]));
				hardware->AnalysisPacket(i,recvSwap,recvcount);	
				
			}
		}
		else
		{
			DWORD dwEvent = WaitForMultipleObjects(MAXIMUM_WAIT_OBJECTS,hardware->hEventArray+offset,FALSE,1000);
			DWORD m_error = GetLastError();
			int i = (dwEvent - WAIT_OBJECT_0 + offset)%nOpenedDevNum;
			if (dwEvent >= WAIT_OBJECT_0 && dwEvent < WAIT_OBJECT_0+MAXIMUM_WAIT_OBJECTS)
			{
				BOOL IOComplete = GetOverlappedResult(GetUSBDevByID(hardware->EventIndexTOCardIndex[i]),
					&hardware->ovRead[hardware->EventIndexTOCardIndex[i]],&recvcount,FALSE);
				ResetEvent(hardware->hEventArray[i]);
				offset = (i+1)%nOpenedDevNum;
				i = hardware->EventIndexTOCardIndex[i];
				if( recvcount == 0xFFFFFFFF || recvcount / BLOCK_SIZE < 1)
				{
					USBReadData(i,3,BLOCK_BUFFER_SUM_SIZE,recvbuffer[i],&(hardware->ovRead[i]));
					continue;
				}
				memcpy(recvSwap, recvbuffer[i],recvcount); 
				USBReadData(i,3,BLOCK_BUFFER_SUM_SIZE,recvbuffer[i],&(hardware->ovRead[i]));
				hardware->AnalysisPacket(i,recvSwap,recvcount);	

				//hardware->AnalysisPacket(i,recvbuffer[i],recvcount);				
                //USBReadData(i,3,BLOCK_BUFFER_SUM_SIZE,recvbuffer[i],&(hardware->ovRead[i]));
			}
		}
		
	}
	
	for(i=0; i < nOpenedDevNum; i++)
	{
		if (WAIT_OBJECT_0 != WaitForSingleObject(hardware->hEventArray[i],1000))
			continue;
		BOOL IOComplete = GetOverlappedResult(GetUSBDevByID(hardware->EventIndexTOCardIndex[i]),
			&hardware->ovRead[hardware->EventIndexTOCardIndex[i]],&recvcount,FALSE);
		ResetEvent(hardware->hEventArray[i]);
		hardware->AnalysisPacket(hardware->EventIndexTOCardIndex[i],recvbuffer[hardware->EventIndexTOCardIndex[i]],recvcount);	
	}

#ifdef SPEED_STATISTICS_DEBUG
    end = GetTickCount();

    SYSTEMTIME tm;
    GetLocalTime(&tm);

	char* pFileName = "statistic.txt";
    FILE* fp = fopen(pFileName, "ab+");
    
    fseek(fp, 0, SEEK_END);

    if (end != start)
    {
        fprintf(fp, "%d/%d/%d %d:%d:%d cost = %d ms speed = %f Mbytes\n", tm.wYear, tm.wMonth, tm.wDay,
            tm.wHour, tm.wMinute, tm.wSecond, end - start, total_bytes * 1000 / (end - start) / 1024 / 1024);
    }
    else
    {
        fprintf(fp, "%d/%d/%d %d:%d:%d cost = %d ms speed = %f Mbytes\n", tm.wYear, tm.wMonth, tm.wDay,
            tm.wHour, tm.wMinute, tm.wSecond, 0, 0);
    }    
	fprintf(fp,"\r\n");
	fclose(fp);
#endif
	hardware->ThreadStatus = 2;
	for (i=0;i<MAX_CARDNUM;i++)
		if(hardware->bDeviceOpenFlag[i])
			if (recvbuffer[i])
				delete []recvbuffer[i];
    delete[] recvSwap;
	return 0;
}

//д����Ĵ���
#ifdef _DEBUG
__declspec(dllexport) void _stdcall WriteMainboardRegister(short ChassisId,UCHAR addr, UINT value)
#else
void WriteMainboardRegister(short ChassisId,UCHAR addr, UINT value)
#endif // _DEBUG
{
#ifdef SINGLE_POINT_BUS_INTERFACE
    short chassis, card;
    chassis = ChassisId;// / MAX_CARD_NUM_PER_CHASSIS;
    //card = ChassisId % MAX_CARD_NUM_PER_CHASSIS;
    
    UCHAR bufOutput[33];
    
    memset(&bufOutput,0,sizeof(bufOutput));
    bufOutput[0] = 10 ;					// USB��������
    bufOutput[1]  = 1 ;					// FPGA��������
    bufOutput[2]  = addr;		        // �Ĵ�����ַ
    
    char *valuebuf =(char*)&value;
    
    bufOutput[3] = valuebuf[3];
    bufOutput[4] = valuebuf[2];
    bufOutput[5] = valuebuf[1];
    bufOutput[6] = valuebuf[0];
    
    bufOutput[1] |= 0x80;   //����Ϊ�����߰�Ĵ�������
#ifdef SINGLE_POINT_OPTIM
    USBWriteEP(chassis,1,33,bufOutput);	
#else
    USBWriteEP(chassis,0,33,bufOutput);	
#endif
    
#ifdef FPGA_VERSION_1_3
    // 	if(addr == 0 && ((*(unsigned long *)&bufOutput[3]) | (~RESET_MAINBOARD)) == (~RESET_MAINBOARD)) {
    // 		bufOutput[0] = 3 ;
    // 		bufOutput[7] = 0 ;							// reset fifo
    // 	#ifdef SINGLE_POINT_OPTIM
    // 		USBWriteEP(chassis,1,8,bufOutput);
    // 	#else
    // 		USBWriteEP(chassis,0,8,bufOutput);
    // 	#endif
    //     }
#else
    if(addr == 0 && (*(unsigned long *)&bufOutput[3] == 0) ) {
        bufOutput[0] = 3 ;
        bufOutput[7] = 0 ;							// reset fifo
#ifdef SINGLE_POINT_OPTIM
        USBWriteEP(chassis,1,8,bufOutput);
#else
        USBWriteEP(chassis,0,8,bufOutput);
#endif
    }
#endif
#else
    return;
#endif
}

//������Ĵ���
#ifdef _DEBUG
__declspec(dllexport) void _stdcall ReadMainboardRegister(short ChassisId, UCHAR addr, UINT *value)
#else
void ReadMainboardRegister(short ChassisId, UCHAR addr, UINT *value)
#endif
{
#ifdef SINGLE_POINT_BUS_INTERFACE
    short chassis, card;
    chassis = ChassisId;// / MAX_CARD_NUM_PER_CHASSIS;
    //card = ChassisId % MAX_CARD_NUM_PER_CHASSIS;
    
    UCHAR bufOutput[33];
    
    memset(&bufOutput,0,sizeof(bufOutput));	
    
    bufOutput[0] = 13 ;
    bufOutput[1] = 2 ;
    bufOutput[2] = addr;
    
    bufOutput[1] |= 0x80;   //����Ϊ�����߰�Ĵ�������
#ifdef SINGLE_POINT_OPTIM
    USBWriteEP(chassis,1,10,bufOutput);
#else
    USBWriteEP(chassis,0,10,bufOutput);
#endif
    
    USBReadEP(chassis,2,4,bufOutput);
    *value = *(UINT *)&bufOutput[0];
#else
    return;
#endif
}

UCHAR GetCardNumberNo(unsigned short index)
{
    UCHAR	bufInput[64],bufOutput[33];
    UCHAR   m_CardAddr;
    
    if(index >= MAX_CARDNUM)
        return FALSE;
#ifdef BGA_18BITS_40M_VERSION
#ifdef BGA_18BITS_HUB_NEW
    CARD_ID_STAT CardId;
#ifdef SOCKET_VERSION
    usbAEhardware::ReadRegister(index, CARD_NO_REG, (UINT*)(&CardId.cmd));
#else
	for (int i = 0; i < 63; i++)//zch_2012_03_09 HUB18��FPGA����Ҳ�����˿��ŵ�ƫ�ƣ����Զ����Ų���ֻ��
	{	
		memset(&bufOutput,0,sizeof(bufOutput));			
		bufOutput[0] = 13 ;
		bufOutput[1] = 2 | (i << 2);
		bufOutput[2] = CARD_NO_REG;	
		USBWriteEP(index,0,10,bufOutput);		
		USBReadEP(index,2,4,bufOutput);		
		CardId = *(CARD_ID_STAT *)&bufOutput[0];
		if (CardId.spec.CardNo != 63)
			break;
	}
#endif
    return (CardId.spec.CardNo);
#else
    UINT val;
    usbAEhardware::ReadRegister(index, AE_CARDID_REG, &val);
    return (val & 0xFF);
#endif
#else
    bufOutput[0] = 9 ;
    USBWriteEP(index,0,1,bufOutput);
    
    USBReadEP(index,2,16,bufInput);
    m_CardAddr = bufInput[0] ;                 // from 51
#endif

#ifdef BGA_16BITS_10M_NEW_VERSION
	BUS_BOARD_ID_STAT RegVal;
	RegVal.cmd = 0;
	UsbaeHardware16BitNew::ReadRegister(index, CHASSIS_NO_REG, (unsigned int*)&RegVal.cmd);
	if (RegVal.cmd != 0xffffffff)
	{
		switch(RegVal.spec.SlotNum)
		{
		case 3:
			m_CardAddr += RegVal.spec.ChassisNo * 15;	//0x3 ʮ��ͨ��
			break;
		case 2:
			m_CardAddr += RegVal.spec.ChassisNo * 10;	//0x2 ʮͨ��������
			break;
		default:
			m_CardAddr += RegVal.spec.ChassisNo * 15;
			break;
		}
	}
	
#endif
    return m_CardAddr;
}

//��û����
BOOL GetChassisNo(unsigned short index, PUCHAR pChassisNo)
{
#ifdef SINGLE_POINT_BUS_INTERFACE
    UINT val = 0;
    
    if(index >= MAX_CHASSIS) {
        return FALSE;
    }
    
#ifdef FPGA_VERSION_1_3
    //��ѯ���߰�PID
    ReadMainboardRegister(index, MB_PID_REG, &val);
    
    if (GET_PID(val) != MB_PRODUCT_ID)
    {
        return FALSE;
    }
    //���߰�����λ
    WriteMainboardRegister(index, MB_CTRL_REG, 0);
    //�������߰�����λ
    WriteMainboardRegister(index, MB_CTRL_REG, 0x01);
    
    *pChassisNo = MB_GET_CHASSIS_NO(val);
#else
    //��λ���߰�
    //     UCHAR bufOutput[32];
    //     bufOutput[0] = 11 ;				//RST_FPGA
    //     USBWriteEP(index, 0, 8, bufOutput);
    //     bufOutput[0] = 12 ;
    //     USBWriteEP(index, 0, 8, bufOutput);
    
    ReadMainboardRegister(index, MB_CTRL_REG, &val);
    
    *pChassisNo = val >> 30;
#endif
    
    return TRUE;
#else
    return FALSE;
#endif
    
}

BOOL SetCardNumberNo(unsigned short index, UCHAR CardNO)
{
    UCHAR	bufOutput[33];
    
    if(index >= MAX_CARDNUM)
        return FALSE;
    memset(&bufOutput,0,sizeof(bufOutput));
#ifdef BGA_16BITS_10M_NEW_VERSION
	

	bufOutput[0] = 10 ;					// USB��������
	bufOutput[1]  = 1;					// FPGA��������
	bufOutput[2]  = 0x77;		        // �Ĵ�����ַ
	
	char *valuebuf =(char*)&CardNO;
    
	bufOutput[3] = valuebuf[3];
	bufOutput[4] = valuebuf[2];
	bufOutput[5] = valuebuf[1];
	bufOutput[6] = valuebuf[0];
	
    USBWriteEP(index,0,33,bufOutput);	
#else

    bufOutput[0] = 10 ;					// USB��������
    bufOutput[1]  = 3 ;					// FPGA�������� 1: write, 2, read,3, cardno
    bufOutput[2]  = CardNO;		        // card adress
    
    USBWriteEP(index,0,33,bufOutput);	 // set address to FPGA
#endif
    return TRUE;
    
}
