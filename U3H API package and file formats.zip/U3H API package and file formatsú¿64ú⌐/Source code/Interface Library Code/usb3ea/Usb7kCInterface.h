// interface.h - device interface classes for USB7310

// This GUID identifies the device interface class used by the USB700 device

// TODO:	If your driver supports a standard interface, use the GUID that identifies
//			the interface class, rather than using the one defined below

#define USB7kC_CLASS_GUID \
 { 0x4ed68d40, 0x22f3, 0x11d7, { 0xb8, 0x79, 0x0, 0x50, 0xcf, 0x0, 0x52, 0xc8 } }
//   { 0x36fc9e60, 0xc465, 0x11cf, { 0x80, 0x56, 0x44, 0x45, 0x53, 0x54, 0x0, 0x0 } }     //CYUSB
