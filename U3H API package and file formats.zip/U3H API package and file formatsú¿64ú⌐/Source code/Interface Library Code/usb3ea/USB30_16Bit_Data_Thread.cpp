// WLan_DataSocket_Thread.cpp : implementation file
//
#pragma once

#include "USB30_16Bit_Data_Thread.h"
#include "WAEDrive_USB30_16Bit.h"
#include "Usb7kC.h"
//#include "hardware.h"
using namespace Usb7kCio_USB3016Bit;


// CUSB30_16Bit_Data_Thread


CUSB30_16Bit_Data_Thread::CUSB30_16Bit_Data_Thread(CWAEDrive_USB30_16Bit* pDirve)
{
	m_pDrive = pDirve;
	m_hEventArray = NULL;
	m_ppOvReads = NULL;
	m_pCardNos = NULL;
	m_nOpenedDevNum = 0;
	m_offsetEvent = 0;
	m_hThread = NULL;

}
CUSB30_16Bit_Data_Thread::CUSB30_16Bit_Data_Thread()
{
	m_pDrive = NULL;
	m_hEventArray = NULL;
	m_ppOvReads = NULL;
	m_pCardNos = NULL;
	m_nOpenedDevNum = 0;
	m_offsetEvent = 0;
	m_hThread = NULL;
}

CUSB30_16Bit_Data_Thread::~CUSB30_16Bit_Data_Thread()
{
	if( m_hThread )		
		KillThread( FALSE );
	ClearBuffer();
	for (int i = 0; i < m_nOpenedDevNum; i++)
	{
		if(m_dataOvLaps)
		{
			delete[] m_dataOvLaps;
			m_dataOvLaps = NULL;
		}
	}
}

BOOL CUSB30_16Bit_Data_Thread::InitInstance()
{
	while (WaitForSingleObject(m_hEventKill, 0) == WAIT_TIMEOUT)
		DoWork();

	return FALSE;
}

int CUSB30_16Bit_Data_Thread::ExitInstance()
{
	return 0;
}



static  FILE* g_debugfile = NULL;
// CUSB30_16Bit_Data_Thread message handlers

void CUSB30_16Bit_Data_Thread::DoWork()
{
	if( m_pCardNos == NULL || m_hEventArray == NULL ) return;

	CHardWare_USB30_16Bit* pHardware = NULL;

	long dwRecCount = USB30_BUFFER_SIZE;


	if (m_nOpenedDevNum <= MAXIMUM_WAIT_OBJECTS && m_nOpenedDevNum > 0)
	{
		if( m_hEventArray == NULL ) return;
		DWORD dwEvent = WaitForMultipleObjects(m_nOpenedDevNum, m_hEventArray + m_offsetEvent, FALSE, 1000);
		DWORD m_error = GetLastError();
		int i = (dwEvent - WAIT_OBJECT_0 + m_offsetEvent)%m_nOpenedDevNum;
		if (dwEvent >= WAIT_OBJECT_0 && dwEvent < WAIT_OBJECT_0+m_nOpenedDevNum)
		{		
			pHardware = (CHardWare_USB30_16Bit*)m_pDrive->GetHardWare(m_pCardNos[i]);
			if( pHardware == NULL ) return;


			dwRecCount = m_dataOvLaps[i].FinishAsyReadData();

			m_offsetEvent = (i+1)%m_nOpenedDevNum;

			if( dwRecCount == 0xFFFFFFFF || dwRecCount / BLOCK_SIZE < 1)
			{
				m_dataOvLaps[i].ReadNextDataAsy();
				return;
			}

			memcpy(pHardware->m_recvbuffer, m_dataOvLaps[i].GetCurBuff(), dwRecCount);

			pHardware->OnReceiveData(NULL,dwRecCount);	
			m_dataOvLaps[i].ReadNextDataAsy();
			m_hEventArray[ i ] = m_dataOvLaps[i].GetCurEvent();
			m_hEventArray[ i + m_nOpenedDevNum ] = m_dataOvLaps[i].GetCurEvent();			
		}
	}
}

BOOL CUSB30_16Bit_Data_Thread::StartListon()
{
	if(m_pDrive == NULL) return FALSE;

	CHardWare_USB30_16Bit* pHardware = NULL;
	::EnterCriticalSection(&m_pDrive->m_csHardwareMapLock);
	m_nOpenedDevNum = 0;
	ULONG nBufferSize = 0;
	for (int j = 0; j < MAX_CARDNUM; j++)
	{		
		pHardware = (CHardWare_USB30_16Bit*)m_pDrive->m_HardWareArray[j];
		if( !pHardware ) continue;
		if(pHardware->m_dwDevStatus == USB_DEV_OPEN)
		{
			m_nOpenedDevNum++;
		}
	}
	int nGroupCount = 4;
	if( m_nOpenedDevNum < 2 )
		nGroupCount = 8;
	else if( m_nOpenedDevNum < 4 )
		nGroupCount = 4;
	else if( m_nOpenedDevNum < 8)
		nGroupCount = 2;
	else if( m_nOpenedDevNum < 12)
		nGroupCount = 1;
	else
		nGroupCount = 1;
	::LeaveCriticalSection(&m_pDrive->m_csHardwareMapLock);

	if( m_nOpenedDevNum < 1) return FALSE;
	if( m_hEventArray )
	{
		delete[] m_hEventArray;
		m_hEventArray = NULL;
	}
	if( m_pCardNos )
	{
		delete[] m_pCardNos;
		m_pCardNos = NULL;
	}
	m_hEventArray = new HANDLE[m_nOpenedDevNum * 2];
	m_pCardNos = new int[m_nOpenedDevNum];
	m_dataOvLaps = new U3016_DataOVLap[m_nOpenedDevNum];

	int i = 0;
	int nRecBuffCount = 256*1024;
	if( m_pDrive->m_bHaveStream )
		nRecBuffCount = USB30_BUFFER_SIZE;

	
	::EnterCriticalSection(&m_pDrive->m_csHardwareMapLock);
	for (int j = 0; j < MAX_CARDNUM; j++)
	{		
		pHardware = (CHardWare_USB30_16Bit*)m_pDrive->m_HardWareArray[j];
		if( !pHardware ) continue;
		if(pHardware->m_dwDevStatus == USB_DEV_OPEN)
		{
			m_dataOvLaps[i].m_nCardNo = pHardware->m_dwCardNo;
			m_dataOvLaps[i].m_nRecBuffCount = nRecBuffCount;
			m_dataOvLaps[i].SetGroupCount(nGroupCount);			
			m_hEventArray[i] = m_dataOvLaps[i].GetCurEvent();
			m_pCardNos[i] = (short)pHardware->m_dwCardNo;	
			m_hEventArray[i + m_nOpenedDevNum] = m_dataOvLaps[i].GetCurEvent();

			i++;
		}
	}
	::LeaveCriticalSection(&m_pDrive->m_csHardwareMapLock);
	
	for (int k = 0; k < 8; k++)
	{
		for (int j = 0; j < m_nOpenedDevNum; j++ )
		{
			m_dataOvLaps[j].ReadAllDataAsy(k);
		}
	}

	m_offsetEvent = 0;
	

	// Create Thread in a suspended state so we can set the Priority
	// before it starts getting away from us
	if( !m_hThread )
	{
		if (!CreateThread(CREATE_SUSPENDED))
			return FALSE;
		// If you want to make the sample more sprightly, set the thread priority here
		// a little higher. It has been set at idle priority to keep from bogging down
		// other apps that may also be running.
		::SetThreadPriority(m_hThread, THREAD_PRIORITY_ABOVE_NORMAL);
		// Now the thread can run wild
	}


	ResumeThread();

    return TRUE;
}
BOOL CUSB30_16Bit_Data_Thread::StopListon()
{
	if( m_hEventArray != NULL)
	{
		delete[] m_hEventArray;
		m_hEventArray = NULL;
	}	
	if( m_pCardNos != NULL)
	{
		delete[] m_pCardNos;
		m_pCardNos = NULL;
	}	
	for (int i = 0; i < m_nOpenedDevNum; i++)
	{
		m_dataOvLaps[i].StopReadData();
	}

	//���� ��������������
	//if(m_hThread)
	//	SuspendThread();
	return TRUE;
}

void CUSB30_16Bit_Data_Thread::ClearBuffer()
{
	if(m_hEventArray)
	{
		delete[] m_hEventArray;
		m_hEventArray = NULL;
	}
	if(m_pCardNos)
	{
		delete m_pCardNos;
		m_pCardNos = NULL;
	}
	for (int i = 0; i < m_nOpenedDevNum; i++)
	{
		m_dataOvLaps[i].StopReadData();
	}
}


void U3016_DataOVLap::SetGroupCount(int nCount)
{
	if( nCount < 1 || nCount > 8 ) return;
	char tempStr[20];
	for (int i = 0; i < nCount; i++)
	{
		sprintf_s(tempStr, "CardEvent%02d_%02d\0", m_nCardNo, i);
		m_hEvents[i] = CreateEvent(NULL, TRUE, FALSE, tempStr);
		m_ovReadDatas[i].hEvent = m_hEvents[i];
		if(m_recvbuffers[i] == NULL)			
			m_recvbuffers[i] = new UCHAR[USB30_BUFFER_SIZE];
	}
	m_nCurIndex = 0;
	m_nGroupCount = nCount;
}

 void U3016_DataOVLap::ReadAllDataAsy(int nIndex/* = 0*/)
 {
	 if( nIndex >= m_nGroupCount ) return;
	 m_pXmitBufs[nIndex] = USBReadEP_ASY(m_nCardNo,0x82,m_nRecBuffCount,  m_recvbuffers[nIndex], &(m_ovReadDatas[nIndex]));
 }

 void U3016_DataOVLap::ReadNextDataAsy()
 {
	 if( m_nGroupCount < 1 || m_nGroupCount > 8 ) return;
	m_pXmitBufs[m_nCurIndex] = USBReadEP_ASY(m_nCardNo,0x82,m_nRecBuffCount,  m_recvbuffers[m_nCurIndex], &(m_ovReadDatas[m_nCurIndex]));
	if( m_nCurIndex < m_nGroupCount -1)
		m_nCurIndex++;
	else
		m_nCurIndex = 0;	
 }

 LONG U3016_DataOVLap::FinishAsyReadData()
 {
	 if( m_nGroupCount < 1 || m_nGroupCount > 8 ) return 0;
	 long dwRecCount = m_nRecBuffCount;
	 FinishReadData(m_nCardNo,0x82,dwRecCount, m_recvbuffers[m_nCurIndex], &(m_ovReadDatas[m_nCurIndex]), m_pXmitBufs[m_nCurIndex]);
	 

	 ResetEvent(m_hEvents[m_nCurIndex]);
	 return dwRecCount;
 }

  void  U3016_DataOVLap::StopReadData()
  {
	  if( m_nGroupCount < 1 || m_nGroupCount > 8 ) return;

	  for (int i = 0; i < m_nGroupCount; i++)
	  {	
		  if(m_hEvents[i]!= NULL)
		  {
			  CloseHandle(m_hEvents[i]);
			  m_hEvents[i] = NULL;
			  m_ovReadDatas[i].hEvent = NULL;
		  }
	  }
	  m_nCurIndex = 0;
  }

  void  U3016_DataOVLap::Abort()
  {
		AbortReset(m_nCardNo);
  }


  