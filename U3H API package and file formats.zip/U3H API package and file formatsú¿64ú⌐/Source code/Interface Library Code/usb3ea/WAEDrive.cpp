// WAEDrive.cpp : implementation file
//


#include "WAEDrive.h"
#include "DriveDataDefine.h"
#include "atltime.h"
// CWAEDrive
//CEvent CWAEDrive::g_ParamDataEvent(FALSE,TRUE);
//CEvent CWAEDrive::g_WaveDataEvent(FALSE,TRUE);
//CEvent CWAEDrive::g_FFTDataEvent(FALSE,TRUE);
CWAEDrive::CWAEDrive()
{
	m_dwLostDataCount = 0;
	m_dLostDataVec = 0;
	m_dwRecDataCount = 0;	
	m_dwRecCmdCount = 0;	
	m_dwSendCmdCount = 0;
	m_dRecDataVec = 0;
	m_dRecDataAVec = 0;
	m_dwLastDataCount = 0;	
	m_dwLastDataCountTick = 0;
	m_dwFirstDataTick = 0;

	//m_hDataEvent = NULL;

	m_llParamPreSysTime = 0;

	m_dwSampleStatus = SAMPLESTOP;
	m_dwCurParamCount = 0;
	m_dwCurWaveCount = 0;
	m_dwCurFFTCount = 0;

	m_dwRecParamIndex = 0; 
	m_dwRecWaveIndex = 0;  
	m_dwRecFFTIndex = 0;  
	//m_pSaveParamThread = NULL;
	//m_pSaveWaveThread = NULL;
	m_dwDriveType = 0;

	for ( int i = 0; i< MAX_CARDNUM; i++)
	{
		m_HardWareArray[i] = NULL;
	}
	m_nStepByStep = 0xFFFFFFFF;
	m_bInitialized = FALSE;
	memset(m_exParamBuf, 0, 12 * sizeof(short));
	GetLocalTime(&m_SampleStartTime);

	::InitializeCriticalSection(&m_csHardwareMapLock);
	::InitializeCriticalSection(&m_csParamData);
	::InitializeCriticalSection(&m_csWaveData);
	::InitializeCriticalSection(&m_csFFTData);
	::InitializeCriticalSection(&m_csCountLock);
	
}

CWAEDrive::~CWAEDrive()
{
	::DeleteCriticalSection(&m_csHardwareMapLock);
	::DeleteCriticalSection(&m_csParamData);
	::DeleteCriticalSection(&m_csWaveData);
	::DeleteCriticalSection(&m_csFFTData);
	::DeleteCriticalSection(&m_csCountLock);
}


// CWAEDrive member functions

CWAE_HardWare::CWAE_HardWare( DWORD chanCount/* =1*/)
{ 
	m_pChannels=NULL; 
	m_iChanCount = 0;
	m_pDriver = NULL;
	SetChanCount(chanCount);
}
void	CWAE_HardWare::SetChanCount(DWORD dwChanCount)
{
	if( m_pChannels )
	{
		delete[] m_pChannels;
		m_pChannels = NULL;
		m_iChanCount = 0;
	}
	m_pChannels = new CWAE_Channel[dwChanCount];
	m_iChanCount = dwChanCount;
}
void CWAE_HardWare::ClearChanBuff()
{
	if( m_pChannels )
		delete[] m_pChannels;
}

BOOL CWAE_HardWare::IsUsed()
{
	for (int i = 0; i< m_iChanCount; i++)
	{
		if( m_pChannels[i].m_bWaveEnable || m_pChannels[i].m_bParamEnable)
			return TRUE;
	}
	return FALSE;
}

void CWAE_HardWare::SetSampleLength( DWORD dwLength )
{
	//m_paramFIFO.ReleaseBuf();
	//m_waveFIFO.ReleaseBuf();
	//m_paramFIFO.AllocateBuf(20000);
	m_waveFIFO.SetWaveDataSize(dwLength * 2 + 48 );
	for (int i = 0; i< m_iChanCount; i++)
	{
		m_pChannels[i].m_dwSampleLength = dwLength;
	}
}

void CWAE_HardWare::ClearBuffData()
{
	m_paramFIFO[0].ClearData();
	m_paramFIFO[1].ClearData();
	m_waveFIFO.ClearData();
}

//���ݵ���ʱ��������ʱ��
void CWAE_HardWare::GetArriveTime(SYSTEMTIME *arrivetime, SYSTEMTIME *starttime,unsigned __int64 curdiff0)
{
	if( arrivetime == NULL || starttime  == NULL ) 
		return;

	//// Edited by mengliang 2014-1-13
	// purpose: ԭ�����㷨�����⣬���ֻ�ܱ�ʾ48Сʱ֮�ڵ����ڣ�Ӳ��֧��325��
	curdiff0 = curdiff0/1000000;//����	
	LONG dwSeconds = curdiff0 / 1000;//��
	if( curdiff0 % 1000  + starttime->wMilliseconds >= 1000)
		dwSeconds = 1;
	else
		dwSeconds = 0;

	memcpy(arrivetime,starttime,sizeof(SYSTEMTIME));
	 	
	DWORD ii = (DWORD)(curdiff0/3600000);//3600000��һСʱ�ĺ�����,ii�ǽ�����תΪСʱ
	if(ii){
	 	arrivetime->wHour += ii;
	 	if(arrivetime->wHour >= 24) {
	 		arrivetime->wHour %= 24;
	 		arrivetime->wDay ++;
	 	}
	}
	 	
	DWORD curdiff = (DWORD)(curdiff0%3600000);//��СʱĦ��
	ii = curdiff/60000;//����
	if(ii)	{
	 	arrivetime->wMinute += ii;
	 	if(arrivetime->wMinute >= 60)	{
	 		arrivetime->wMinute %= 60;
	 		arrivetime->wHour++;
	 		if(arrivetime->wHour >= 24)	{
	 			arrivetime->wHour %= 24;
	 			arrivetime->wDay ++;
	 		}
	 	}
	}
	 	
	curdiff = curdiff%60000;//������Ħ��
	 	ii = curdiff/1000;//��
	 	if(ii)	{
	 	arrivetime->wSecond += ii;
	 	if(arrivetime->wSecond >= 60)	{
	 		arrivetime->wSecond %= 60;
	 		arrivetime->wMinute++;
	 		if(arrivetime->wMinute >= 60)	{
	 			arrivetime->wMinute %= 60;
	 			arrivetime->wHour++;
	 			if(arrivetime->wHour >= 24)	{
	 				arrivetime->wHour %= 24;
	 				arrivetime->wDay ++;
	 			}
	 		}
	 	}
	}
	 		
	curdiff = curdiff%1000;
	arrivetime->wMilliseconds += (unsigned short)curdiff;
	if(arrivetime->wMilliseconds >= 1000)	{
	 	arrivetime->wMilliseconds %= 1000;
	 	arrivetime->wSecond++;
		arrivetime->wSecond += dwSeconds;
	 	if(arrivetime->wSecond >= 60)	{
	 		arrivetime->wSecond %= 60;
	 		arrivetime->wMinute++;
	 		if(arrivetime->wMinute >= 60)	{
	 			arrivetime->wMinute %= 60;
	 			arrivetime->wHour++;
	 			if(arrivetime->wHour >= 24)	{
	 				arrivetime->wHour %= 24;
	 				arrivetime->wDay ++;
	 			}
	 		}
	 	}
	}

}    




DWORD CWAEDrive::GetWaveDataFromBuf(char *pBuf, DWORD& dwDataSize)
{
	if( pBuf == NULL ) return 0;

	ULONGLONG llWaveCurSysTime = 0;
	DWORD nMaxBuffer = dwDataSize;
	dwDataSize = 0;
	DWORD retnlength =0;
	::EnterCriticalSection(&m_csWaveData);
	DWORD curWaveBufLength = 0;
	DWORD dwBuffIndex = 0;
	COMWAVEDATA* pData = NULL;

	CWAE_HardWare* pHardware = NULL;

	::EnterCriticalSection(&m_csHardwareMapLock);	
	for (int i = 0; i< MAX_CARDNUM; i++)
	{	
		pHardware = m_HardWareArray[i];
		if(pHardware)
		{
			curWaveBufLength += pHardware->m_waveFIFO.GetDataLength();
			if (pHardware->m_waveFIFO.GetSysTime() > llWaveCurSysTime)
				llWaveCurSysTime = pHardware->m_waveFIFO.GetSysTime();

		}
	}


	//if(curWaveBufLength > 100 || (llWaveCurSysTime + m_llWaveTimeAdjust + PARAM_OUTPUT_DELAY < m_llWavePreSysTime ) || (m_dwDriveType > REPLAYSTART))
	{
		ULONGLONG tempTime = 0;
		if (m_dwSampleStatus == SAMPLEING)
		{
			for (int i = 0; i< MAX_CARDNUM; i++)	
			{	
				pHardware = m_HardWareArray[i];
				if(pHardware == NULL ) continue;
				while(pHardware->m_waveFIFO.GetDataLength() > 0 )
				{
					pHardware->m_waveFIFO.popsingle((COMWAVEDATA*)(pBuf+dwBuffIndex));
					pData = (COMWAVEDATA*)(pBuf+dwBuffIndex);					
					if( (dwBuffIndex + pHardware->m_waveFIFO.GetWaveDataSize())  < (nMaxBuffer  - pHardware->m_waveFIFO.GetWaveDataSize()))
					{
						pData->FrameNo = m_dwRecWaveIndex++;
						dwBuffIndex += pHardware->m_waveFIFO.GetWaveDataSize();
						retnlength++;	
					}
				}
			}		
		}	
	}

	::LeaveCriticalSection(&m_csHardwareMapLock);
	
	::LeaveCriticalSection(&m_csWaveData);
	dwDataSize = dwBuffIndex;
	return retnlength;
}
DWORD CWAEDrive::GetFFTDataFromBuf(char *pBuf, DWORD& dwDataSize)
{
	if( pBuf == NULL ) return 0;

	ULONGLONG llfftCurSysTime = 0;
	DWORD nMaxBuffer = dwDataSize;
	DWORD retnlength =0;
	::EnterCriticalSection(&m_csFFTData);
	DWORD curWaveBufLength = 0;
	DWORD dwBuffIndex = 0;
	COMWAVEDATA* pData = NULL;

	CWAE_HardWare* pHardware = NULL;
	::EnterCriticalSection(&m_csHardwareMapLock);

	for (int i = 0; i< MAX_CARDNUM; i++)
	{	
		pHardware = m_HardWareArray[i];
		if(pHardware)
		{
			curWaveBufLength += pHardware->m_fftFIFO.GetDataLength();
			if (pHardware->m_fftFIFO.GetSysTime() > llfftCurSysTime)
				llfftCurSysTime = pHardware->m_fftFIFO.GetSysTime();

		}
	}

	//if(curWaveBufLength > 100 ||(llfftCurSysTime <= 2000000 ) || (llfftCurSysTime > 2000000 + m_llWavePreSysTime ) || (m_dwDriveType > REPLAYSTART))
	{

		//m_llWavePreSysTime = llfftCurSysTime;

		DWORD dwTime = GetTickCount();

		ULONGLONG tempTime = 0;
		if (m_dwSampleStatus == SAMPLEING)
		{
			while ((tempTime + PARAM_OUTPUT_DELAY) < llfftCurSysTime || (m_dwDriveType > REPLAYSTART))
			{
				tempTime = PARAM_TIME_MASK;
				CWAE_HardWare* pTempHardware = NULL;

				for (int i = 0; i< MAX_CARDNUM; i++)
				{	
					pHardware = m_HardWareArray[i];
					if(pHardware == NULL) continue;
					if( pHardware->m_fftFIFO.ArriveTime < tempTime)
					{
						pTempHardware = pHardware;
						tempTime = pHardware->m_fftFIFO.ArriveTime;
					}
				}
				if (pTempHardware)
				{
					pTempHardware->m_fftFIFO.popsingle((COMWAVEDATA*)(pBuf+dwBuffIndex));
					pData = (COMWAVEDATA*)(pBuf+dwBuffIndex);
					pData->FrameNo = m_dwRecFFTIndex++;
					dwBuffIndex += pTempHardware->m_fftFIFO.GetWaveDataSize();
					if( retnlength < 2998)
						retnlength++;		
				}else
				{
					break;
				}		
			}
		}
		//TRACE("ticktime -------------------%d\n", GetTickCount() - dwTime);
	}
	::LeaveCriticalSection(&m_csHardwareMapLock);
	::LeaveCriticalSection(&m_csFFTData);

	return retnlength;
}

LONGLONG GetMillSecondsSpan( const SYSTEMTIME& time1, const SYSTEMTIME& time2)
{
	CFileTime myFT1, myFT2;
	CFileTimeSpan myFTS;

	SystemTimeToFileTime(&time1, &myFT1);
	SystemTimeToFileTime(&time2, &myFT2);

	// Calculate the time difference
	myFTS = myFT2 - myFT1;

	return myFTS.GetTimeSpan() / 10000;

}

DWORD CWAEDrive::GetParamDataFromBuf(char *pBuf, DWORD& dwDataSize)
{
	ULONGLONG llParamCurSysTime = PARAM_TIME_MASK;	
	DWORD retnlength =0;
	::EnterCriticalSection(&m_csParamData);
	DWORD curParaBufLength = 0;
	
	COMPARAMDATA* pData = NULL;
	CWAE_HardWare* pHardware = NULL;

	BOOL bSingleFull = FALSE;
	::EnterCriticalSection(&m_csHardwareMapLock);
	for (int i = 0; i< MAX_CARDNUM; i++)
	{	
		pHardware = m_HardWareArray[i];
		if(pHardware)
		{
			for (int j = 0; j < pHardware->m_iChanCount; j++)
			{
				if( pHardware->m_paramFIFO[j].GetDataLength() > 20000)
					bSingleFull = TRUE;
				curParaBufLength += pHardware->m_paramFIFO[j].GetDataLength();
				if (pHardware->m_paramFIFO[j].ArriveTime < llParamCurSysTime)
					llParamCurSysTime = pHardware->m_paramFIFO[j].ArriveTime;
			}
		}
	}
	if( curParaBufLength  < 1 ) 
	{
		::LeaveCriticalSection(&m_csHardwareMapLock);
		::LeaveCriticalSection(&m_csParamData);	
		return retnlength;
	}
	//����������2ÿ�βɼ�֮ǰ������ʱ��,��Ҫ��һ������,�������Ҫ�ӳٺܶ�ʱ����ܿ���
	if( m_llParamPreSysTime == 0)
	{
		//u2s,u3h����Ҫ
		//m_llParamPreSysTime = llParamCurSysTime;
	}
	SYSTEMTIME currentTime;
	GetLocalTime(&currentTime);

	LONGLONG llRealTimeSpan = GetMillSecondsSpan(m_SampleStartTime, currentTime); //ms
	//llRealTimeSpan += m_llParamPreSysTime/1000000.0;
	//TRACE("________��ǰ��������:   %.0f, %I64d, %.0f,%.0f\n", llParamCurSysTime /1000000.0, llRealTimeSpan, (llParamCurSysTime /1000000.0 + PARAM_OUTPUT_DELAY), m_llParamPreSysTime/1000000.0);
	if(bSingleFull || curParaBufLength > 150000 || (llRealTimeSpan > (llParamCurSysTime /1000000.0 + PARAM_OUTPUT_DELAY) ) || (m_dwDriveType > REPLAYSTART))
	{	

		ULONGLONG tempTime = 0;
		
		if (m_dwSampleStatus == SAMPLEING)
		{
			while ((tempTime / 1000000.0 + 100) < llRealTimeSpan || (m_dwDriveType > REPLAYSTART))
			{
				tempTime = PARAM_TIME_MASK;
				CWAE_HardWare* pTempHardware = NULL;
				int nChannel = 0;
				for (int i = 0; i< MAX_CARDNUM; i++)
				{	
					pHardware = m_HardWareArray[i];
					if( pHardware == NULL) continue;
					//TRACE("________[0].ArriveTime:  %I64d\n", pHardware->m_paramFIFO[0].ArriveTime);
					//TRACE("________[1].ArriveTime:  %I64d\n", pHardware->m_paramFIFO[1].ArriveTime);
					//TRACE("________[3].ArriveTime:  %I64d\n", pHardware->m_paramFIFO[2].ArriveTime);
					//TRACE("________[4].ArriveTime:  %I64d\n", pHardware->m_paramFIFO[3].ArriveTime);
					for (int j = 0; j < pHardware->m_iChanCount; j++)
					{
						if(pHardware->m_paramFIFO[j].ArriveTime < tempTime)
						{
							pTempHardware = pHardware;
							tempTime = pHardware->m_paramFIFO[j].ArriveTime;
							nChannel = j;
						}	
					}
					//if(pHardware->m_paramFIFO[0].ArriveTime < tempTime)
					//{
					//	pTempHardware = pHardware;
					//	tempTime = pHardware->m_paramFIFO[0].ArriveTime;
					//	nChannel = 0;
					//}
					//if(pHardware->m_paramFIFO[1].ArriveTime < tempTime)
					//{
					//	pTempHardware = pHardware;
					//	tempTime = pHardware->m_paramFIFO[1].ArriveTime;
					//	nChannel = 1;
					//}
				}
				if (pTempHardware)
				{
					
					//TRACE("POP[%d][%d].ArriveTime:  %I64d\n",m_dwRecParamIndex, pTempHardware->m_dwCardNo* 4+nChannel +1,pTempHardware->m_paramFIFO[nChannel].ArriveTime);
					pTempHardware->m_paramFIFO[nChannel].popsingle((COMPARAMDATA*)pBuf+retnlength);
					pData = (COMPARAMDATA*)pBuf+retnlength;
					pData->FrameNo = m_dwRecParamIndex++;
					//if( CWAESystemConfigManager::GetInstance().GetParamAlarmFilter().FilterPara(pData))
					//	CMy_ErrorEvent::GetInstance().FireMyError(MY_ERROR_NOTIFACATION_PARAMALARM, 
					//	"ALARM",  NULL, __FILE__, pData->FrameNo + 1);
					if( pData->ChannelId > CHSUM) 
					{
						//CString str;
						//str.Format("error, ChannelId = %d", pData->ChannelId);
						//AfxMessageBox(str);
					}
					
					if( retnlength < dwDataSize -2)
					   retnlength++;
					else
					{
							//CString str;
							//str.Format("���������", pData->ChannelId);							
							//AfxMessageBox(str);
					}
				}else
				{
					break;
				}		
			}
		}
		//TRACE("ticktime -------------------%d\n", GetTickCount() - dwTime);
	}
	::LeaveCriticalSection(&m_csHardwareMapLock);
	::LeaveCriticalSection(&m_csParamData);
	return retnlength;
}

BOOL CWAEDrive::SetCurParamCount( DWORD dwCount )
{ 
	::EnterCriticalSection(&m_csCountLock);
	m_dwCurParamCount = dwCount;
	::LeaveCriticalSection(&m_csCountLock);
	return TRUE;
}
BOOL CWAEDrive::SetCurWaveCount( DWORD dwCount )
{ 
	::EnterCriticalSection(&m_csCountLock);
	m_dwCurWaveCount = dwCount;
	::LeaveCriticalSection(&m_csCountLock);
	return TRUE;
}
BOOL CWAEDrive::SetCurFFTCount( DWORD dwCount )
{ 
	::EnterCriticalSection(&m_csCountLock);
	m_dwCurFFTCount = dwCount;
	::LeaveCriticalSection(&m_csCountLock);
	return TRUE;
}	

BOOL CWAEDrive::AddCurParamCount( DWORD dwCount )
{ 
	::EnterCriticalSection(&m_csCountLock);
	m_dwCurParamCount += dwCount;
	::LeaveCriticalSection(&m_csCountLock);
	return TRUE;
}
BOOL CWAEDrive::AddCurWaveCount( DWORD dwCount )
{ 
	::EnterCriticalSection(&m_csCountLock);
	m_dwCurWaveCount += dwCount;
	::LeaveCriticalSection(&m_csCountLock);
	return TRUE;
}
BOOL CWAEDrive::AddCurFFTCount( DWORD dwCount )
{ 
	::EnterCriticalSection(&m_csCountLock);
	m_dwCurFFTCount += dwCount;
	::LeaveCriticalSection(&m_csCountLock);
	return TRUE;
}	
BOOL CWAEDrive::StartSample()
{
	m_dwLostDataCount = 0;
	m_dLostDataVec = 0;
	m_dwRecDataCount = 0;	
	m_dwRecCmdCount = 0;	
	m_dwSendCmdCount = 0;
	m_dRecDataVec = 0;
	m_dRecDataAVec = 0;
	m_dwLastDataCount = 0;	
	m_dwLastDataCountTick = 0;
	m_dwFirstDataTick = 0;
	
	m_dwCurParamCount = 0;
	m_dwCurWaveCount = 0;
	m_dwCurFFTCount = 0;

	m_dwRecParamIndex = 0; 
	m_dwRecWaveIndex = 0;  
	m_dwRecFFTIndex = 0;  

	m_llParamPreSysTime = 0;

	//g_nCurTime_ns = 0;;
	//g_CurArriveTime.wYear = 0;
	//g_nCurParamNo = 0;
	//g_nCurWaveNo = 0;
	memset(m_exParamBuf, 0, 12 * sizeof(short));
	//CWAEGlobalProgressWnd::GetInstance().ShowWindow(1500);
	//CString str;
	//str.Format("���ݲɼ���ʼ��");
	//CMy_ErrorEvent::GetInstance().FireMyError(MY_ERROR_NOTIFACATION_STARTSMAPLE, 
	//	str,  NULL, __FILE__, __LINE__);
	//CWAEGlobalProgressWnd::GetInstance().CloseWindow();
	return TRUE;
}

void CWAEDrive::StopSample()
{
	//CString str;
	//str.Format("���ݲɼ�������");
	//CMy_ErrorEvent::GetInstance().FireMyError(MY_ERROR_NOTIFACATION_STOPSAMPLE, 
	//	str,  NULL, __FILE__, __LINE__);
}

int  CWAEDrive::GetInuseHwCount()
{
	if( !m_bInitialized )
		return 0;
	CWAE_HardWare* pHardware = NULL;
	int count = 0;
	for (int i = 0; i< MAX_CARDNUM; i++)
	{	
		pHardware = m_HardWareArray[i];
		if(pHardware && pHardware->IsUsed())
		{			
			count++;
		}
	}
	return count;
}