#ifndef USB7kC_h
#define USB7kC_h

#include "Usb7kCioctl.h"
#include "CyUsb\CyAPI.h"


struct ZT_PCIBOARD
{
	long lIndex;
	HANDLE hHandle;
	HANDLE hHandle_Asy;
	short nChNo;
	long  lData;
	unsigned long* plData;
	long lCode;
};

struct ZT_USBBOARD
{
	long CardNo;
	CCyUSBDevice* USBDevice;
	long Index;
};

//namespace Usb7kCio_USB20
//{
//	__declspec(dllexport)  long _stdcall OpenUSB7kC_ByCardNo(short nIndex);
//	__declspec(dllexport)  long _stdcall OpenUSB7kC(ZT_PCIBOARD* bs);
//	__declspec(dllexport)  long _stdcall OpenUSBChassis(ZT_PCIBOARD* bs);
//	__declspec(dllexport)  long _stdcall CloseUSB7kC(short nIndex);
//	__declspec(dllexport)  long _stdcall OpenUSBDev(short nIndex);
//	__declspec(dllexport)  long _stdcall CloseUSBDev(short nIndex);
//
//	__declspec(dllexport)  long _stdcall USBRead(short nIndex,short nEndpoint,short nBufOutput_num);
//	__declspec(dllexport)  long _stdcall USBWrite(short nIndex,short nEndpoint,short nBufOutput_num,unsigned char nData);
//
//	__declspec(dllexport)  long _stdcall USBReadEP_ASY(short nIndex,short nEndpoint,short nBufOutput_num,unsigned char* pData,OVERLAPPED* ovRead);
//	__declspec(dllexport)  BOOL _stdcall GetDriverVersion(short nIndex,PEZUSB_DRIVER_VERSION pDriverVersion);
//	__declspec(dllexport)  long _stdcall USBReadEP(short nIndex,short nEndpoint,short nBufOutput_num,unsigned char* pData);
//	__declspec(dllexport)  long _stdcall USBReadBulk(short nIndex,short reserved,short nBufOutput_num,unsigned char* pData,OVERLAPPED* ovRead = NULL);
//	__declspec(dllexport)  HANDLE _stdcall GetUSBDevByID(short nIndex);
//	__declspec(dllexport)  long _stdcall USBWriteEP(short nIndex,short nEndpoint,short nBufOutput_num,unsigned char* pData);
//	__declspec(dllexport)  long _stdcall StartIsoStream(short nIndex,short nEndpoint);
//	__declspec(dllexport)  long _stdcall IsoReadBuffer(short nIndex,short nEndpoint,short* nBufOutput_num,unsigned char* pData);
//	__declspec(dllexport)  long _stdcall StopIsoStream(short nIndex);
//}

//namespace Usb7kCio_USB30
//{
//	long  OpenUSB7kC_ByCardNo(short nIndex);
//	long  OpenUSB7kC(ZT_PCIBOARD* bs);
//	long  CloseUSB7kC(short nIndex);
//
//	bool  cyusb_control_xfer_synch(int index, UCHAR pipe, PUCHAR buf, LONG *len, DWORD tmo);
//	ULONG  GetXferSize(short nIndex,short nEndpoint);
//	void  SetXferSize(short nIndex,short nEndpoint, ULONG xfer);
//	PUCHAR USBReadEP_ASY(short nIndex,short nEndpoint,long nBufOutput_num,unsigned char* pData,OVERLAPPED* ovRead);
//	long  USBReadEP(short nIndex,short nEndpoint,long nBufOutput_num,unsigned char* pData);
//	HANDLE GetUSBDevByID(short nIndex);
//	long  USBWriteEP(short nIndex,short nEndpoint,long nBufOutput_num,unsigned char* pData);
//}

namespace Usb7kCio_USB3016Bit
{
	long  OpenUSB7kC_ByCardNo(short nIndex);
	long  OpenUSB7kC(ZT_USBBOARD* bs);
	long  CloseUSB7kC(short nIndex);
	BOOL AbortReset(short nIndex);
	BOOL FinishReadData(short nIndex,short nEndpoint,long& nBufOutput_num,unsigned char* pData,OVERLAPPED* ovRead, PUCHAR pXmitBuf);
	BOOL CYUSB_Control_Reset(int index, UCHAR pipe, PUCHAR buf, LONG *len, DWORD tmo);
	PUCHAR USBReadEP_ASY(short nIndex,short nEndpoint,long nBufOutput_num,unsigned char* pData,OVERLAPPED* ovRead);
	long  USBReadEP(short nIndex,short nEndpoint,long nBufOutput_num,unsigned char* pData);
	long  USBWriteEP(short nIndex,short nEndpoint,long nBufOutput_num,unsigned char* pData);
}

//}

//����������ȡUSB���ݺ���ָ��
typedef long (_stdcall *USBReadDataFuncPtr)(short nIndex,short nEndpoint,short nBufOutput_num,unsigned char* pData, OVERLAPPED* ovRead);

//����Ӳ���汾�����г��Ķ�������ͬʱֻ����һ������
//#define CONVENTIONAL_16BITS_10M_WITHOUT_FFT           //��FFT�汾���ϵ�USB�汾
//#define BGA_16BITS_10M_WITH_FFT_WIN_FUNC_SWITCH     //FFT��������ʹ�ܿ���
//#define BGA_16BITS_10M_WITHOUT_FFT_WIN_FUNC_SWITCH  //FFT������û��ʹ�ܿ���
//#define BGA_16BITS_10M_FFT_RECT_WIN_FUNC            //FFT���δ��������Ե�������
//#define BGA_18BITS_40M_VERSION //40M/18λ BGA �汾����FFT
#define BGA_16BITS_10M_NEW_VERSION					//10m/16λ BGA�汾���£����������ɼ�

#ifdef BGA_16BITS_10M_FFT_RECT_WIN_FUNC
//�������߽ӿ�ģʽ��ÿ������ֻ��һ��USB�ӿڣ������ڵİ忨ͨ���Զ�����������
//#define SINGLE_POINT_BUS_INTERFACE                       
#endif

#ifdef SINGLE_POINT_BUS_INTERFACE
#define SINGLE_POINT_OPTIM  //����ʽ�Ż�
#define FPGA_VERSION_1_3	//2011��1��20��֮����ӿ�FPGA�汾
#endif

#ifdef BGA_18BITS_40M_VERSION
#define BGA_18BITS_HUB_NEW                              //18λHUBʽ�忨�°�
#ifdef BGA_18BITS_HUB_NEW
#define SOCKET_VERSION                                  //����������
#endif
#endif

#ifdef SOCKET_VERSION
#ifndef MAX_CARDNUM
#define MAX_CARDNUM  30
#endif
#else
#ifndef MAX_CARDNUM
//#define MAX_CARDNUM  100
#define MAX_CARDNUM  32
#endif
#endif

#endif
