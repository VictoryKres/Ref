#pragma once
/********************************************************************
	created:	2013-10-12   15:36;
	filename: 	D:\DemoTest\WAECommDebugTool\WAECommDebugTool\HardDrive\WLan_DataMonitor_Thread.h;
	file path:	D:\DemoTest\WAECommDebugTool\WAECommDebugTool\HardDrive;
	file base:	WLan_DataMonitor_Thread;
	file ext:	h;
	author:		mengl;
	
	purpose:	������������ͨ��ʱ���ݼ���߳�;
*********************************************************************/
#include "windows.h"

// CMy_WorkThread



class CMy_WorkThread
{

public:
	CMy_WorkThread();
	virtual ~CMy_WorkThread();
	static unsigned __stdcall ThreadStaticEntryPoint(void* pParam);  

	
	BOOL CreateThread(DWORD dwCreateFlags = 0, UINT nStackSize = 0,
		LPSECURITY_ATTRIBUTES lpSecurityAttrs = NULL);
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	virtual void DoWork();
	virtual void KillThread( BOOL bDelete = TRUE );

public:	
	virtual void Delete();

	DWORD SuspendThread();
	DWORD ResumeThread();

public:
	HANDLE m_hEventKill;
	HANDLE m_hEventDead;
	HANDLE m_hThread;     
	DWORD m_nThreadID;      // this thread's ID
};

struct _MY_THREAD_STARTUP
{
	CMy_WorkThread* pThread;    // CWinThread for new thread
	DWORD dwCreateFlags;    // thread creation flags

	HANDLE hEvent;          // event triggered after success/non-success
	HANDLE hEvent2;         // event triggered after thread is resumed

	// strictly "out" -- set after hEvent is triggered
	BOOL bError;    // TRUE if error during startup
};

