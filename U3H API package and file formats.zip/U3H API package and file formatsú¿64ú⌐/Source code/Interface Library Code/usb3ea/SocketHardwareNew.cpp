/*******************************************************************************
                ����������ҵ�Ƽ����޹�˾��Ȩ����
********************************************************************************
  Name        : SocketHardwareNew.cpp: implementation of the SocketHardware class
  Description : �����������°�DLL����
  Author      : hegang
  Version     : V1.0
  Date        : 20130131    
  History     :
          Author          Date          Version          Content
*******************************************************************************/

/*****************************Included Declaration*****************************/
#include "SocketHardwareNew.h"
#include "../include/usb/hardware.h"
//#include "../include/common/DataType.h"
//#include "usbAEhardware.h"
//#include "Windows.h"
#include "../include/usb/usbae.h"
#include <stdio.h>

#pragma   comment(lib, "ws2_32.lib")

/*************************Extern Variables Declaration*************************/
extern unsigned long GetOneCount(unsigned long x);
/********************Local Constant & Local Type Defination********************/
//ͨ���Ĵ�������ַ��
const U32 ChRegBaseAddrs[] = {PROP_CH0_REG_BASEADDR, PROP_CH1_REG_BASEADDR, PROP_CH2_REG_BASEADDR
, PROP_CH3_REG_BASEADDR, PROP_CH4_REG_BASEADDR, PROP_CH5_REG_BASEADDR};

#define SOUNDWEL_VID        (0x01037085)
#define WIRELESS_AE_PID		(0x01063600)

//����SOCKET�˿�
#define CMD_PORT			(5001)	//����˿ڣ��Ĵ����������ö˿�
#define DATA_PORT			(5002)	//���ݶ˿ڣ������������ö˿�

#define HELLO_CMD_INDEX		(0xffff)	//HELLO��������Ϊ����0xffff
#define HELLO_CMD_CHECK1	(0x48656c6c)
#define HELLO_CMD_CHECK2	(0x65210000)
#define CMD_FLAG			(0x5753)	//�������־����

#define HELLO_DATA_INDEX	(0xffff)	//NIHAO���ݰ����Ϊ����0xffff
#define DATA_FLAG			(0x5752)	//���ݰ���־����

#define PACK_INDEX_MAX		(0xfffe)	//��������ֵ

#define COMM_TIMEOUT_MS		(2000)		//ͨ�Ų�����ʱʱ�䣬��λms
#define COMM_RETRY_NUM		(3)			//ͨ��ʧ�����Դ���

#define ALL_OPENED_DEVS		(-1)		//�����д򿪵��豸����ID��

#define SYNC_TIMEOUT_MS		(1000)		//����ͬ����ʱʱ�䣬��λms

#define PARAM_TIME_MASK     (0x0000FFFFFFFFFFFF)	//����ʱ������
#define PARAM_OUTPUT_DELAY  (1000000)				//�������������ʱʱ�� unit :100ns, according sample frequecy, namely TIME_COUNTER

//����豸����������2���豸��Ϊ����MAX_SOCKET_NUM����ϣ�Ԥ��4�����������豸����
//#define MAX_DEV_NUM		(MAX_CARDNUM - 2)
#define MAX_SOCKET_NUM	FD_SETSIZE	//���������
#define CHANNEL_NUMBER_PERCARD	1	//ÿ�����ϵ����ͨ����

/************************************************************************/
#define FIR_ORDER							63			//FIR�˲�������
#define WIN_FUNC_COEF_SIZE					1024		//������ϵ������
#define MAX_FFT_PARTIAL_POW_SEGMENTS		5			//���ֲ������׶���

#define AE_HIT_CFG_WIN_COEF_DATA_MASK		0xFFFFC00	//����������
#define	AE_HIT_CFG_FFT_DECIMATE_RATE_MASK	0xFFFF		//�źų�ȡ�ʡ����Ϊ65535����СΪ1��ע����Ҫͬ�˲������õ����

/************************************************************************/

//ͨ��״̬��
typedef enum _enumCommStatMachine
{
	enumInitCmd = 0,	//����˿ڳ�ʼ��
	enumIdleCmd,		//����˿ڿ���
	enumSendCmd,		//����˿ڷ�������
	enumGetCmd,			//����˿ڻ�������ֵ

	enumInitData,		//���ݶ˿ڳ�ʼ��
	enumGetData,		//���ݶ˿ڻ������
	
	enumCloseSocket,	//�رն˿�
} enumCommStatMachine;

//�������������
typedef enum _EnumCmdPackType
{
	enuCmdHello = 0x0,		//HELLO
	enuCmdTrans = 0x1,		//���͵������
	enuCmdRecv  = 0x2,		//���յ���������Ӧ��
} EnuCmdPackType;

//�������������
typedef enum _EnumDataPackType
{
	enuDataHello = 0x0,		//HELLO
	enuDataRecv  = 0x1,		//���յ������ݰ�
} EnumDataPackType;

#ifndef enStreamingTrigSrc
//���������ɼ�����Դ
enum enStreamingTrigSrc
{
    enStreamTrigSrcInternal = 0,//�ڲ�����
	enStreamTrigSrcExternal,    //�ⲿ����
	enStreamTrigSrcThreshold,   //���޴���
};
#endif

//���嵥Ƭ����������
enum enuMcuCmdType
{
	enuMcuCmdGpsPrepare = 0x4,		//0x4��׼��GPS�ź�״̬����
	enuMcuCmdWifiPrepare = 0x5,		//0x5��׼���豸wifi�ź�״̬����
	enuMcuCmdSync = 0x06,			//0x6���ɼ��豸��ʱͬ������
	enuMcuCmdGpsRead = 0x07,		//0x7����ȡGPS�ź�״̬����
	enuMcuCmdWifiRead = 0x08,		//0x8����ȡ�豸wifi�ź�״̬����
	enuMcuCmdWifiPowerSet = 0x9,	//0x9�������豸wifi���书������
	enuMcuCmdWriteRegister = 0x0A,	//0xA��10����дFPGA�Ĵ���
	enuMcuCmdResetFpga = 0x0B,		//0xB��11����FPGA��λ���Զ�����
	enuMcuCmdReadRegister = 0x0D,	//0xD��13������FPGA�Ĵ���
};

//����FPGA��������
enum enuFpgaCmdType
{
	enuFpgaCmdWriteRegister = 0x01,	//дFPGA�Ĵ���
	enuFpgaCmdReadRegister = 0x02,	//��FPGA�Ĵ���
};

//����������
enum enuErrCode
{
	enuOk = 0,						//������ȷ
	enuCheckError,					//���ݼ�����
	enuTransError,					//���ݷ��ʹ���
	enuRecvError,					//���ݽ��մ���
};

//����ϵͳ״̬
enum enuSysState
{
	enuSampleIdle = 0,				//ֹͣ�ɼ���ϵͳ����
	enuSamplePause,					//��ͣ�ɼ�
	enuSampling,					//���ڲɼ�
};

//��������ͨ������Ȩ��
enum enuCmdOperateAuth
{
	enuDeviceAvailable = 0,			//��ǰ���ڵ��豸
	enuDeviceEnabled,				//��ǰ�򿪵��豸
};

/*************************Local Message ID Defination**************************/
#define WM_REFRESH_INFO		(WM_USER + 100)		//ˢ����Ϣ��Ϣ

/****************************Local Macro Defination****************************/

#define IS_CLIENT_CMD_PORT(port)		((port % 2) != 0)						//�ж��Ƿ�Ϊ����˿�
#define IS_DEV_EXIST(devm, no)			(devm.pDev[no].DevNo < devm.MaxDevNum)	//�ж�ĳ�豸�Ƿ����
#define SET_DEV_UNAVAILABLE(devm, no)	(devm.pDev[no].DevNo = 0xffff)			//����ĳ�豸Ϊ������
//#define SET_PDEV_UNAVAILABLE(pdevm, no)	(pdevm->pDev[no].DevNo = 0xffff)		//����ĳ�豸Ϊ������
#define DATA_BLOCK_SIZE					(sizeof(short) * FPGA_BLOCK_DATA_LEN)	//���ݿ��С
#define CMD_PACK_LEN					(sizeof(CMD_PACK))						//���������
#define DATA_PACK_LEN					(sizeof(DATA_PACK))						//���ݰ�����
#define PARAM_NUM_IN_DATA_PACK			(sizeof(DATA_PACK) / sizeof(PARAM))		//ÿ�����ݰ��еĲ�������
#define MSGSIZE							(sizeof(DATA_PACK))						//���紫�������

//#define DEBUG_OUTPUT_FILE   //������Ϣ������ļ�
#define DEBUG_VIEW_OUTPUT	//��Debug View���������Ϣ
#ifdef DEBUG_VIEW_OUTPUT
DWORD tmStart, tmCurrent;
#endif
/**************************Local Variables Defination**************************/


/***************************Local Function Declaration*************************/
// DWORD WINAPI CmdServerThread(LPVOID lp);		//����˿ڷ����������߳�
// DWORD WINAPI DataServerThread(LPVOID lp);	//���ݶ˿ڷ����������߳�
// DWORD WINAPI WorkerThread(LPVOID lpParam);		//�ͻ�ͨ�Ź����߳�     
// DWORD WINAPI SendCmdThread(LPVOID lpParam);		//���������߳�

/***************************Local Function Prototype***************************/
/*******************************************************************************
 Function Name:	CmdServerThread
 Description  : ����˿ڼ����߳�
 Input        :	LPVOID lp  ---  ���ݲ���
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
DWORD WINAPI CmdServerThread(LPVOID lp)
{
#ifdef DEBUG_VIEW_OUTPUT
	/************************************************************************/
	char debug_str[250];
	/************************************************************************/
#endif
	SocketHardware *thiz = (SocketHardware *)lp;
	PDEV_MANAGER pdevs = &thiz->devs;
	PSOCK_MANAGER pclients = &thiz->clients;

	SOCKET sockSrvAccept = socket(AF_INET, SOCK_STREAM, 0);

	SOCKADDR_IN addrSrvAccept;

	addrSrvAccept.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
	addrSrvAccept.sin_family = AF_INET;
	addrSrvAccept.sin_port = htons(CMD_PORT);

	bind(sockSrvAccept, (SOCKADDR *)&addrSrvAccept, sizeof(SOCKADDR));

	//���� TCP_NODELAY
	BOOL bOptVal = TRUE;
    int bOptLen = sizeof (BOOL);
	int iResult = 0;
	setsockopt(sockSrvAccept, IPPROTO_TCP, TCP_NODELAY, (char *)&bOptVal, bOptLen);
	if (iResult == SOCKET_ERROR)
	{
    }

	//����������socket
	thiz->CmdSrvSocket = sockSrvAccept;

	listen(sockSrvAccept, 5);

	SOCKADDR_IN addrClientAccept;
	SOCKET sk = INVALID_SOCKET;
	int len = sizeof(SOCKADDR);

	while(thiz->bServerRun)
	{
		sk = accept(sockSrvAccept, (SOCKADDR *)&addrClientAccept, &len);
		if(sk == INVALID_SOCKET)
		{
		}
		else
		{
			//���� TCP_NODELAY
			BOOL bOptVal = TRUE;
			int bOptLen = sizeof (BOOL);
			int iResult = 0;
			setsockopt(sockSrvAccept, IPPROTO_TCP, TCP_NODELAY, (char *)&bOptVal, bOptLen);
			if (iResult == SOCKET_ERROR)
			{
		    }

			EnterCriticalSection (&thiz->SockCriticalSection);

			if (pclients->SockNum >= pclients->MaxSockNum)
			{
				closesocket(sk);
			}
			else
			{
				pclients->pSock[pclients->SockNum].sk = sk;
				pclients->pSock[pclients->SockNum].addr = addrClientAccept;
				pclients->pSock[pclients->SockNum].CommStatMach = enumInitCmd;
// 				pclients->pSock[pclients->SockNum].buf = NULL;
// 				pclients->pSock[pclients->SockNum].BufSz = 0;
				pclients->pSock[pclients->SockNum].buf = new char[DATA_PACK_LEN];
				pclients->pSock[pclients->SockNum].BufSz = DATA_PACK_LEN;
				memset(&pclients->pSock[pclients->SockNum].CmdTrans, 0, sizeof(CMD_PACK));
				memset(&pclients->pSock[pclients->SockNum].CmdRecv, 0, sizeof(CMD_PACK));
				pclients->pSock[pclients->SockNum].len = 0;
				pclients->pSock[pclients->SockNum].hCmdResponsed = CreateEvent(NULL,FALSE,FALSE,NULL);
				pclients->pSock[pclients->SockNum].ErrCode = enuOk;
				pclients->pSock[pclients->SockNum].enalbed = FALSE;
				pclients->pSock[pclients->SockNum].seq = 0;

				pclients->SockNum++;
			}

			LeaveCriticalSection (&thiz->SockCriticalSection);
		}
	}

	//closesocket(sockSrvAccept);

	return 0;
}

/*******************************************************************************
 Function Name:	DataServerThread
 Description  : ���ݶ˿ڼ����߳�
 Input        :	LPVOID lp  ---  ���ݲ���
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
DWORD WINAPI DataServerThread(LPVOID lp)
{
#ifdef DEBUG_VIEW_OUTPUT
	char debug_str[250];
#endif
	SocketHardware *thiz = (SocketHardware *)lp;
	PDEV_MANAGER pdevs = &thiz->devs;
	PSOCK_MANAGER pclients = &thiz->clients;

	SOCKET sockSrvAccept = socket(AF_INET, SOCK_STREAM, 0);
	SOCKADDR_IN addrSrvAccept;
	addrSrvAccept.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
	addrSrvAccept.sin_family = AF_INET;
	addrSrvAccept.sin_port = htons(DATA_PORT);

	bind(sockSrvAccept, (SOCKADDR *)&addrSrvAccept, sizeof(SOCKADDR));

	//���� TCP_NODELAY
	BOOL bOptVal = TRUE;
    int bOptLen = sizeof (BOOL);
	int iResult = 0;
	setsockopt(sockSrvAccept, IPPROTO_TCP, TCP_NODELAY, (char *)&bOptVal, bOptLen);
	if (iResult == SOCKET_ERROR)
	{
    }

	//����������socket
	thiz->DataSrvSocket = sockSrvAccept;

	listen(sockSrvAccept, 5);

	SOCKADDR_IN addrClientAccept;
	SOCKET sk = INVALID_SOCKET;
	int len = sizeof(SOCKADDR);

	while(thiz->bServerRun)
	{
		sk = accept(sockSrvAccept, (SOCKADDR *)&addrClientAccept, &len);
		if(sk == INVALID_SOCKET)
		{
		}
		else
		{
			//���� TCP_NODELAY
			BOOL bOptVal = TRUE;
			int bOptLen = sizeof (BOOL);
			int iResult = 0;
			setsockopt(sockSrvAccept, IPPROTO_TCP, TCP_NODELAY, (char *)&bOptVal, bOptLen);
			if (iResult == SOCKET_ERROR)
			{
			}

			EnterCriticalSection (&thiz->SockCriticalSection);

			if (pclients->SockNum >= pclients->MaxSockNum)
			{
				closesocket(sk);
			}
			else
			{
				pclients->pSock[pclients->SockNum].sk = sk;
				pclients->pSock[pclients->SockNum].addr = addrClientAccept;
				pclients->pSock[pclients->SockNum].CommStatMach = enumInitData;
				pclients->pSock[pclients->SockNum].buf = new char[DATA_PACK_LEN];
				pclients->pSock[pclients->SockNum].BufSz = DATA_PACK_LEN;
				memset(&pclients->pSock[pclients->SockNum].CmdTrans, 0, sizeof(CMD_PACK));
				memset(&pclients->pSock[pclients->SockNum].CmdRecv, 0, sizeof(CMD_PACK));
				pclients->pSock[pclients->SockNum].len = 0;
				pclients->pSock[pclients->SockNum].hCmdResponsed = NULL;
				pclients->pSock[pclients->SockNum].ErrCode = enuOk;
				pclients->pSock[pclients->SockNum].enalbed = FALSE;
				pclients->pSock[pclients->SockNum].seq = 0;
				pclients->SockNum++;
			}

			LeaveCriticalSection (&thiz->SockCriticalSection);
		}
	}

	//closesocket(sockSrvAccept);

	return 0;
}

/*******************************************************************************
 Function Name:	WorkerThread
 Description  : �ͻ�ͨ�Ź����߳�
 Input        :	LPVOID lpParam  ---  ���ݲ���
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
DWORD WINAPI WorkerThread(LPVOID lpParam)
{
#ifdef DEBUG_VIEW_OUTPUT
	char debug_str[250];
	DWORD diff_tm;
#endif

	SocketHardware *thiz = (SocketHardware *)lpParam;
	PDEV_MANAGER pdevs = &thiz->devs;
	PSOCK_MANAGER pclients = &thiz->clients;

	int i;
	int j;
	fd_set fdread;     
	//fd_set fdwrite;
	int ret;     
	struct timeval tv = {1, 0};     
	char *szMessage = new char[DATA_PACK_LEN];
	while(thiz->bServerRun)      
	{
		if (pclients->SockNum <= 0)
		{
			Sleep(100);
			continue;
		}

		//�����׽��ֹر�״̬
		for (i = 0; i < pclients->SockNum; i++)
		{
			if (enumCloseSocket == pclients->pSock[i].CommStatMach)
			{
				EnterCriticalSection(&thiz->SockCriticalSection);

				//�ر�����
				closesocket(pclients->pSock[i].sk);
				pclients->pSock[i].sk = INVALID_SOCKET;
				if (pclients->pSock[i].buf)
				{
					delete []pclients->pSock[i].buf;
					pclients->pSock[i].buf = NULL;
				}
				if (pclients->pSock[i].hCmdResponsed)
				{
					CloseHandle(pclients->pSock[i].hCmdResponsed);
					pclients->pSock[i].hCmdResponsed = NULL;
				}
				if (i < pclients->SockNum - 1)      
				{     
					pclients->pSock[i] = pclients->pSock[pclients->SockNum - 1];
					i--;
					pclients->SockNum--;
				}
				else
				{
					pclients->SockNum--;
				}
				LeaveCriticalSection(&thiz->SockCriticalSection);
			}
		}

		//�������ݽ���
		FD_ZERO(&fdread);   //1��ն���  
		//FD_ZERO(&fdwrite);

#ifdef DEBUG_VIEW_OUTPUT
		/************************************************************************/
		int addr[MAX_CARDNUM];
		memset(addr, 0, sizeof(addr));
		int num = 0;
		/************************************************************************/
#endif

		for (i = 0; i < pclients->SockNum; i++)
		{   
			if (
				(pclients->pSock[i].CommStatMach == enumInitCmd)
				|| (pclients->pSock[i].CommStatMach == enumInitData)
				|| (pclients->pSock[i].enalbed == TRUE)
				)
			{
				FD_SET(pclients->pSock[i].sk, &fdread);   //2��Ҫ�����׽ӿڼ������
				
#ifdef DEBUG_VIEW_OUTPUT
				/************************************************************************/
				if (ntohs(pclients->pSock[i].addr.sin_port) % 2 == 0)	//���ݶ˿�
				{
					addr[num] = pclients->pSock[i].addr.sin_addr.s_impno;
					num++;
				}
				/************************************************************************/
#endif
			}
		}
#ifdef DEBUG_VIEW_OUTPUT
		/************************************************************************/
		tmCurrent = GetTickCount();
		DWORD tmSpan = tmCurrent - tmStart;
// 		sprintf(debug_str, "%02d:%02d:%02d:%03d   Read device num %d - %d: ",
// 			tmSpan / 3600000, (tmSpan % 3600000) / 60000, (tmSpan % 60000) / 1000, tmSpan % 1000, 
// 			pclients->SockNum, num);
		sprintf(debug_str, "Total %d, Read %d : ", pclients->SockNum, num);
		for (int addr_num = 0; addr_num < num; addr_num++)
		{
			char tmp_add[10];
			sprintf(tmp_add, "%d ", addr[addr_num]);
			strcat(debug_str, tmp_add);
		}
		strcat(debug_str, "\n");
		OutputDebugString(debug_str);
		/************************************************************************/
#endif

		// We only care read event     
		ret = select(0, &fdread, NULL, NULL, &tv);   //3��ѯ����Ҫ����׽��֣�������Ҫ�󣬳���  
		if (ret == 0)      
		{     
			// Time expired     
			continue;     
		}     
		else if (ret == SOCKET_ERROR)
		{
			//int a= WSAGetLastError();
#ifdef DEBUG_VIEW_OUTPUT
			sprintf(debug_str, "Select Error\n");
			OutputDebugString(debug_str);
#endif
			Sleep(COMM_TIMEOUT_MS);
		}

		for (i = 0; i < pclients->SockNum; i++)      
		{     
			if (FD_ISSET(pclients->pSock[i].sk, &fdread))    //4.�Ƿ���Ȼ�ڶ���  
			{     
				// A read event happened on g_CliSocketArr     

				//ret = recv(pclients->pSock[i].sk, szMessage, DATA_PACK_LEN, 0);     
				ret = recv(pclients->pSock[i].sk, szMessage, DATA_PACK_LEN - pclients->pSock[i].len, 0);     
				//if (ret == 0 || (ret == SOCKET_ERROR && WSAGetLastError() == WSAECONNRESET))      
				if (ret == 0 || ret == SOCKET_ERROR)
				{
				}      
				else      
				{   
					switch (pclients->pSock[i].CommStatMach)
					{
					case enumInitCmd:
						memcpy(&pclients->pSock[i].buf[pclients->pSock[i].len], szMessage, ret);
						pclients->pSock[i].len += ret;
						if (pclients->pSock[i].len >= CMD_PACK_LEN)		//hello����
						{
							//��ʾ���յ�������
// 							memcpy(&g_CmdRecv, g_SockBuf[i], sizeof(g_CmdRecv));
// 							thiz->DisplayCmdReceived();

							//�����������
							CMD_PACK cmd;
							int id;
							int j;
							memcpy(&cmd, pclients->pSock[i].buf, CMD_PACK_LEN);
							id = ntohs(cmd.dat.hello.DevNo);

							if (//HELLOУ��
								(ntohs(cmd.index) != HELLO_CMD_INDEX)
								|| (ntohs(cmd.flag) != CMD_FLAG)
								|| (cmd.FpgaAddr != 0x00)
								|| (cmd.FpgaCmd != 0x00)
								|| (cmd.McuCmd != 0x00)
								|| (cmd.type != enuCmdHello)
								|| (ntohl(cmd.dat.hello.check1) != HELLO_CMD_CHECK1)
								|| (ntohl(cmd.dat.hello.check2) != HELLO_CMD_CHECK2)
								|| (ntohs(cmd.dat.hello.DevNo) >= pdevs->MaxDevNum)
								|| (ntohl(cmd.dat.hello.pid) != WIRELESS_AE_PID)
								//IDУ��
								|| (id >= pdevs->MaxDevNum)
								)
							{
								//�ر�����
								EnterCriticalSection(&thiz->SockCriticalSection);
								closesocket(pclients->pSock[i].sk);
								pclients->pSock[i].sk = INVALID_SOCKET;
								if (pclients->pSock[i].buf)
								{
									delete []pclients->pSock[i].buf;
									pclients->pSock[i].buf = NULL;
								}
								if (pclients->pSock[i].hCmdResponsed)
								{
									CloseHandle(pclients->pSock[i].hCmdResponsed);
									pclients->pSock[i].hCmdResponsed = NULL;
								}
								if (i < pclients->SockNum - 1)      
								{     
									pclients->pSock[i] = pclients->pSock[pclients->SockNum - 1];
									i--;
									pclients->SockNum--;
								}
								else
								{
									pclients->SockNum--;
								}
								LeaveCriticalSection(&thiz->SockCriticalSection);
							}
							else	//����˿�HELLOУ��ɹ�
							{
								EnterCriticalSection(&thiz->SockCriticalSection);

								pclients->pSock[i].CommStatMach = enumIdleCmd;

								SOCKET sock = pdevs->pDev[id].CmdSock;
								sock = pclients->pSock[i].sk;

								//���ö˿�ʹ��״̬
								pclients->pSock[i].enalbed = pdevs->pDev[id].enalbed;

								//�ر�֮ǰ��socket
								for (j = 0; j < pclients->SockNum; j++)
								{
									//if (pclients->pSock[j].sk == sock)
									if ((sock != pclients->pSock[j].sk)
										&& (pclients->pSock[j].addr.sin_addr.S_un.S_addr == pdevs->pDev[id].CmdAddr.sin_addr.S_un.S_addr)
										&& (pclients->pSock[j].CommStatMach >= enumInitCmd)
										&& (pclients->pSock[j].CommStatMach <= enumGetCmd)
										)
									{
										closesocket(pclients->pSock[j].sk);
										if (pclients->pSock[j].buf)
										{
											delete []pclients->pSock[j].buf;
											pclients->pSock[j].buf = NULL;
										}
										if (pclients->pSock[j].hCmdResponsed)
										{
											CloseHandle(pclients->pSock[j].hCmdResponsed);
											pclients->pSock[j].hCmdResponsed = NULL;
										}
										if (j < pclients->SockNum - 1)      
										{     
											pclients->pSock[j] = pclients->pSock[pclients->SockNum - 1];
											j--;
											pclients->SockNum--;
										}
										else
										{
											pclients->SockNum--;
										}
									}
								}								

								//�˿ڷ����仯��˵��֮ǰ������ʧЧ�򲻴���
								if (pdevs->pDev[id].CmdPort != ntohs(cmd.dat.hello.port))
								{
								}
								else
								{
								}

								pdevs->pDev[id].CmdAddr = pclients->pSock[i].addr;
								pdevs->pDev[id].CmdPort = ntohs(cmd.dat.hello.port);
								
								//�����µ�socket
								pdevs->pDev[id].CmdSock = pclients->pSock[i].sk;
								
								pdevs->pDev[id].DevNo = id;//ntohs(cmd.dat.hello.DevNo);
								pdevs->pDev[id].pid = ntohl(cmd.dat.hello.pid);
								pdevs->pDev[id].FpgaVer = ntohl(cmd.dat.hello.FpgaVer);
								pdevs->pDev[id].FirmVer = ntohl(cmd.dat.hello.FirmVer);

								//pclients->pSock[i].enalbed = pdevs->pDev[id].enalbed;


								LeaveCriticalSection(&thiz->SockCriticalSection);
							}
						}
						break;
					case enumIdleCmd:
						break;
					case enumSendCmd:
						pclients->pSock[i].len = ret;
						memset(pclients->pSock[i].buf, 0, DATA_PACK_LEN);
						memcpy(pclients->pSock[i].buf, szMessage, ret);
						if (pclients->pSock[i].len >= CMD_PACK_LEN)
						{
							//��ʾ���յ�������
// 							memcpy(&g_CmdRecv, g_SockBuf[i], sizeof(g_CmdRecv));
// 							thiz->DisplayCmdReceived();

							memcpy(&pclients->pSock[i].CmdRecv, pclients->pSock[i].buf, CMD_PACK_LEN);
							if (//����յ���������ȷ��
								(pclients->pSock[i].CmdRecv.flag == pclients->pSock[i].CmdTrans.flag)
								&& (pclients->pSock[i].CmdRecv.index == pclients->pSock[i].CmdTrans.index)
								&& (pclients->pSock[i].CmdRecv.type == enuCmdRecv)
								&& (pclients->pSock[i].CmdRecv.McuCmd == pclients->pSock[i].CmdTrans.McuCmd)
								&& (pclients->pSock[i].CmdRecv.FpgaCmd == pclients->pSock[i].CmdTrans.FpgaCmd)
								&& (pclients->pSock[i].CmdRecv.FpgaAddr == pclients->pSock[i].CmdTrans.FpgaAddr)
								)
							{
								pclients->pSock[i].ErrCode = enuOk;
							}
							else
							{
								pclients->pSock[i].ErrCode = enuCheckError;
							}

							pclients->pSock[i].CommStatMach = enumIdleCmd;
							pclients->pSock[i].len = 0;
							SetEvent(pclients->pSock[i].hCmdResponsed);

						}
						else
						{
							pclients->pSock[i].CommStatMach = enumGetCmd;
						}
						break;
					case enumGetCmd:

						memcpy(&pclients->pSock[i].buf[pclients->pSock[i].len], szMessage, ret);
						pclients->pSock[i].len += ret;
						if (pclients->pSock[i].len >= CMD_PACK_LEN)
						{
							//��ʾ���յ�������
// 							memcpy(&g_CmdRecv, g_SockBuf[i], sizeof(g_CmdRecv));
// 							thiz->DisplayCmdReceived();

							memcpy(&pclients->pSock[i].CmdRecv, pclients->pSock[i].buf, CMD_PACK_LEN);
							if (//����յ���������ȷ��
								(pclients->pSock[i].CmdRecv.flag == pclients->pSock[i].CmdTrans.flag)
								&& (pclients->pSock[i].CmdRecv.index == pclients->pSock[i].CmdTrans.index)
								&& (pclients->pSock[i].CmdRecv.type == enuCmdRecv)
								&& (pclients->pSock[i].CmdRecv.McuCmd == pclients->pSock[i].CmdTrans.McuCmd)
								&& (pclients->pSock[i].CmdRecv.FpgaCmd == pclients->pSock[i].CmdTrans.FpgaCmd)
								&& (pclients->pSock[i].CmdRecv.FpgaAddr == pclients->pSock[i].CmdTrans.FpgaAddr)
								)
							{
								pclients->pSock[i].ErrCode = enuOk;
							}
							else
							{
								pclients->pSock[i].ErrCode = enuCheckError;
							}

							pclients->pSock[i].CommStatMach = enumIdleCmd;
							pclients->pSock[i].len = 0;
							SetEvent(pclients->pSock[i].hCmdResponsed);
						}
						break;
					case enumInitData:
						memcpy(&pclients->pSock[i].buf[pclients->pSock[i].len], szMessage, ret);
						pclients->pSock[i].len += ret;
						if (pclients->pSock[i].len >= DATA_PACK_LEN)		//hello����
						{
							//�����������
							DATA_PACK cmd;
							int id;
							int j;
							memcpy(&cmd, pclients->pSock[i].buf, DATA_PACK_LEN);
							id = ntohs(cmd.dat.hello.DevNo);

							if (//HELLOУ��
								(ntohs(cmd.flag) != DATA_FLAG)
								|| (ntohs(cmd.index) != HELLO_DATA_INDEX)
								|| (cmd.type != enuDataHello)
								|| (ntohs(cmd.len) != DATA_PACK_LEN)
								//IDУ��
								|| (id >= pdevs->MaxDevNum)
								)
							{
								//�ر�����
								EnterCriticalSection(&thiz->SockCriticalSection);
								closesocket(pclients->pSock[i].sk);
								pclients->pSock[i].sk = INVALID_SOCKET;
								if (pclients->pSock[i].buf)
								{
									delete []pclients->pSock[i].buf;
									pclients->pSock[i].buf = NULL;
								}
								if (pclients->pSock[i].hCmdResponsed)
								{
									CloseHandle(pclients->pSock[i].hCmdResponsed);
									pclients->pSock[i].hCmdResponsed = NULL;
								}
								if (i < pclients->SockNum - 1)      
								{     
									pclients->pSock[i] = pclients->pSock[pclients->SockNum - 1];
									i--;
									pclients->SockNum--;
								}
								else
								{
									pclients->SockNum--;
								}
								LeaveCriticalSection(&thiz->SockCriticalSection);
							}
							else	//���ݶ˿�HELLOУ��ɹ�
							{

								EnterCriticalSection(&thiz->SockCriticalSection);

								pclients->pSock[i].len = 0;

								pclients->pSock[i].CommStatMach = enumGetData;

								SOCKET sock = pdevs->pDev[id].DataSock;
								sock = pclients->pSock[i].sk;

								//���ö˿�ʹ��״̬
								pclients->pSock[i].enalbed = pdevs->pDev[id].enalbed;

								//�ر�֮ǰ��socket
								for (j = 0; j < pclients->SockNum; j++)
								{
									//if (pclients->pSock[j].sk == sock)
									if ((sock != pclients->pSock[j].sk)
										&& (pclients->pSock[j].addr.sin_addr.S_un.S_addr == pdevs->pDev[id].CmdAddr.sin_addr.S_un.S_addr)
										&& (pclients->pSock[j].CommStatMach >= enumInitData)
										&& (pclients->pSock[j].CommStatMach <= enumGetData)
										)
									{

										closesocket(pclients->pSock[j].sk);
										if (pclients->pSock[j].buf)
										{
											delete []pclients->pSock[j].buf;
											pclients->pSock[j].buf = NULL;
										}
										if (pclients->pSock[j].hCmdResponsed)
										{
											CloseHandle(pclients->pSock[j].hCmdResponsed);
											pclients->pSock[j].hCmdResponsed = NULL;
										}
										if (j < pclients->SockNum - 1)      
										{     
											pclients->pSock[j] = pclients->pSock[pclients->SockNum - 1];
											j--;
											pclients->SockNum--;
										}
										else
										{
											pclients->SockNum--;
										}
									}
								}								

								//�˿ڷ����仯��˵��֮ǰ������ʧЧ�򲻴���
								if (pdevs->pDev[id].DataPort != ntohs(cmd.dat.hello.port))
								{
									pdevs->pDev[id].DataAddr = pclients->pSock[i].addr;
									pdevs->pDev[id].DataPort = ntohs(cmd.dat.hello.port);
									

									//�����µ�socket
									pdevs->pDev[id].DataSock = pclients->pSock[i].sk;
								}
								else
								{
								}
								LeaveCriticalSection(&thiz->SockCriticalSection);
							}
						}
						break;
					case enumGetData:

						memcpy(&pclients->pSock[i].buf[pclients->pSock[i].len], szMessage, ret);
						pclients->pSock[i].len += ret;
						if (pclients->pSock[i].len >= DATA_PACK_LEN)
						{
							//�����������
							PDATA_PACK pcmd;
							int id;
							//int j;
							pcmd = (PDATA_PACK)pclients->pSock[i].buf;
							id = ntohs(pcmd->dat.response.DevNo);

							if (//���ݰ�ͷУ��
								(ntohs(pcmd->flag) != DATA_FLAG)
								|| (pcmd->type != enuDataRecv)
								|| (ntohs(pcmd->len) != DATA_PACK_LEN)
								//IDУ��
								|| (id >= pdevs->MaxDevNum)
								)
							{

							}
							else	//���ݰ�ͷУ��ɹ�
							{

								//��ż��
								if (pclients->pSock[i].seq == 0)	//���׽����״��յ����ݰ�(������HELLO��)
								{
									pclients->pSock[i].seq = ntohs(pcmd->index);
								}
								else
								{
									if ((++pclients->pSock[i].seq) != ntohs(pcmd->index))
									{

									}
									if (pclients->pSock[i].seq >= PACK_INDEX_MAX)
									{
										pclients->pSock[i].seq = 0;
									}
								}

								thiz->AnalysisPacket(id, (PUCHAR)pcmd->dat.response.dat, DATA_BLOCK_SIZE);
							}

							pclients->pSock[i].len = 0;
						}
						break;
					case enumCloseSocket:
						//Do nothing
						break;
					default:
						break;
					}
				}
			}     
		}    
	}

	if (szMessage)
	{
		delete []szMessage;
		szMessage = NULL;
	}

	return 0;
}

/*******************************************************************************
 Function Name:	SendCmdThread
 Description  : ���������߳�
 Input        :	LPVOID lpParam  ---  ���ݲ���
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
DWORD WINAPI SendCmdThread(LPVOID lpParam)     
{
#ifdef DEBUG_VIEW_OUTPUT
	/************************************************************************/
	char debug_str[250];
	/************************************************************************/
#endif

	SocketHardware *thiz = (SocketHardware *)lpParam;
	PDEV_MANAGER pdevs = &thiz->devs;
	PSOCK_MANAGER pclients = &thiz->clients;
	int DevNo;
	
	int i;
	int cnt = 0;
	int rtn;
	int RepeatNum = 0;

	if (ALL_OPENED_DEVS == thiz->CurrentDev)
	{
		EnterCriticalSection (&thiz->SockCriticalSection);
		if (thiz->DevOperatingIndex < thiz->openCardNum )
		{
			DevNo = thiz->OpenedDevIndexTab[thiz->DevOperatingIndex];
			thiz->DevOperatingIndex++;
		}
		else
		{
			LeaveCriticalSection(&thiz->SockCriticalSection);
			return 0;
		}
		LeaveCriticalSection(&thiz->SockCriticalSection);
	}
	else
	{
		DevNo = thiz->CurrentDev;
	}
	
	if (thiz->bServerRun)      
	{
		//EnterCriticalSection(&thiz->SockCriticalSection);

		SOCKET sk;
		
// 		for (i = 0; i < pdevs->MaxDevNum; i++)
// 		{
// 			if (pdevs->pDev[i].DevNo == DevNo)
// 			{
// 				sk = pdevs->pDev[i].CmdSock;
// 				break;
// 			}
// 		}
		
		sk = pdevs->pDev[DevNo].CmdSock;
		
		for (i = 0; i < pclients->SockNum; i++)      
		{   
			if (sk != pclients->pSock[i].sk)
			{
				continue;
			}
			
			//ǿ�ƶ�״̬����λ������
			pclients->pSock[i].CommStatMach = enumIdleCmd;

			if (pclients->pSock[i].CommStatMach == enumIdleCmd)
			{
				memset(&pclients->pSock[i].CmdRecv, 0, sizeof(CMD_PACK));
				cnt = 0;
				RepeatNum = 0;
				while ((cnt < sizeof(CMD_PACK)) && (RepeatNum < COMM_RETRY_NUM))
				{
					//����׽����Ƿ�仯
					if (sk != pclients->pSock[i].sk)
					{
						sk = pclients->pSock[i].sk;
						RepeatNum = 0;
					}
					rtn = send(pclients->pSock[i].sk, ((char*)&pclients->pSock[i].CmdTrans) + cnt, sizeof(CMD_PACK) - cnt, 0);
					if (rtn == SOCKET_ERROR)
					{
// 						thiz->m_SwapMsg.Format(_T("Error in send command, sent %d, error code %d"), cnt, WSAGetLastError());
// 						thiz->PostMessage(WM_REFRESH_INFO);
						break;
					}
					else
					{
						cnt += rtn;
					}

					RepeatNum++;
				}

				if (cnt >= sizeof(CMD_PACK))
				{
					pclients->pSock[i].CommStatMach = enumSendCmd;
				}
				else
				{
					pclients->pSock[i].ErrCode = enuTransError;
				}
			}
			break;
		}
		
		//LeaveCriticalSection(&thiz->SockCriticalSection);
	}
	return 0;
}     

/*******************************�ڲ�����***************************************/
/*******************************************************************************
 Function Name:	SocketHardware
 Description  : Construction
 Input        :	
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
SocketHardware::SocketHardware()
{
	int i;

	//��ʼ���豸������
	DEV_NODE tmp_dev;
	memset(&tmp_dev.CmdAddr, 0, sizeof(tmp_dev.CmdAddr));
	tmp_dev.CmdPort = 0;
	tmp_dev.CmdSock = INVALID_SOCKET;
	memset(&tmp_dev.DataAddr, 0, sizeof(tmp_dev.DataAddr));
	tmp_dev.DataPort = 0;
	tmp_dev.DataSock = INVALID_SOCKET;
	tmp_dev.DevNo = (USHORT)(~0);
	tmp_dev.pid = 0;
	tmp_dev.FpgaVer = 0;
	tmp_dev.FirmVer = 0;
	tmp_dev.seq = 0;
	//p_dev.bFrmDecodeCompleted = TRUE;
	tmp_dev.PackVer = 0;
	tmp_dev.FrmVer = 0;
	tmp_dev.FrmEncodeType = en16BitsPcm;
	tmp_dev.FrmDpcmBits = 0x0d;
	tmp_dev.PackId = 0;
	tmp_dev.PackOfFrm = 0;
    tmp_dev.PackInFrm = 0;
	tmp_dev.restPackageCard = 0;
    tmp_dev.restPackageData = NULL;
	tmp_dev.restFftPackageCard = 0;
    tmp_dev.restFftPackageData = NULL;
	tmp_dev.ParamFIFO.ReleaseBuf();

	tmp_dev.bStartStreamingInternalTrig = FALSE;
	tmp_dev.ChStreamingState = 0;
	tmp_dev.bParamEn = FALSE;

	tmp_dev.enalbed = FALSE;

	devs.MaxDevNum = MAX_CARDNUM;
	//devs.DevNum = 0;
	devs.pDev = new DEV_NODE[devs.MaxDevNum];
	for (i = 0; i < devs.MaxDevNum; i++)
	{
		devs.pDev[i] = tmp_dev;
	}

	//��ʼ�����ӹ�����
	SOCK_NODE tmp_sock;
	tmp_sock.sk = INVALID_SOCKET;
	memset(&tmp_sock.addr, 0, sizeof(tmp_sock.addr));
	tmp_sock.CommStatMach = -1;
	tmp_sock.buf = NULL;
	tmp_sock.BufSz = 0;
	memset(&tmp_sock.CmdTrans, 0, sizeof(tmp_sock.CmdTrans));
	memset(&tmp_sock.CmdRecv, 0, sizeof(tmp_sock.CmdRecv));
	tmp_sock.len = 0;
	tmp_sock.hCmdResponsed = NULL;
	tmp_sock.ErrCode = enuOk;
	tmp_sock.enalbed = FALSE;
	tmp_sock.seq = 0;

	clients.MaxSockNum = MAX_SOCKET_NUM;
	clients.SockNum = 0;
	clients.pSock = new SOCK_NODE[MAX_SOCKET_NUM];
	for (i = 0; i < MAX_SOCKET_NUM; i++)
	{
		clients.pSock[i] = tmp_sock;
	}

	SocketError = enSocketOk;

	//��ʼ���豸����ͬ������
	InitializeCriticalSection(&SockCriticalSection);

	//��ʼ����ǰ�������豸��
	CurrentDev = ALL_OPENED_DEVS;

	//��ʼ����������ͬ���ź�
	//hCmdTransEvent = CreateEvent(NULL,FALSE,FALSE,NULL);

	//��ʼ��������Ӧ������ͬ���ź�
	//hCmdResponseEvent = CreateEvent(NULL,FALSE,FALSE,NULL);

	//��ʼ��socket
	WORD wVersionRequested;
	WSADATA wsaData;
	int err;
	wVersionRequested = MAKEWORD(1, 1);
	err = WSAStartup(wVersionRequested, &wsaData);
	
	if(err != 0
		|| LOBYTE(wsaData.wVersion) != 1
		|| HIBYTE(wsaData.wVersion) != 1)
	{
		WSACleanup();
		return;
	}

	//��ʼ����������
// 	bDeviceStaus = new BOOL[MAX_DEV_NUM];
// 	if (bDeviceStaus)
// 	{
// 		memset(bDeviceStaus, 0, MAX_DEV_NUM * sizeof(BOOL));
// 	}
// 	bDeviceOpenFlag = new BOOL[MAX_DEV_NUM];
// 	if (bDeviceOpenFlag)
// 	{
// 		memset(bDeviceOpenFlag, 0, MAX_DEV_NUM * sizeof(BOOL));
// 	}
	openCardNum = 0;
	DevOperatingIndex = 0;
	ppOpenedDevTab = new PDEV_NODE[devs.MaxDevNum];
	memset(ppOpenedDevTab, 0, devs.MaxDevNum * sizeof(PDEV_NODE));
	OpenedDevIndexTab = new UINT[devs.MaxDevNum];
	memset(OpenedDevIndexTab, 0xff, devs.MaxDevNum * sizeof(UINT));
	//chParamFIFO = new CParamFIFO[devs.MaxDevNum + 2];	//����buffer + ʱ��֡buffer + ���֡buffer
	SysTimeFIFO.AllocateBuf(SYSTIME_PARAM_BUF_LENGTH);							//ϵͳʱ��֡buffer
	ExParamFIFO.AllocateBuf(EXP_PARAM_BUF_LENG);								//���֡buffer

	SampleLen = 0;
	exParamBuf = new short[devs.MaxDevNum];
	memset(exParamBuf, 0, sizeof(short) * devs.MaxDevNum);
	exParamEn = FALSE;
	fftEn = FALSE;
	ParamType = enFixedLen;
	WaveThreshold = new U32[devs.MaxDevNum];
	memset(WaveThreshold, 0, sizeof(U32) * devs.MaxDevNum);
	FirFilterOrder = FIR_ORDER;

	preSysTime = 0;			//�ϴμ�¼��ϵͳʱ��
	curSysTime = 0;			//��ǰϵͳʱ��

	WthMdl = NULL;
	bHardParam = TRUE;
    hWaveToHitSemaph = NULL;

	//��ʼ������buffer
	rawBuf = new char[MAX_RAWDATA_BUF_LENGTH];
	fftBuf = new char[MAX_FFTDATA_BUF_LENGTH];

	paraBuf = new PARAM[MAX_PARAM_BUF_LENGTH];

	//��ʼ��GPSͬ��״̬
	bGpsSyncEnabled = FALSE;

	//��ʼ��ϵͳ״̬
	SysState = enuSampleIdle;

	//��ʼ�����ݴ�ȡͬ���ź�
	ParamMutex = CreateMutex(NULL, FALSE, NULL);
	WaveMutex = CreateMutex(NULL, FALSE, NULL);
    FftMutex = CreateMutex(NULL, FALSE, NULL);

	//��ʼ���߳�
	bServerRun = TRUE;

	//��ʼ���׽���
	CmdSrvSocket = INVALID_SOCKET;
	DataSrvSocket = INVALID_SOCKET;

	DWORD dwThreadId = 0;
	hThreadWork = CreateThread(NULL, 0, WorkerThread, this, 0, &dwThreadId);    
	hThreadCmd = CreateThread(NULL, 0, CmdServerThread, this, 0, NULL);
	hThreadData = CreateThread(NULL, 0, DataServerThread, this, 0, NULL);
}

/*******************************************************************************
 Function Name:	~SocketHardware
 Description  : Destruction
 Input        :	
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
SocketHardware::~SocketHardware()
{
	int i;

	bServerRun = FALSE;

	SysState = enuSampleIdle;

	if (CmdSrvSocket != INVALID_SOCKET)
	{
		closesocket(CmdSrvSocket);
		CmdSrvSocket = INVALID_SOCKET;
	}
	if (DataSrvSocket != INVALID_SOCKET)
	{
		closesocket(DataSrvSocket);
		DataSrvSocket = INVALID_SOCKET;
	}
	
	WSACleanup();
	
	WaitForSingleObject(hThreadCmd, INFINITE);
	WaitForSingleObject(hThreadData, INFINITE);
	WaitForSingleObject(hThreadWork, INFINITE);

	DeleteCriticalSection(&SockCriticalSection);

	//CloseHandle(hCmdTransEvent);

	//CloseHandle(hCmdResponseEvent);

// 	if (bDeviceStaus)
// 	{
// 		delete []bDeviceStaus;
// 		bDeviceStaus = NULL;
// 	}
// 
// 	if (bDeviceOpenFlag)
// 	{
// 		delete []bDeviceOpenFlag;
// 		bDeviceOpenFlag = NULL;
// 	}
	if (WthMdl)
	{
		WaveToHitCleanup(WthMdl);
		WthMdl = NULL;
	}
	
    if (hWaveToHitSemaph)
    {
        CloseHandle(hWaveToHitSemaph);
        hWaveToHitSemaph = NULL;
    }

	if (clients.pSock)
	{
		for (i = 0; i < clients.MaxSockNum; i++)
		{
			if (clients.pSock[i].buf)
			{
				delete []clients.pSock[i].buf;
				clients.pSock[i].buf = NULL;
			}
			if (clients.pSock[i].hCmdResponsed)
			{
				CloseHandle(clients.pSock[i].hCmdResponsed);
				clients.pSock[i].hCmdResponsed = NULL;
			}
		}
		delete []clients.pSock;
		clients.pSock = NULL;
		clients.SockNum = 0;
		clients.MaxSockNum = 0;
	}

	if (devs.pDev)
	{
		for (i = 0; i < devs.MaxDevNum; i++)
		{
			if (devs.pDev[i].restPackageData)
			{
				delete []devs.pDev[i].restPackageData;
				devs.pDev[i].restPackageData = NULL;
			}
			if (devs.pDev[i].restFftPackageData)
			{
				delete []devs.pDev[i].restFftPackageData;
				devs.pDev[i].restFftPackageData = NULL;
			}
			devs.pDev[i].ParamFIFO.ReleaseBuf();
		}
		delete []devs.pDev;
		devs.pDev = NULL;
		//devs.DevNum = 0;
		devs.MaxDevNum = 0;
	}

	if (ppOpenedDevTab)
	{
		delete []ppOpenedDevTab;
		ppOpenedDevTab = NULL;
	}

	if (OpenedDevIndexTab)
	{
		delete []OpenedDevIndexTab;
		OpenedDevIndexTab = NULL;
	}

	SysTimeFIFO.ReleaseBuf();
	ExParamFIFO.ReleaseBuf();

// 	if (chParamFIFO)
// 	{
// 		for (i = 0; i < devs.MaxDevNum + 2; i++)
// 		{
// 			chParamFIFO[i].ReleaseBuf();
// 		}
// 		delete []chParamFIFO;
// 		chParamFIFO = NULL;
// 	}

	if (exParamBuf)
	{
		delete []exParamBuf;
		exParamBuf = NULL;
	}

	if (WaveThreshold)
    {
        delete []WaveThreshold;
		WaveThreshold = NULL;
    }

	if(rawBuf)
	{
		delete []rawBuf;
		rawBuf = NULL;
	}

	if (fftBuf)
	{
		delete []fftBuf;
		fftBuf = NULL;
	}

	if (paraBuf)
	{
		delete []paraBuf;
		paraBuf = NULL;
	}

	if(ParamMutex)
    {
		CloseHandle(ParamMutex);
        ParamMutex = NULL;
    }

	if(WaveMutex)
    {
		CloseHandle(WaveMutex);	
        WaveMutex = NULL;
    }

	if (FftMutex)
	{
		CloseHandle(FftMutex);	
		FftMutex = NULL;
	}
}

/*******************************************************************************
 Function Name:	AnalysisPacket
 Description  : ���ģ�飬����һ�δ��豸�ж������������н������raw���ݣ�fft���ݣ�para���ݷֿ�����Ӧ������
 Input        :	short nIndex      --- ����
                UCHAR *recvbuffer --- ָ�����������ݻ�������ָ��
				UINT recvcount    --- ���������ݻ������ĳ���
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
void SocketHardware::AnalysisPacket(short nIndex, UCHAR *recvbuffer, UINT recvcount)
{
#ifdef DEBUG_VIEW_OUTPUT
	/************************************************************************/
	char debug_str[250];
	/************************************************************************/
#endif

#ifdef DEBUG_OUTPUT_FILE
	char* pFileName;
	switch (nIndex)
	{
	case 0:
		pFileName = "datafile_0.dat";
		break;
	case 1:
		pFileName = "datafile_1.dat";
		break;
	case 2:
		pFileName = "datafile_2.dat";
		break;
	case 3:
		pFileName = "datafile_3.dat";
		break;
	default:
		pFileName = "datafile.dat";
		break;
	}
    
    FILE* fp = fopen(pFileName, "ab+");
    
    fseek(fp, 0, SEEK_END);
    
	fwrite(recvbuffer, recvcount, 1, fp);
	
	fclose(fp);
#endif

	if (ppOpenedDevTab[nIndex] == NULL)
	{
		return;
	}

	UINT allPackageSum = recvcount / DATA_BLOCK_SIZE;
    
	UINT restPackageSum;
	
	PACK_HEAD *pPackHead = NULL;
    char *pDataBuf = NULL;
    UINT DataLen = 0;

	UINT PackVer;
	
	for(UINT i = 0; i < allPackageSum; )
    {
		pPackHead = (PACK_HEAD*)&recvbuffer[i * DATA_BLOCK_SIZE];
		PackVer = ppOpenedDevTab[nIndex]->PackVer;
		switch (PackVer)
        {
		case 0:
        default:
			pDataBuf = (char*)&recvbuffer[i * DATA_BLOCK_SIZE];
			DataLen = DATA_BLOCK_SIZE;

			if ((ppOpenedDevTab[nIndex]->restPackageCard < singlePackageSum)
				|| ((ppOpenedDevTab[nIndex]->restFftPackageCard >= singleFftPackageSum)
			//	&& (*(unsigned short *)&recvbuffer[i * DATA_BLOCK_SIZE]) == 0x8000))
				&& (((*(unsigned short *)&recvbuffer[i * DATA_BLOCK_SIZE]) & 0xff00) == 0x8000)))   //Realtime Wave
			{
				restPackageSum = ppOpenedDevTab[nIndex]->restPackageCard;

				while(curRawBufLength >= maxRawBufLength)
                {
                    if (enuSampleIdle == SysState)
                    {
                        return;
                    }
                }
				if(WAIT_OBJECT_0 != WaitForSingleObject(WaveMutex, SYNC_TIMEOUT_MS))
				{
                    continue;
				}
				
				if(i + restPackageSum <= allPackageSum)	// copy all singlerawbuf
				{
// 					if(curRawBufLength * singleChannelRawDataLen + singleChannelRawDataLen 
// 						> MAX_RAWDATA_BUF_LENGTH)
// 					{
// 						curRawBufLength = 0;
// 					}
					if(restPackageSum == singlePackageSum)
					{
						memcpy(&rawBuf[curRawBufLength * singleChannelRawDataLen], 
							&recvbuffer[i * DATA_BLOCK_SIZE],
							singleChannelRawDataLen);
					}
					else 
					{
						memcpy(&rawBuf[curRawBufLength * singleChannelRawDataLen], 
							ppOpenedDevTab[nIndex]->restPackageData, 
							(singlePackageSum - restPackageSum) * DATA_BLOCK_SIZE);
						memcpy(&rawBuf[curRawBufLength * singleChannelRawDataLen + (singlePackageSum - restPackageSum) * DATA_BLOCK_SIZE], 
							&recvbuffer[i * DATA_BLOCK_SIZE],
							singleChannelRawDataLen - (singlePackageSum - restPackageSum) * DATA_BLOCK_SIZE);				
					}
					curRawBufLength++;
					i += restPackageSum;
					restPackageSum = singlePackageSum;
				}
				else	// not enough a singleraw buf 
				{
					memcpy(ppOpenedDevTab[nIndex]->restPackageData + (singlePackageSum - restPackageSum) * DATA_BLOCK_SIZE,
						&recvbuffer[i * DATA_BLOCK_SIZE], 
						(allPackageSum - i) * DATA_BLOCK_SIZE );
					restPackageSum -= (allPackageSum - i);
					i = allPackageSum;
				}
				ppOpenedDevTab[nIndex]->restPackageCard = restPackageSum;
				ReleaseMutex(WaveMutex);
			}
			else if ((ppOpenedDevTab[nIndex]->restFftPackageCard < singleFftPackageSum)
				|| ((ppOpenedDevTab[nIndex]->restPackageCard >= singlePackageSum)
			//	&& ((*(unsigned short *)&recvbuffer[i * DATA_BLOCK_SIZE]) == 0xC000))) 
				&& (((*(unsigned short *)&recvbuffer[i * DATA_BLOCK_SIZE]) & 0xC000) == 0xC000)))   //FFT Wave
			{
				restPackageSum = ppOpenedDevTab[nIndex]->restFftPackageCard;

				while(curFftBufLength >= maxFftBufLength)
                {
                    if (enuSampleIdle == SysState)
                    {
                        return;
                    }
                }
                if(WAIT_OBJECT_0 != WaitForSingleObject(FftMutex, SYNC_TIMEOUT_MS))
				{
                    continue;
				}
				
				if(i + restPackageSum <= allPackageSum) 
				{
// 					if(curFftBufLength * singleFftBufLen + singleFftBufLen 
// 						> MAX_FFTDATA_BUF_LENGTH)
// 					{
// 						curFftBufLength = 0;
// 					}
					if(restPackageSum == singleFftPackageSum)
					{
						memcpy(&fftBuf[curFftBufLength * singleFftBufLen],
							&recvbuffer[i*DATA_BLOCK_SIZE], singleFftBufLen);
					}
					else 
					{
						memcpy(&fftBuf[curFftBufLength * singleFftBufLen], 
							ppOpenedDevTab[nIndex]->restFftPackageData, 
							(singleFftPackageSum - restPackageSum) * DATA_BLOCK_SIZE );
						memcpy(&fftBuf[curFftBufLength * singleFftBufLen + (singleFftPackageSum - restPackageSum) * DATA_BLOCK_SIZE], 
							&recvbuffer[i * DATA_BLOCK_SIZE],
							singleFftBufLen - (singleFftPackageSum - restPackageSum) * DATA_BLOCK_SIZE );				
					}
					curFftBufLength ++;
					i += restPackageSum;
					restPackageSum = singleFftPackageSum;
				}
				else 
				{
					memcpy(ppOpenedDevTab[nIndex]->restFftPackageData + (singleFftPackageSum - restPackageSum) * DATA_BLOCK_SIZE, 
						&recvbuffer[i * DATA_BLOCK_SIZE],
						(allPackageSum - i) * DATA_BLOCK_SIZE );
					restPackageSum -= (allPackageSum - i);
					i = allPackageSum;
				}
				ppOpenedDevTab[nIndex]->restFftPackageCard = restPackageSum;
				ReleaseMutex(FftMutex);
			}
		//	else// if (((*(unsigned short *)&recvbuffer[i*DATA_BLOCK_SIZE]) & 0xC000) == 0x4000)   //Hit Data
			else// if(((*(unsigned short *)&recvbuffer[i * DATA_BLOCK_SIZE]) & 0xf000) == 0)
			{
				if(WAIT_OBJECT_0 != WaitForSingleObject(ParamMutex, SYNC_TIMEOUT_MS))
				{
					continue;
				}
			//	if(ParamType == enFixedLen)
				{
					//����֡���뷽ʽ0
					PARAM *curParam =(PARAM *)&recvbuffer[i * DATA_BLOCK_SIZE];
					for(int j = 0;  j < PARAM_NUM_IN_DATA_PACK; j++, curParam++)
					{
						if ((curParam->ArriveTime.Time1 == 0) && (curParam->ArriveTime.Time2 == 0))
						{
							break;
						}
						//curSysTime = *(ULONGLONG*)(&curParam->ArriveTime) & PARAM_TIME_MASK;		//zch_2011_12_24 �κβ���֡�����µ�ǰʱ��
						FRAME_FLAG *pFrmFlag = (FRAME_FLAG *)curParam;
					/*	if((curParam->ChNo & 0xE000) == STATE_FLAG)
						{
							//״̬֡
							STPARAM_TYPE_0 *tempStParam = (STPARAM_TYPE_0 *)curParam;
							DWORD cardno = pFrmFlag->spec.card;
							ChStreamingState[cardno] = tempStParam->Ch0_State;
							//	ChStreamingState[cardno * CHANNEL_NUMBER_PERCARD + 1] = tempStParam->Ch1_State;
						}*/
						if ((curParam->ChNo & 0xE000) == SYSTIME_FLAG)
						{
							//ʱ��֡						   
							SysTimeFIFO.pushsingle(curParam);
						}
						else if((curParam->ChNo & 0xE000) == 0x6000)
					//	else if (curParam->AllRing == 0)
						{
							//���֡
							DWORD cardno = pFrmFlag->spec.card;
							if(cardno < 0 || cardno >= devs.MaxDevNum)
							{
								i++;
								continue;
							}
							exParamBuf[cardno] = curParam->exparam[0];
					//		exParamBuf[cardno * 4 + 1] = curParam->exparam[1];
					//		exParamBuf[cardno * 4 + 2] = curParam->exparam[2];
					//		exParamBuf[cardno * 4 + 3] = curParam->exparam[3];
							memcpy(curParam->exparam, exParamBuf, sizeof(short) * 12);
							ExParamFIFO.pushsingle(curParam);
						}
						else if((curParam->ChNo & 0xF000) == 0)
						{
							//��ͨ����֡
						//	DWORD chno = pFrmFlag->spec.card * MAX_SOCKET_NUM + pFrmFlag->spec.ChOfCard;
							DWORD chno = pFrmFlag->spec.card;
							//if(chno >= 0 && chno < devs.MaxDevNum)
							if (chno == nIndex)
							{
								if (exParamEn)
								{
									memcpy(curParam->exparam, exParamBuf, sizeof(short) * 5);
								}

								ppOpenedDevTab[nIndex]->ParamFIFO.pushsingle(curParam);
							}
						}					   
					}
					i++;
				}
				ReleaseMutex(ParamMutex);
			}
//             else    //Wrong Data
//             {
//                 i++;
//             }
			break;
        }
	}
}

/*******************************************************************************
 Function Name:	CmdCommProc
 Description  : ����ͨ������������ִ������ͨ�������Ķ�д����
 Input        :	unsigned short card    --- �忨��
				int authority          --- ����Ȩ�ޣ����enuCmdOperateAuth
                unsigned char McuCmd   --- ��Ƭ������
				unsigned char FpgaCmd  --- FPGA����
                unsigned char FpgaAddr --- FPGA��ַ
				unsigned int *dat      --- ���ݵ�ַ
 Output       :
 Return       :
 Note         : �ɹ�����TRUE��ʧ�ܷ���FALSE                           			   
*******************************************************************************/
BOOL SocketHardware::CmdCommProc(unsigned short card, int authority,
								 unsigned char McuCmd, unsigned char FpgaCmd = 0,
								 unsigned char FpgaAddr = 0, unsigned int *dat = NULL)
{
#ifdef DEBUG_VIEW_OUTPUT
	/************************************************************************/
	char debug_str[250];
	int cnt = 0;
	/************************************************************************/
#endif

	int i;
	//SOCKET sk = INVALID_SOCKET;
	PDEV_NODE pDev = NULL;
	int RepeatNum = 0;
	DWORD rtn;
	HANDLE hThreadTransCmd;	//���������߳�
	//HANDLE hCmdResponsed = NULL;	//������Ӧͬ���ź�
	SOCKET sk = INVALID_SOCKET;
	BOOL stat;
	
	if(card >= devs.MaxDevNum)
	{
		return FALSE;
	}

	switch (authority)
	{
	case enuDeviceAvailable:
		for (i = 0; i < devs.MaxDevNum; i++)
		{
			if (devs.pDev[i].DevNo == card)
			{
				pDev = &devs.pDev[i];

				//��¼�豸ʹ��״̬
				stat = pDev->enalbed;
				
				//ǿ������Ϊ��״̬
				SetCardEnable(card, TRUE);

				break;
			}
		}
		break;
	case enuDeviceEnabled:
		if (ppOpenedDevTab[card] && ppOpenedDevTab[card]->enalbed)
		{
			pDev = ppOpenedDevTab[card];
		}
		break;
	default:
		return FALSE;
	}

	if (!pDev)
	{
		return FALSE;
	}

	do 
	{
		for (i = 0; i < clients.SockNum; i++)
		{
			if (clients.pSock[i].sk == pDev->CmdSock)
			{
				break;
			}
		}
		if (i >= clients.SockNum)
		{
			RepeatNum++;
			continue;
		}

		//����׽����Ƿ�仯
		if (sk != clients.pSock[i].sk)
		{
			sk = clients.pSock[i].sk;
			RepeatNum = 0;
		}
	
		//����buffer��ֵ
		PCMD_PACK pcmd = &clients.pSock[i].CmdTrans;
		pcmd->flag = htons(CMD_FLAG);
		pcmd->index = htons(pDev->seq);
		pcmd->type = enuCmdTrans;
		pcmd->McuCmd = McuCmd;
		switch (McuCmd)
		{
		case enuMcuCmdWifiPowerSet:
			pcmd->FpgaCmd = 0;
			pcmd->FpgaAddr = 0;
			pcmd->dat.command.dat = htonl(*dat);
			memset(pcmd->dat.command.reserved, 0, sizeof(pcmd->dat.command.reserved));
			break;
		case enuMcuCmdWriteRegister:
			pcmd->FpgaCmd = enuFpgaCmdWriteRegister;
			pcmd->FpgaAddr = FpgaAddr;
			pcmd->dat.command.dat = htonl(*dat);
			memset(pcmd->dat.command.reserved, 0, sizeof(pcmd->dat.command.reserved));
			break;
		case enuMcuCmdReadRegister:
			pcmd->FpgaCmd = enuFpgaCmdReadRegister;
			pcmd->FpgaAddr = FpgaAddr;
			pcmd->dat.command.dat = 0;
			memset(pcmd->dat.command.reserved, 0, sizeof(pcmd->dat.command.reserved));
			break;
		case enuMcuCmdGpsPrepare:
		case enuMcuCmdWifiPrepare:
		case enuMcuCmdSync:
		case enuMcuCmdGpsRead:
		case enuMcuCmdWifiRead:
		case enuMcuCmdResetFpga:
		default:
			pcmd->FpgaCmd = 0;
			pcmd->FpgaAddr = 0;
			pcmd->dat.command.dat = 0;
			memset(pcmd->dat.command.reserved, 0, sizeof(pcmd->dat.command.reserved));
			break;
		}

#ifdef DEBUG_VIEW_OUTPUT
		/************************************************************************/
		switch (McuCmd)
		{
		case enuMcuCmdGpsPrepare:
			sprintf(debug_str, "Prepare GPS data id %u, socket %x, cnt %u\n", card, clients.pSock[i].sk, cnt++);
			break;
		case enuMcuCmdWifiPrepare:
			sprintf(debug_str, "Prepare WIFI data id %u, socket %x, cnt %u\n", card, clients.pSock[i].sk, cnt++);
			break;
		case enuMcuCmdSync:
			sprintf(debug_str, "Synchronization id %u, socket %x, cnt %u\n", card, clients.pSock[i].sk, cnt++);
			break;
		case enuMcuCmdResetFpga:
			sprintf(debug_str, "ResetFpga id %u, socket %x, cnt %u\n", card, clients.pSock[i].sk, cnt++);
			break;
		case enuMcuCmdGpsRead:
			break;
		case enuMcuCmdWifiRead:
			break;
		case enuMcuCmdWifiPowerSet:
			break;
		case enuMcuCmdWriteRegister:
			sprintf(debug_str, "WriteRegister id %u, socket %x, addr %x, data %x, cnt %u\n", card, clients.pSock[i].sk, FpgaAddr, *dat, cnt++);
			break;
		case enuMcuCmdReadRegister:
			sprintf(debug_str, "ReadRegister id %u, socket %x, addr %x, data %x, cnt %u\n", card, clients.pSock[i].sk, FpgaAddr, *dat, cnt++);
			break;
		default:
			sprintf(debug_str, "Invalid cmd id %u, socket %x, cnt %u\n", card, clients.pSock[i].sk, cnt++);
			break;
		}

		/************************************************************************/
#endif
	
		//��������ۼ�
		if (pDev->seq < PACK_INDEX_MAX)
		{
			pDev->seq++;
		}
		else
		{
			pDev->seq = 0;
		}
	
		//Ԥ�跢���̵߳�ͨ����
		CurrentDev = card;

		//��ʼ��������
		clients.pSock[i].ErrCode = enuOk;
	
		//����	
		hThreadTransCmd = CreateThread(NULL, 0, SendCmdThread, this, 0, NULL);

		rtn = WaitForSingleObject(hThreadTransCmd, COMM_TIMEOUT_MS);
	
		if (WAIT_OBJECT_0 != rtn)
		{
			clients.pSock[i].ErrCode = enuTransError;

			RepeatNum++;
			continue;
		}

		//�������
		rtn = WaitForSingleObject(clients.pSock[i].hCmdResponsed, COMM_TIMEOUT_MS);
	
		if (WAIT_OBJECT_0 != rtn)
		{
			clients.pSock[i].ErrCode = enuRecvError;

			RepeatNum++;
			continue;
		}

		if (clients.pSock[i].ErrCode != enuOk)
		{

			RepeatNum++;
			continue;
		}
		else
		{
			break;
		}	

	} while (RepeatNum < COMM_RETRY_NUM);

	switch (authority)
	{
	case enuDeviceAvailable:
		//�ָ�Ϊ֮ǰ���õ�״̬
		SetCardEnable(card, stat);
		break;
	case enuDeviceEnabled:
		break;
	default:
		break;
	}

	if (RepeatNum < COMM_RETRY_NUM)
	{
		switch (McuCmd)
		{
		case enuMcuCmdGpsPrepare:
			break;
		case enuMcuCmdWifiPrepare:
			break;
		case enuMcuCmdSync:
			break;
		case enuMcuCmdResetFpga:
			break;
		case enuMcuCmdGpsRead:
			*dat = ntohl(clients.pSock[i].CmdRecv.dat.command.dat);
			break;
		case enuMcuCmdWifiRead:
			*dat = ntohl(clients.pSock[i].CmdRecv.dat.command.dat);
			break;
		case enuMcuCmdWifiPowerSet:
			break;
		case enuMcuCmdWriteRegister:
			break;
		case enuMcuCmdReadRegister:
			*dat = ntohl(clients.pSock[i].CmdRecv.dat.command.dat);
			break;
		default:
			break;
		}		

		return TRUE;
	}
	
	switch (McuCmd)
	{
	case enuMcuCmdGpsPrepare:
		SocketError |= enSocketWriteError;
		break;
	case enuMcuCmdWifiPrepare:
		SocketError |= enSocketWriteError;
		break;
	case enuMcuCmdSync:
		SocketError |= enSocketWriteError;
		break;
	case enuMcuCmdResetFpga:
		SocketError |= enSocketWriteError;
		break;
	case enuMcuCmdGpsRead:
		SocketError |= enSocketReadError;
		break;
	case enuMcuCmdWifiRead:
		SocketError |= enSocketReadError;
		break;
	case enuMcuCmdWifiPowerSet:
		SocketError |= enSocketWriteError;
		break;
	case enuMcuCmdWriteRegister:
		SocketError |= enSocketWriteError;
		break;
	case enuMcuCmdReadRegister:
		SocketError |= enSocketReadError;
		break;
	default:
		break;
	}

	return FALSE;
}
	

/*******************************************************************************
 Function Name:	ResetCardFpga
 Description  : ��λ�忨FPGAоƬ���ָ�����ʼ״̬��֮ǰ������ȫ����ʧ����Ҫ��������
 Input        :	unsigned short CardNo  --- �忨��
 Output       :
 Return       :
 Note         : �ɹ�����TRUE��ʧ�ܷ���FALSE                           			   
*******************************************************************************/
BOOL SocketHardware::ResetCardFpga(unsigned short CardNo)
{
	return CmdCommProc(CardNo, enuDeviceAvailable, enuMcuCmdResetFpga);
}

/*******************************************************************************
 Function Name:	DevSynchronize
 Description  : �豸ͬ������
 Input        :	
 Output       :
 Return       :
 Note         : �ɹ�����TRUE��ʧ�ܷ���FALSE                           			   
*******************************************************************************/
BOOL SocketHardware::DevSynchronize()
{
	#ifdef DEBUG_VIEW_OUTPUT
	/************************************************************************/
	char debug_str[250];
	int cnt = 0;
	/************************************************************************/
#endif

	int i;
	int j;
	//SOCKET sk = INVALID_SOCKET;
	PDEV_NODE pDev = NULL;
	int RepeatNum = 0;
	DWORD rtn;
	HANDLE *hThreadTransCmd;	//���������߳�
	HANDLE *hCmdResponsed;		//�������ͬ����Ϣ
	UINT ValidSyncObjectsNum = 0;	//��Чͬ����������
	//HANDLE hCmdResponsed = NULL;	//������Ӧͬ���ź�
	SOCKET sk = INVALID_SOCKET;
	
	if (openCardNum <= 0)
	{
		return FALSE;
	}

// 	if (openCardNum == 1)
// 	{
// 		return TRUE;
// 	}

	hThreadTransCmd = new HANDLE[openCardNum];
	memset(hThreadTransCmd, 0, openCardNum * sizeof(HANDLE));
	hCmdResponsed = new HANDLE[openCardNum];
	memset(hCmdResponsed, 0, openCardNum * sizeof(HANDLE));

	//��ʼ���豸����˳���
	DevOperatingIndex = 0;

	for (j = 0; j < openCardNum; j++)
	{
		if ((OpenedDevIndexTab[j] >= devs.MaxDevNum)
			|| (NULL == ppOpenedDevTab[OpenedDevIndexTab[j]])
			|| (FALSE == ppOpenedDevTab[OpenedDevIndexTab[j]]->enalbed)
			)
		{
			continue;
		}

		pDev = ppOpenedDevTab[OpenedDevIndexTab[j]];
		RepeatNum = 0;
		sk = INVALID_SOCKET;

		do 
		{
			for (i = 0; i < clients.SockNum; i++)
			{
				if (clients.pSock[i].sk == pDev->CmdSock)
				{
					break;
				}
			}
			if (i >= clients.SockNum)
			{
				RepeatNum++;
				continue;
			}

			//����׽����Ƿ�仯
			if (sk != clients.pSock[i].sk)
			{
				sk = clients.pSock[i].sk;
				RepeatNum = 0;
			}

			//hCmdResponsed = clients.pSock[i].hCmdResponsed;
		
			//����buffer��ֵ
			PCMD_PACK pcmd = &clients.pSock[i].CmdTrans;
			pcmd->flag = htons(CMD_FLAG);
			pcmd->index = htons(pDev->seq);
			pcmd->type = enuCmdTrans;
			pcmd->McuCmd = enuMcuCmdSync;
			pcmd->FpgaCmd = 0;
			pcmd->FpgaAddr = 0;
			pcmd->dat.command.dat = 0;
			memset(pcmd->dat.command.reserved, 0, sizeof(pcmd->dat.command.reserved));

		
			//��������ۼ�
			if (pDev->seq < PACK_INDEX_MAX)
			{
				pDev->seq++;
			}
			else
			{
				pDev->seq = 0;
			}
		
			//Ԥ�跢���̵߳�ͨ����
			CurrentDev = ALL_OPENED_DEVS;

			//��ʼ��������
			clients.pSock[i].ErrCode = enuOk;
		
			//����	
			hThreadTransCmd[ValidSyncObjectsNum] = CreateThread(NULL, 0, SendCmdThread, this, 0, NULL);

			//�������
			hCmdResponsed[ValidSyncObjectsNum] = clients.pSock[i].hCmdResponsed;

			ValidSyncObjectsNum++;

			break;

		} while (RepeatNum < COMM_RETRY_NUM);
	}

	if (ValidSyncObjectsNum > 0)
	{
		//�ȴ�����
		rtn = WaitForMultipleObjects(ValidSyncObjectsNum, hThreadTransCmd, TRUE, COMM_TIMEOUT_MS);

		if ((WAIT_OBJECT_0 > rtn) || ((WAIT_OBJECT_0 + ValidSyncObjectsNum) <= rtn))
		{
			SocketError = enSocketSynchronousEror;
		}
		else
		{
			//�ȴ��������
			rtn = WaitForMultipleObjects(ValidSyncObjectsNum, hCmdResponsed, TRUE, COMM_TIMEOUT_MS);

			if ((WAIT_OBJECT_0 > rtn) || ((WAIT_OBJECT_0 + ValidSyncObjectsNum) <= rtn))
			{
				SocketError = enSocketSynchronousEror;
			}
		}
	}
	else
	{
	}

	if (hThreadTransCmd)
	{
		delete []hThreadTransCmd;
	}
	
	if (hCmdResponsed)
	{
		delete []hCmdResponsed;
	}

	if (enSocketSynchronousEror != SocketError)
	{
		return TRUE;
	}
	
	return FALSE;
}

/*******************************************************************************
 Function Name:	SetCardEnable
 Description  : �����豸ʹ��״̬
 Input        :	unsigned short CardNo --- �豸��
                BOOL enabled          --- ʹ�ܱ�ǣ����ʾʹ�ܣ��ٱ�ʾ��ʹ��
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetCardEnable(unsigned short CardNo, BOOL enabled)
{
	int i;
	int j;
	
	for (i = 0; i < devs.MaxDevNum; i++)
	{
		if (devs.pDev[i].DevNo == CardNo)
		{
			devs.pDev[i].enalbed = enabled;

			for (j = 0; j < clients.SockNum; j++)
			{
				if (clients.pSock[j].sk == devs.pDev[i].CmdSock)
				{
					clients.pSock[j].enalbed = enabled;
					break;
				}
			}

			for (j = 0; j < clients.SockNum; j++)
			{
				if (clients.pSock[j].sk == devs.pDev[i].DataSock)
				{
					clients.pSock[j].enalbed = enabled;
					break;
				}
			}
			return TRUE;
		}
	}

	return FALSE;
}

/*******************************************************************************
 Function Name:	Pcm16bitWaveConvert
 Description  : PCM16λ��������ת��
 Input        :	unsigned short CardNo --- �豸��
                BOOL enabled          --- ʹ�ܱ�ǣ����ʾʹ�ܣ��ٱ�ʾ��ʹ��
				char* des     --- Ŀ���������ַ
				char* src     --- ԭʼ���ݻ����ַ
				DWORD frm_num --- ��ת����֡��
 Output       :
 Return       : 
 Note         :                            			   
*******************************************************************************/
void SocketHardware::Pcm16bitWaveConvert(char* des, char* src, DWORD frm_num)
{
	if ((openCardNum <= 0) || (!ppOpenedDevTab[OpenedDevIndexTab[0]]))
	{
		return;
	}

	UINT FrmVer = ppOpenedDevTab[OpenedDevIndexTab[0]]->FrmVer;
	UINT FrmEncodeType = ppOpenedDevTab[OpenedDevIndexTab[0]]->FrmEncodeType;

    if ((FrmVer != 0) || ((FrmEncodeType != en16BitsPcm) && (FrmEncodeType != en18BitsPcm)))
    {
        return;
    }

    int i, k;

    int *pData;
    short *pDpcm;


    for (i = 0; i < frm_num; i++)
    {
        memcpy(&des[i * singleChannelBufLen], &src[i * singleChannelRawDataLen], 8);

        pData = (int*)&des[i * singleChannelBufLen + 8];
        pDpcm = (short*)&src[i * singleChannelRawDataLen + 8];
        
        for (k = 0; k < SampleLen; k++)
        {
			if (FrmEncodeType == en16BitsPcm)
			{
				pData[k] = (((int)pDpcm[k]) << 16) >> 14;
			}
			else if(FrmEncodeType == en18BitsPcm)
			{
				pData[k] = ((int)(pDpcm[k] & 0xFFF8) << 16) >> (19 - (pDpcm[k] & 0x0007));
			}
        }
    }
}

/*******************************�ⲿ�ӿں���***********************************/

/*******************************************************************************
 Function Name:	OpenCard
 Description  : �򿪰忨���԰忨���в����ĵ�һ��
 Input        :	BOOL *bDeviceFlag  --- �豸����������飬���ʾ���ø��豸��
                                       �ٱ�ʾ�����ø��豸
                DWORD SampleLength --- ��������
				BOOL reset         --- ��λ��ǣ����ʾ��λ�豸���ٱ�ʾ����λ�豸
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
void SocketHardware::OpenCard(BOOL *bDeviceFlag, DWORD SampleLength, BOOL reset)
{
    UCHAR bufOutput[32];
    DWORD dwOpenSum = 0;
	UINT regvalue=0;
	int i;
	int j;

	openCardNum = 0;
	memset(ppOpenedDevTab, 0, devs.MaxDevNum * sizeof(PDEV_NODE));
	memset(OpenedDevIndexTab, 0xff, devs.MaxDevNum * sizeof(UINT));

	for(i =0; i < devs.MaxDevNum; i++)
	{
		// device is exist and to be opened
		if (IS_DEV_EXIST(devs, i))
		{
			if (!bDeviceFlag[i])
			{
				devs.pDev[i].enalbed = FALSE;

				SetCardEnable(devs.pDev[i].DevNo, devs.pDev[i].enalbed);
			}
			else
			{
				devs.pDev[i].enalbed = TRUE;

				SetCardEnable(devs.pDev[i].DevNo, devs.pDev[i].enalbed);

				OpenedDevIndexTab[dwOpenSum] = devs.pDev[i].DevNo;
				ppOpenedDevTab[OpenedDevIndexTab[dwOpenSum]] = &devs.pDev[i];
				dwOpenSum ++;

				if (reset)
				{
					ResetCardFpga(devs.pDev[i].DevNo);	//RST_FPGA
				}
				
// 				//����ȫ�ֳɰ����ԼĴ���
// 				GLB_PKG_PROP PkgCfg;
// 				PkgCfg.cmd = 0;
// 				PkgCfg.spec.ver = devs.pDev[i].PackVer;
// 				WriteRegister(i, PROP_GLB_REG_BASEADDR + PROP_GLB_PKG_REG, PkgCfg.cmd);
// 				
// 				//����ȫ�ֳ�֡���ԼĴ���
// 				GLB_FRM_PORP FrmCfg;
// 				FrmCfg.cmd = 0;
// 				FrmCfg.spec.TimeFrmEncode = ParamType;
// 				FrmCfg.spec.HitFrmEncode = ParamType;
// 				FrmCfg.spec.WaveFrmEncode = devs.pDev[i].FrmEncodeType;
// 				FrmCfg.spec.ver = devs.pDev[i].FrmVer;
// 				WriteRegister(devs.pDev[i].DevNo, PROP_GLB_REG_BASEADDR + PROP_GLB_FRM_REG, FrmCfg.cmd);
// 				
// 				//����ȫ��DPCM�������ԼĴ���
// 				GLB_DPCM_PROP DpcmCfg;
// 				DpcmCfg.cmd = 0;
// 				DpcmCfg.spec.bits = devs.pDev[i].FrmDpcmBits;
// 				WriteRegister(devs.pDev[i].DevNo, PROP_GLB_REG_BASEADDR + PROP_GLB_DPCM_REG, DpcmCfg.cmd);
				
				//����ȫ��ͬ��ģʽ�Ĵ���
				GLB_SYNC_PROP SyncCfg;
				SyncCfg.cmd = 0;
				if (bGpsSyncEnabled)
				{
					SyncCfg.spec.SyncEn = 1;
				}
				WriteRegister(devs.pDev[i].DevNo, PROP_GLB_REG_BASEADDR + PROP_GLB_SYNC_REG, SyncCfg.cmd);
			}
			for (j = 0; j < clients.SockNum; j++)
			{
				if (clients.pSock[j].sk == devs.pDev[i].CmdSock)
				{
					clients.pSock[j].enalbed = devs.pDev[i].enalbed;
				}
				if (clients.pSock[j].sk == devs.pDev[i].DataSock)
				{
					clients.pSock[j].enalbed = devs.pDev[i].enalbed;
				}
			}
		}
	}
	openCardNum = dwOpenSum;
	SampleLen = SampleLength;

	singleChannelBufLen = 0;
    singleChannelRawDataLen = 0;
	maxRawBufLength = 0;
	curRawBufLength = 0;

	if (dwOpenSum == 0)
	{
		return;
	}
	
	//Ϊͨ��chParamFIFO����ռ�
	if (dwOpenSum != 0)
	{
		for (i = 0; i < devs.MaxDevNum; i++)
		{
			devs.pDev[i].ParamFIFO.ReleaseBuf();
		}

		for (i = 0; i < dwOpenSum; i++)
		{
			ppOpenedDevTab[OpenedDevIndexTab[i]]->ParamFIFO.AllocateBuf(HIT_PARAM_BUF_LENGTH / dwOpenSum);	//ͨ��ײ������buffer
		}

// 		chParamFIFO[dwOpenSum].AllocateBuf(SYSTIME_PARAM_BUF_LENGTH);							//ϵͳʱ��֡buffer
// 		chParamFIFO[dwOpenSum + 1].AllocateBuf(EXP_PARAM_BUF_LENG);								//���֡buffer
	}

	UINT FrmVer = ppOpenedDevTab[OpenedDevIndexTab[0]]->FrmVer;
	UINT FrmEncodeType = ppOpenedDevTab[OpenedDevIndexTab[0]]->FrmEncodeType;
	UINT FrmDpcmBits = ppOpenedDevTab[OpenedDevIndexTab[0]]->FrmDpcmBits;

    switch (FrmVer)
    {
    case 1:
        switch (FrmEncodeType)
        {
        case en16BitsPcm:
            singleChannelRawDataLen = 0;
            break;
        case en18BitsPcm:
            singleChannelRawDataLen = 0;
            break;
        case en18BitsMixed:
            singleChannelRawDataLen = 0;
            break;
        case enDpcm:
            singleChannelRawDataLen = 0;
            break;
        case enOneBitDpcm:
            singleChannelRawDataLen = 0;
            break;
        default:
            singleChannelRawDataLen = 0;
        }
        singleChannelBufLen = 0;
        break;
    case 0:
    default:
        switch (FrmEncodeType)
        {
        case en16BitsPcm:
            singleChannelRawDataLen = (SampleLen << 1 ) + 8;
            break;
        case en18BitsPcm:
			singleChannelRawDataLen = (SampleLen << 1 ) + 8;
 //           singleChannelRawDataLen = (SampleLen * 18 + 7) / 8 + 8;
            break;
        case en18BitsMixed:
            singleChannelRawDataLen = 0;
            break;
        case enDpcm:
            singleChannelRawDataLen = (SampleLen * (FrmDpcmBits + 1) + 7) / 8 + 8;
            break;
        case enOneBitDpcm:
            singleChannelRawDataLen = (SampleLen + 7) / 8 + 8;
            break;
        default:
            singleChannelRawDataLen = (SampleLen << 1 ) + 8;
        }
        singleChannelBufLen = (SampleLen << 2 ) + 8;
        break;
    }
	
	if (FrmDpcmBits < 8)
	{
		maxRawBufLength = MAX_RAWDATA_BUF_LENGTH / MAX_SAMPLE_LENGTH;
	}
	else
	{
		maxRawBufLength = MAX_RAWDATA_BUF_LENGTH / singleChannelRawDataLen;
	}
	
    //maxRawBufLength = MAX_RAWDATA_BUF_LENGTH/singleChannelBufLen;
	singlePackageSum = singleChannelRawDataLen % DATA_BLOCK_SIZE ?  singleChannelRawDataLen/DATA_BLOCK_SIZE + 1: singleChannelRawDataLen/DATA_BLOCK_SIZE;

    for(i = 0; i < openCardNum; i++)
	{
	   ppOpenedDevTab[OpenedDevIndexTab[i]]->restPackageCard = singlePackageSum;
	   if (ppOpenedDevTab[OpenedDevIndexTab[i]]->restPackageData)
	   {
		   delete []ppOpenedDevTab[OpenedDevIndexTab[i]]->restPackageData;
	   }
	   ppOpenedDevTab[OpenedDevIndexTab[i]]->restPackageData = new UCHAR[singleChannelRawDataLen];
	}

    curFftBufLength = 0;
    singleFftBufLen = (MAX_FFTDATA_LENGTH << 1) + 8;
    maxFftBufLength = MAX_FFTDATA_BUF_LENGTH / singleFftBufLen;
    singleFftPackageSum = singleFftBufLen % DATA_BLOCK_SIZE ?  singleFftBufLen/DATA_BLOCK_SIZE + 1: singleFftBufLen/DATA_BLOCK_SIZE;
    for(i = 0; i < openCardNum; i++)
    {
        ppOpenedDevTab[OpenedDevIndexTab[i]]->restFftPackageCard = singleFftPackageSum;
		if (ppOpenedDevTab[OpenedDevIndexTab[i]]->restFftPackageData)
		{
			delete []ppOpenedDevTab[OpenedDevIndexTab[i]]->restFftPackageData;
		}
        ppOpenedDevTab[OpenedDevIndexTab[i]]->restFftPackageData = new UCHAR[singleFftBufLen];
	}

    if (reset)
    {
		for(i = 0; i < openCardNum; i++)
		{
			ppOpenedDevTab[OpenedDevIndexTab[i]]->bStartStreamingInternalTrig = FALSE;
		}
    }
	memset(exParamBuf, 0, sizeof(short) * devs.MaxDevNum);

	for(i = 0; i < openCardNum; i++)
	{
		ppOpenedDevTab[OpenedDevIndexTab[i]]->ChStreamingState = 0;
	}
    if (reset)
    {
        //bHardParam = FALSE;
		for(i = 0; i < openCardNum; i++)
		{
			ppOpenedDevTab[OpenedDevIndexTab[i]]->bParamEn = FALSE;
		}
    }

//	return dwOpenSum;
}

/*******************************************************************************
 Function Name:	SetCardParamThreshold
 Description  : �豸ͨ����������
 Input        :	unsigned short chanNo  --- ͨ����
                DWORD value            --- ��������
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetCardParamThreshold(unsigned short chanNo, DWORD value)
{
	int i;
	unsigned short CardNo;
	CardNo = chanNo / CHANNEL_NUMBER_PERCARD;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return FALSE;
	}

	CH_HIT_THRESHOLD_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.threshold = value;

	WriteRegister(CardNo, ChRegBaseAddrs[chanNo % CHANNEL_NUMBER_PERCARD] + PROP_CH_HIT_THRESHOLD_REG, RegVal.cmd);

	return TRUE;
}

/*******************************************************************************
 Function Name:	SetCardSampleThreshold
 Description  : �豸ͨ����������
 Input        :	unsigned short chanNo  --- ͨ����
                DWORD value            --- ��������
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetCardSampleThreshold(unsigned short chanNo, DWORD value)
{
	int i;
	unsigned short CardNo;
	CardNo = chanNo / CHANNEL_NUMBER_PERCARD;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return FALSE;
	}

	CH_WAVE_THRESHOLD_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.threshold = value;

	WriteRegister(CardNo, ChRegBaseAddrs[chanNo % CHANNEL_NUMBER_PERCARD] + PROP_CH_WAVE_THRESHOLD_REG, RegVal.cmd);

	WaveThreshold[chanNo] = value;			
	return TRUE;
}

/*******************************************************************************
 Function Name:	SetCardSampleLength
 Description  : �豸�忨���γ���
 Input        :	unsigned short CardNo  --- �忨��
                DWORD value            --- ���γ���
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetCardSampleLength(unsigned short CardNo, DWORD value)
{
	int i;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return FALSE;
	}
	
	CH_SAMPLEN_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.SampLen = value;

	for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
	{
		WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_SAMP_LEN_REG, RegVal.cmd);
	}
	return TRUE;
}

/*******************************************************************************
 Function Name:	GetCardSampleFreq
 Description  : ����豸�忨������
 Input        :	unsigned short CardNo  --- �忨��
                WORD *value            --- �����ʷ���ֵ��ַ
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::GetCardSampleFreq(unsigned short CardNo, WORD *value)
{
	int i;
	CH_SAMPRATE_PROP RegVal;
	RegVal.cmd = 0;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return FALSE;
	}
	
		
	for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
	{
		RegVal.cmd = 0;
		ReadRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_SAMP_RATE_REG, (UINT*)&RegVal.cmd);
		
		if (RegVal.spec.SampRate == 0)
		{
			SocketError |= enSocketReadError;
			return FALSE;
		}
	}

	*value = RegVal.spec.SampRate;

	return TRUE;
}

/*******************************************************************************
 Function Name:	SetCardSampleFreq
 Description  : ���ð忨������
 Input        :	unsigned short CardNo  --- �忨��
                WORD value             --- ������
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetCardSampleFreq(unsigned short CardNo, WORD value)
{
	int i;
	CH_SAMPRATE_PROP RegVal;
    RegVal.cmd = 0;
    RegVal.spec.SampRate = value;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return FALSE;
	}

	for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
	{
		WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_SAMP_RATE_REG, RegVal.cmd);
	}
	return TRUE;
}

/*******************************************************************************
 Function Name:	SetCardParamEventInterval
 Description  : ���ð忨�������
 Input        :	unsigned short CardNo  --- �忨��
                WORD value             --- �������
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetCardParamEventInterval(unsigned short CardNo, DWORD value)
{
	int i;
	UINT regvalue;
	CH_EVEINTER_CFG_PROP RegVal;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return FALSE;
	}

	for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
	{
		RegVal.spec.hdt = value;
		WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_EVENT_INTERVAL_REG, RegVal.cmd);
	}
	return TRUE;
}

/*******************************************************************************
 Function Name:	SetCardParamEventLockOut
 Description  : ���ð忨��������ʱ��
 Input        :	unsigned short CardNo  --- �忨��
                WORD value             --- ����ʱ��
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetCardParamEventLockOut(unsigned short CardNo, DWORD value)
{
	int i;
	UINT regvalue;
	CH_LOCKOUT_CFG_PROP RegVal;
	
	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return FALSE;
	}

	for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
	{
		RegVal.spec.hlt = value;
		WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_LOCKOUT_CFG_REG, RegVal.cmd);
	}
	return TRUE;
}

/*******************************************************************************
 Function Name:	SetCardParamEventPdt
 Description  : ���ð忨������ֵ����ʱ��
 Input        :	unsigned short CardNo  --- �忨��
                WORD value             --- ��ֵ����ʱ��
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetCardParamEventPdt(unsigned short CardNo, DWORD value)
{
	int i;
	UINT regvalue;
	CH_PDT_CFG_PROP RegVal;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return FALSE;
	}	

	for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
	{
		RegVal.spec.pdt = value;
		WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_PDT_REG, RegVal.cmd);
		
// 				RegVal.cmd = 0;
// 				ReadRegister(CardNo, ChRegBaseAddrs[j] + PROP_CH_PDT_REG, (unsigned int *)&RegVal.cmd);
	}
	return TRUE;
}

/*******************************************************************************
 Function Name:	SetCardEnableWaveformParam
 Description  : ���ð忨�������ܼ����ι��ܿ���
 Input        :	unsigned short CardNo  --- �忨��
                WORD EnableWavefrom    --- ���ο��ر��
                WORD EnableParam       --- �������ر��
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetCardEnableWaveformParam(unsigned short CardNo, WORD EnableWavefrom, WORD EnableParam)
{
	int i;
	UINT regvalue,value;	
    CH_FUNC_PROP RegVal;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return FALSE;
	}

	for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
	{
		ReadRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
		
		if (EnableWavefrom & (1 << i))
		{
			RegVal.spec.ThresholdWaveEn = 1;
		}
		else
		{
			RegVal.spec.ThresholdWaveEn = 0;
		}
		
		if (EnableParam & (1 << i))
		{
			if (bHardParam)
			{
				RegVal.spec.ThresholdHitEn = 1;
				ppOpenedDevTab[CardNo]->bParamEn = FALSE;
			}
			else
			{
				RegVal.spec.ThresholdHitEn = 0;
				ppOpenedDevTab[CardNo]->bParamEn = TRUE;
			}
		}
		else
		{
			RegVal.spec.ThresholdHitEn = 0;
			ppOpenedDevTab[CardNo]->bParamEn = FALSE;
		}
		
		RegVal.spec.AdEn = 1;
		
		WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, RegVal.cmd);
	}
	return TRUE;
}

/*******************************************************************************
 Function Name:	SetCardSelectLight
 Description  : 
 Input        :	unsigned short CardNo --- �忨��
				WORD bSelect          --- ���ر��
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetCardSelectLight(unsigned short CardNo, WORD bSelect)
{
	return FALSE;
}

/*******************************************************************************
 Function Name:	SetFilterGain
 Description  : ����ͨ���˲���������
 Input        :	unsigned short chanNo --- ͨ����
				unsigned short filter --- �˲�������
				unsigned short gain   --- ��������
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetFilterGain(unsigned short chanNo, unsigned short filter, unsigned short gain)
{
	return FALSE;
}

/*******************************************************************************
 Function Name:	SetCardFilterGain
 Description  : ���ð忨�˲���������
 Input        :	unsigned short CardNo     --- �忨��
				unsigned short ch0_filter --- ͨ��0�˲�������
				unsigned short ch0_gain   --- ͨ��0��������
				unsigned short ch1_filter --- ͨ��1�˲�������
				unsigned short ch1_gain   --- ͨ��1��������
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetCardFilterGain(unsigned short CardNo, 
									   unsigned short ch0_filter, 
									   unsigned short ch0_gain,
									   unsigned short ch1_filter, 
									   unsigned short ch1_gain)
{
	int i;
	short cardNo = CardNo;
	GLB_ANALOG_PROP RegVal;

    unsigned short filter;
	unsigned short gain;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return FALSE;
	}

	CH_ANALOG_CFG_PROP* pChannel;
	
	ReadRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_ANALOG_H_REG, (unsigned int*)&RegVal.cmd.CmdH);
	ReadRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_ANALOG_L_REG, (unsigned int*)&RegVal.cmd.CmdL);

	for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
	{
		if (i == 0)
		{
			pChannel = &RegVal.spec.Ch0;
			filter = ch0_filter;
			gain = ch0_gain;
		}
		else if (i == 1)
		{
			pChannel = &RegVal.spec.Ch1;
			filter = ch1_filter;
			gain = ch1_gain;
		}
		else
		{
			return FALSE;
		}

		switch (filter)
		{
		case 0:
			pChannel->ChHighPass = enHp20;
			pChannel->ChLowPass = enLp100;
			break;
		case 1:
			pChannel->ChHighPass = enHp20;
			pChannel->ChLowPass = enLp400;
			break;
		case 2:
			pChannel->ChHighPass = enHp20;
			pChannel->ChLowPass = enLp1200;
			break;
		case 3:
			pChannel->ChHighPass = enHp20;
			pChannel->ChLowPass = enLpBypass;
			break;
		case 4:
			pChannel->ChHighPass = enHp100;
			pChannel->ChLowPass = enLp400;
			break;
		case 5:
			pChannel->ChHighPass = enHp100;
			pChannel->ChLowPass = enLp1200;
			break;
		case 6:
			pChannel->ChHighPass = enHp100;
			pChannel->ChLowPass = enLpBypass;
			break;
		case 7:
			pChannel->ChHighPass = enHp400;
			pChannel->ChLowPass = enLp1200;
			break;
		case 8:
			pChannel->ChHighPass = enHp400;
			pChannel->ChLowPass = enLpBypass;
			break;
		default:
			pChannel->ChHighPass = enHpBypass;
			pChannel->ChLowPass = enLpBypass;
			break;
		}

		switch (gain)
		{
		case 0:
			pChannel->ChGain = enGain0;
			break;
		case 1:
			pChannel->ChGain = enGainNeg12;
			break;
		case 2:
			pChannel->ChGain = enGainNeg9;
			break;
		case 3:
			pChannel->ChGain = enGainNeg6;
			break;
		case 4:
			pChannel->ChGain = enGain6;
			break;
		case 5:
			pChannel->ChGain = enGain9;
			break;
		case 6:
			pChannel->ChGain = enGain12;
			break;
		case 7:
			pChannel->ChGain = enGainGnd;
			break;
		default:
			break;
		}
	}
    
    WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_ANALOG_H_REG, RegVal.cmd.CmdH);
    WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_ANALOG_L_REG, RegVal.cmd.CmdL);

    GLB_START_CMD CfgCmd;
    CfgCmd.cmd = 0;
    CfgCmd.spec.StartAnalog = 1;
    
    WriteRegister(cardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_START_REG, CfgCmd.cmd);

	return TRUE;
}

/*******************************************************************************
 Function Name:	SetExnTrig
 Description  : 
 Input        :	unsigned short CardNo     --- �忨��
				BOOL bStatus              --- 
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetExnTrig(unsigned short CardNo, BOOL bStatus)
{
	return FALSE;
}

/*******************************************************************************
 Function Name:	GetCardDriverVersion
 Description  : ��������汾��
 Input        :	unsigned short cardNo			     --- �忨��
				PEZUSB_DRIVER_VERSION pDriverVersion --- �汾�Žṹ���ַָ��
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::GetCardDriverVersion(unsigned short cardNo, PEZUSB_DRIVER_VERSION pDriverVersion)
{
	return FALSE;
}

/*******************************************************************************
 Function Name:	StartSample
 Description  : �����ɼ�����
 Input        :	
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::StartSample()
{
    UINT     regvalue;
    DWORD    pThreadId;
    int      i;

    UCHAR bufOutput;

	//memset(ovRead,0,sizeof(ovRead));

    //sysCurTime = 0;

    CH_AD_PROP RegVal;
    RegVal.cmd = 0;
    RegVal.spec.DcOffsetEn = 1;
    RegVal.spec.run = 1;
    int j;

	//��ִ���豸ͬ��
	//if (bGpsSyncEnabled && (!DevSynchronize()))
	if (!DevSynchronize())
	{
		return FALSE;
	}

	//char tempStr[12];
	//int k = 0;
	for(i = 0; i < openCardNum; i++)
	{
		if(NULL != ppOpenedDevTab[OpenedDevIndexTab[i]])
		{
			//reset fifo
// 			bufOutput = 3 ;
// 			USBWriteEP(i, 0, 1, &bufOutput);

// 			sprintf(tempStr, "CardEvent%u", i);
// 			hEventArray[k] = CreateEvent(NULL, TRUE, FALSE, tempStr);
// 			ovRead[i].hEvent = hEventArray[k];
// 			EventIndexTOCardIndex[k] = i;
			//k++;

            for (j = 0; j < CHANNEL_NUMBER_PERCARD; j++)
            {
                //���� cfg_ad_ch0   (�������� ֱ��ƫ��)
                WriteRegister(OpenedDevIndexTab[i], ChRegBaseAddrs[j] + PROP_CH_AD_REG, RegVal.cmd);
            }
			/************************************************************************/

#ifdef REGISTER_DEBUG
// 			char* pFileName = "regfile.txt";
// 			UINT u32Tmp;
// 			
// 			FILE* fp = fopen(pFileName, "ab+");
// 			
// 			fseek(fp, 0, SEEK_END);   char str[200];
// 			sprintf(str, "Card %d\r\n", i);
// 			fwrite(str, strlen(str), 1, fp);
// 			sprintf(str, "Register Address \t Register Value\r\n");
// 			fwrite(str, strlen(str), 1, fp);
// 			
// 			for (int j = 0; j < 0x30; j++)
// 			{
// 				ReadRegister(i, j, &u32Tmp);
// 				sprintf(str, "0x%x \t\t\t 0x%x\r\n", j, u32Tmp);
// 				fwrite(str, strlen(str), 1, fp);
// 			}
// 			fclose(fp);
// 			//    WriteRegister(i, AE_COMMAND, 0xc300003);
#endif
			/************************************************************************/
		}
	}
// 	for (i = 0; i < openCardNum; i++)
// 	{
// 		sprintf(tempStr, "CardEvent%u", EventIndexTOCardIndex[i]);
// 		hEventArray[i + k] = OpenEvent(EVENT_ALL_ACCESS, NULL, tempStr);
// 	}
// 	for (i = openCardNum * 2; i < MAX_CARDNUM * 2; i++)
// 	{
// 		hEventArray[i] = NULL;
// 	}

    /**********************����ת��������buffer��ʼ��************************/
    if (openCardNum > 0)
    {
        U32 buf_sz;
//         if (compact_mode)
//         {
//             buf_sz = 10000;
//         }
//         else

//         {
//             buf_sz = 200000;
//         }
// 
//         paraBuf = new PARAM[buf_sz];
//         memset(paraBuf, 0, buf_sz * sizeof(PARAM));
    }
    //WaveToHitStart(WthMdl, exParamBuf);
    /************************************************************************/

   SysState = enuSampling;

   preSysTime = 0;
   curSysTime = 0;

   //start AD
//    bufOutput = 0x05;
//    USBWriteEP(0, 0, 1, &bufOutput);
//    bufOutput = 0x04;
//    USBWriteEP(0, 0, 1, &bufOutput);

//#ifdef _DEBUG
#ifdef REGISTER_DEBUG
   /************************************************************************/
   char* pFileName = "regfile.txt";
   UINT u32Tmp;
   
   FILE* fp = fopen(pFileName, "ab+");
   
   fseek(fp, 0, SEEK_END);   char str[200];
   sprintf(str, "Register Address \t Register Value\r\n");
   fwrite(str, strlen(str), 1, fp);
   
   for (i = 0; i < 0xff; i++)
   {
       ReadRegister(0, i, &u32Tmp);
       sprintf(str, "0x%x \t\t\t 0x%x\r\n", i, u32Tmp);
       fwrite(str, strlen(str), 1, fp);
   }
   fclose(fp);
   /************************************************************************/

//    UINT aeCmd, eventLockout, paramThresSamp0, paramThresSamp1, lenFreq, outerTrig, outStat;
//    UINT sysTime, exParamFixed, mode, version, streaming;
//    ReadRegister(0, AE_COMMAND, &aeCmd);
//    ReadRegister(0, AE_PARM_EVENT_INTERVAL_LOCKOUT, &eventLockout);
//    ReadRegister(0, AE_THRESHOLD_PARAM_SAMPLE0, &paramThresSamp0);
//    ReadRegister(0, AE_THRESHOLD_PARAM_SAMPLE1, &paramThresSamp1);
//    ReadRegister(0,AE_SAMPLE_LENGTH_FREQ0, &lenFreq);
//    ReadRegister(0, AE_OUTER_TRIG, &outerTrig);
//    ReadRegister(0, AE_OUT_STATUS_FLAG, &outStat);
//    ReadRegister(0, AE_SYSTIMER_SETTING, &sysTime);
// #ifndef FPGA_VERSION_1_3
//    UINT exParamAttr;
//    ReadRegister(0, AE_EXPARAM_ATTRI, &exParamAttr);
// #endif
//    ReadRegister(0, AE_EXPARAM_FIXED, &exParamFixed);
//    ReadRegister(0, AE_SAMPLE_MODE, &mode);
//    ReadRegister(0, AE_VERSION_CONFIGRATION, &version);

#endif





//    ReadRegister(0, AE_STREAM_MODE_REG, &streaming);

//    char* pFileName = "datafile.dat";
//    
//    FILE* fp = fopen(pFileName, "ab+");
//    
//    fseek(fp, 0, SEEK_END);
//    
//    fwrite(&aeCmd, sizeof(UINT), 1, fp);
//    fwrite(&eventLockout, sizeof(UINT), 1, fp);
//    fwrite(&paramThresSamp0, sizeof(UINT), 1, fp);
//    fwrite(&paramThresSamp1, sizeof(UINT), 1, fp);
//    fwrite(&lenFreq, sizeof(UINT), 1, fp);
//    fwrite(&outerTrig, sizeof(UINT), 1, fp);
//    fwrite(&outStat, sizeof(UINT), 1, fp);
//    fwrite(&sysTime, sizeof(UINT), 1, fp);
//    fwrite(&exParamAttr, sizeof(UINT), 1, fp);
//    fwrite(&exParamFixed, sizeof(UINT), 1, fp);
//    fwrite(&mode, sizeof(UINT), 1, fp);
//    fwrite(&version, sizeof(UINT), 1, fp);
//    fwrite(&streaming, sizeof(UINT), 1, fp);
//   
// 	fclose(fp);

//#endif

//    for (i = 0; i < MAX_CARDNUM * CHANNEL_NUMBER_PERCARD; i++)
//    {
//        if (bStartStreamingInternalTrig[i])
//        {
//            StartChStreamingInternalTrig(i);
//        }
//    }

#ifdef DEBUG_VIEW_OUTPUT
   tmCurrent = GetTickCount();
   tmStart = tmCurrent;
#endif
	return TRUE;
}

/*******************************************************************************
 Function Name:	StopSample
 Description  : ֹͣ�ɼ�����
 Input        :	
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
void SocketHardware::StopSample()
{
 	int i, j;

/*	for(i = 0; i < MAX_CARDNUM; i++)
		if(hDeviceArray[i] == NULL){
			SetEvent(hEventArray[i]);
	//		break;
		}
		*/



	SysState = enuSampleIdle;
// 	while (ThreadStatus != 2)
// 		Sleep(1);
	
	CH_AD_PROP RegVal;
	RegVal.cmd = 0;

	for(i = 0; i < openCardNum; i++)
	{
		for (j = 0; j < CHANNEL_NUMBER_PERCARD; j++)
		{
			WriteRegister(OpenedDevIndexTab[i], (UCHAR)(ChRegBaseAddrs[j] + PROP_CH_AD_REG), RegVal.cmd);
		}
	}

// 	for(i = 0; i < MAX_CARDNUM; i++){	
// 		if( bDeviceOpenFlag[i]){
// 			CloseHandle(hEventArray[i]);
// 			hEventArray[i]	=	NULL;
// 		}
// 	} 

    /*****************************����ת����ֹͣ*****************************/
    //WaveToHitStop(WthMdl);
    /************************************************************************/
}

/*******************************************************************************
 Function Name:	CloseCard
 Description  : �ر������Ѵ򿪰忨
 Input        :	
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
void SocketHardware::CloseCard()
{

}

/*******************************************************************************
 Function Name:	GetRawDataFromBuf
 Description  : ���ʵʱ��������
 Input        :	char *rBuf --- ʵʱ����buffer��ַ
 Output       :
 Return       : ʵʱ����֡��
 Note         :                            			   
*******************************************************************************/
DWORD SocketHardware::GetRawDataFromBuf(char *rBuf)
{
#ifdef DEBUG_VIEW_OUTPUT
	/************************************************************************/
	char debug_str[250];
	/************************************************************************/
#endif

	DWORD retnlength =0;

	if(WAIT_OBJECT_0 != WaitForSingleObject(WaveMutex, SYNC_TIMEOUT_MS))
	{
		return 0;
	}

	UINT FrmVer = ppOpenedDevTab[OpenedDevIndexTab[0]]->FrmVer;
	UINT FrmEncodeType = ppOpenedDevTab[OpenedDevIndexTab[0]]->FrmEncodeType;

	if(curRawBufLength)
    {
        if (FrmVer == 0)
        {
            switch (FrmEncodeType)
            {
//             case enDpcm:
//                 DpcmWaveConvert(rBuf, rawBuf, curRawBufLength);
//                 break;
			case en18BitsPcm:
            case en16BitsPcm:
                Pcm16bitWaveConvert(rBuf, rawBuf, curRawBufLength);
                break;
            }
        }
		
        /****************************����ת����**********************************/
        if (!bHardParam)
        {
            int j, k;
			
            for (j = 0; j < curRawBufLength; j++)
            {
                U32 *tmpbuf = (U32 *)&rBuf[j * singleChannelBufLen];
                FRAME_FLAG *pFrmFlag = (FRAME_FLAG *)tmpbuf;
                WORD chno = pFrmFlag->spec.card * CHANNEL_NUMBER_PERCARD + pFrmFlag->spec.ChOfCard;
                
                if ((chno < 0) || (chno >= MAX_CARDNUM * CHANNEL_NUMBER_PERCARD))
                {
                    continue;
                }
                U64 tm = (((U64)tmpbuf[1]) << 16) | (tmpbuf[0] >> 16);
				
                if (ppOpenedDevTab[pFrmFlag->spec.card]->bParamEn)
                {
                    WaitForSingleObject(hWaveToHitSemaph, INFINITE);
                    I32 prm_num = WaveToHitProc(WthMdl, chno, tm * 100, (I32*)&tmpbuf[2], False);
                    if (prm_num > 0)
                    {
                        prm_num = WaveToHitGetParam(WthMdl, prm_num, (I8*)paraBuf);
                        for (k = 0; k < prm_num; k++)
                        {
                            ppOpenedDevTab[pFrmFlag->spec.card]->ParamFIFO.pushsingle(&paraBuf[k]);
                        }
                    }
                    ReleaseSemaphore(hWaveToHitSemaph, 1, NULL);
                }
            }
        }
        /************************************************************************/
		
#ifdef STREAMING_DEBUG
        int i;
        WORD chno;
        unsigned __int64 tm, tend;
        FRAME_FLAG *pFrmFlag = NULL;
        PDWORD buf;
        FILE *fp;
		
        fp = fopen("streaming_time.txt", "ab+");
		
        for (i = 0; i < curRawBufLength; i++)
        {
            buf = (PDWORD)&rBuf[i * singleChannelRawDataLen];
            pFrmFlag = (FRAME_FLAG *)buf;
            chno = pFrmFlag->spec.card * CHANNEL_NUMBER_PERCARD + pFrmFlag->spec.ChOfCard;
            tm = ((((unsigned __int64)buf[1]) << 16) | (buf[0] >> 16)) * 100;
            tend = tm + SampleCycle * SampleLength;
            fprintf(fp, "CH%u %04x%08x-%04x%08x\r\n", chno, tm >> 32, tm & 0xFFFFFFFF, tend >> 32, tend & 0xFFFFFFFF);
        }
        fclose(fp);
#endif
		retnlength = curRawBufLength;
		curRawBufLength = 0;
	}

	ReleaseMutex(WaveMutex);
	return retnlength;
}

/*******************************************************************************
 Function Name:	GetFftDataFromBuf
 Description  : ���FFT��������
 Input        :	char *rBuf --- FFT����buffer��ַ
 Output       :
 Return       : FFT����֡��
 Note         :                            			   
*******************************************************************************/
DWORD SocketHardware::GetFftDataFromBuf(char *rBuf)
{
    DWORD retnlength =0;
    if(WAIT_OBJECT_0 != WaitForSingleObject(FftMutex, SYNC_TIMEOUT_MS))
	{
        return 0;
	}
	
	int *pDesData;
    short *pSrcData;
	
	DWORD DesFFTDataLen = MAX_FFTDATA_LENGTH * 4 + 8;
	DWORD SrcFFTDataLen = MAX_FFTDATA_LENGTH * 2 + 8;
    if(curFftBufLength)
	{
		//        memcpy(rBuf, fftBuf, curFftBufLength * singleFftBufLen);
		for (int i = 0; i < curFftBufLength; i++)
		{
			memcpy(&rBuf[i * DesFFTDataLen], &fftBuf[i * SrcFFTDataLen], 8);
			
			pDesData = (int*)&rBuf[i * DesFFTDataLen + 8];
			pSrcData = (short*)&fftBuf[i * SrcFFTDataLen + 8];
			for (int k = 0; k < MAX_FFTDATA_LENGTH; k++)
			{
				pDesData[k] = (int)pSrcData[k];
			}
		}
        retnlength = curFftBufLength;
        curFftBufLength = 0;
    }
    ReleaseMutex(FftMutex);
    return retnlength;
}

/*******************************************************************************
 Function Name:	GetParamFromBuf
 Description  : ���ײ����������
	 �����飺
	 1.��ͨ���Ĳ����Ѵ洢����Ӧ��ParamFIFO�У���ͨ��FIFO�еĲ���������ã�������ʱ�䣩
	 2.ͨ�����ȡ�鲢���򣬼��Ƚϸ�ͨ������pop���Ĳ����ĵ���ʱ�䣬��С��pop��
	 3.pop��ʱ�䲻�����������߳̽���ʱ������100��������ݣ��߳�ֹͣʱ��ȫ��pop�������pop
	 4.Ϊ��߲���ͨ���ʣ���һ���ӳٻ��ƣ���ǰ����С��10Wʱ�������в�������ʹ��ݣ�
	 ����ʱ����Ʊ�֤������������������������ʱ��ÿ200������������ʹ���һ�β�����
 Input        :	PARAM *pBuf --- ײ������buffer��ַ
 Output       :
 Return       : ײ������֡��
 Note         :                            			   
*******************************************************************************/
DWORD SocketHardware::GetParamFromBuf(PARAM *pBuf)
{
	DWORD retnlength =0;
	if(WAIT_OBJECT_0 != WaitForSingleObject(ParamMutex, SYNC_TIMEOUT_MS))
	{
		return 0;
	}

    DWORD curParaBufLength = 0;
	int i;

	//ͳ�Ʋ�������
	for (i = 0; i < openCardNum; i++)
	{
		curParaBufLength += ppOpenedDevTab[OpenedDevIndexTab[i]]->ParamFIFO.GetDataLength();
	}
	curParaBufLength += SysTimeFIFO.GetDataLength();
	curParaBufLength += ExParamFIFO.GetDataLength();

	//ͳ������ʱ��
	for (i = 0; i < openCardNum; i++)
	{
		if (ppOpenedDevTab[OpenedDevIndexTab[i]]->ParamFIFO.GetSysTime() > curSysTime)
		{
            curSysTime = ppOpenedDevTab[OpenedDevIndexTab[i]]->ParamFIFO.GetSysTime();
		}
	}
	if (SysTimeFIFO.GetSysTime() > curSysTime)
	{
		curSysTime = SysTimeFIFO.GetSysTime();
	}
	if (ExParamFIFO.GetSysTime() > curSysTime)
	{
		curSysTime = ExParamFIFO.GetSysTime();
	}

	if(curParaBufLength > 100000 || (curSysTime > 2000000 + preSysTime ))
	{
		preSysTime = curSysTime;
		
		ULONGLONG tempTime = 0;
		if (enuSampling == SysState)
		{
			while ((tempTime + PARAM_OUTPUT_DELAY) < curSysTime)
			{
				tempTime = PARAM_TIME_MASK;
				int temp = -1;
				for (i = 0; i < openCardNum; i++)
				{
					if (ppOpenedDevTab[OpenedDevIndexTab[i]]->ParamFIFO.ArriveTime < tempTime)
					{
						temp = i;
						tempTime = ppOpenedDevTab[OpenedDevIndexTab[i]]->ParamFIFO.ArriveTime;
					}
				}
				if (SysTimeFIFO.ArriveTime < tempTime)
				{
					temp = openCardNum;
					tempTime = SysTimeFIFO.ArriveTime;
				}
				if (ExParamFIFO.ArriveTime < tempTime)
				{
					temp = openCardNum + 1;
					tempTime = ExParamFIFO.ArriveTime;
				}

				if (temp != -1)
				{
					if (temp < openCardNum)
					{
						ppOpenedDevTab[OpenedDevIndexTab[temp]]->ParamFIFO.popsingle(pBuf + retnlength);
						retnlength++;
					}
					else if (temp == openCardNum)
					{
						SysTimeFIFO.popsingle(pBuf + retnlength);
						retnlength++;
					}
					else
					{
						ExParamFIFO.popsingle(pBuf + retnlength);
						retnlength++;
					}
				}			
			}
		}
		else
		{
			while (tempTime < curSysTime)
			{
				tempTime = PARAM_TIME_MASK;
				int temp = -1;
				for (i = 0; i < openCardNum; i++)
				{
					if (ppOpenedDevTab[OpenedDevIndexTab[i]]->ParamFIFO.ArriveTime < tempTime)
					{
						temp = i;
						tempTime = ppOpenedDevTab[OpenedDevIndexTab[i]]->ParamFIFO.ArriveTime;
					}
				}
				if (SysTimeFIFO.ArriveTime < tempTime)
				{
					temp = openCardNum;
					tempTime = SysTimeFIFO.ArriveTime;
				}
				if (ExParamFIFO.ArriveTime < tempTime)
				{
					temp = openCardNum + 1;
					tempTime = ExParamFIFO.ArriveTime;
				}

				if (temp != -1)
				{
					if (temp < openCardNum)
					{
						ppOpenedDevTab[OpenedDevIndexTab[temp]]->ParamFIFO.popsingle(pBuf + retnlength);
						retnlength++;
					}
					else if (temp == openCardNum)
					{
						SysTimeFIFO.popsingle(pBuf + retnlength);
						retnlength++;
					}
					else
					{
						ExParamFIFO.popsingle(pBuf + retnlength);
						retnlength++;
					}
				}			
			}
		}
	}
	//curParaBufLength = 0;
	ReleaseMutex(ParamMutex);
	return retnlength;
}

/*******************************************************************************
 Function Name:	OnPluseTrig
 Description  : ָ��ͨ������ĳ�����͵�AST����
 Input        :	int chanNo   --- ����AST����ͨ����
                int TrigPara --- AST���崥������
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::OnPluseTrig(int chanNo, int TrigPara)
{
	short	cardNo;
	UINT	Trigvalue;
	UINT    regValue;
	
	cardNo = chanNo / CHANNEL_NUMBER_PERCARD;
	chanNo = chanNo % CHANNEL_NUMBER_PERCARD;

	if(cardNo >= devs.MaxDevNum || ppOpenedDevTab[cardNo] == NULL || ppOpenedDevTab[cardNo]->enalbed == FALSE)
	{
		return FALSE;
	}

    //AST����
    GLB_AST_PROP RegVal;
    RegVal.cmd = 0;
    RegVal.spec.ch = (0x1 << chanNo);
    RegVal.spec.PulseNo = TrigPara & 0xFF;
    RegVal.spec.PulseWid = (TrigPara >> 8) & 0xFF;
    RegVal.spec.PulseInt = (TrigPara >> 16) & 0xFF;
    WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_AST_REG, RegVal.cmd);
	
    //����AST
    GLB_START_CMD RegCmd;
    RegCmd.cmd = 0;
    RegCmd.spec.StartAst = 1;
    WriteRegister(cardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_START_REG, RegCmd.cmd);
	
    //�ȴ�AST����
    GLB_AST_STAT AstStat;
    AstStat.cmd = 0;
    AstStat.spec.completed = COMPLETED;
    do 
    {
        ReadRegister(cardNo, STAT_GLB_REG_BASEADDR + STAT_GLB_AST_REG, (unsigned int *)&AstStat.cmd);
    } while (COMPLETED != AstStat.spec.completed);
	
	return TRUE;
}

/*******************************************************************************
 Function Name:	OnPluseTrigStop
 Description  : ָֹͣ��ͨ������AST����
 Input        :	int chanNo   --- ����AST�����ͨ����
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::OnPluseTrigStop(int chanNo)
{
	return FALSE;
}

// DWORD WINAPI GetsingleChannelBufLen()
// {
// 	return (((hardware.singleChannelBufLen - 8) >> 2) + 2);
// }

// DWORD WINAPI GetsingleFftBufLen()
// {
//    return (((hardware.singleFftBufLen - 8) >> 1) + 2);
// //	return hardware.singleFftBufLen;
// }

/*******************************************************************************
 Function Name:	GetCardStatus
 Description  : ��õ�ǰ�豸״̬
 Input        :	BOOL *bDeviceFlag --- �豸����״̬�����ַָ��
                BOOL reset        --- ��λ��ǣ����ʾ��λ�豸���ٱ�ʾ����λ�豸
 Output       :
 Return       :
 Note         :                            			   
*******************************************************************************/
DWORD SocketHardware::GetCardStatus(BOOL *bDeviceFlag, BOOL reset)
{
	int i;
	int j;
	int OpenCardNum = 0;
	BOOL stat;
	
	if(bDeviceFlag)
	{
		memset(bDeviceFlag, 0, devs.MaxDevNum * sizeof(BOOL));
	}

	for (i = 0; i < devs.MaxDevNum; i++)
	{
		if (IS_DEV_EXIST(devs, i))
		{
			//��¼�豸ʹ��״̬
			stat = devs.pDev[i].enalbed;

			//ǿ������Ϊ��״̬
			SetCardEnable(devs.pDev[i].DevNo, TRUE);

			if (reset)
			{
				if (ResetCardFpga(devs.pDev[i].DevNo))	//RST_FPGA
				{
					bDeviceFlag[devs.pDev[i].DevNo] = TRUE;
					OpenCardNum++;
				}
				else
				{
					for (j = 0; j < clients.SockNum; j++)
					{
						if (clients.pSock[j].sk == devs.pDev[i].CmdSock)
						{
							clients.pSock[j].CommStatMach = enumCloseSocket;
							devs.pDev[i].CmdSock = INVALID_SOCKET;
							break;
						}
					}
					for (j = 0; j < clients.SockNum; j++)
					{
						if (clients.pSock[j].sk == devs.pDev[i].DataSock)
						{
							clients.pSock[j].CommStatMach = enumCloseSocket;
							devs.pDev[i].DataSock = INVALID_SOCKET;
							break;
						}
					}
					//�����豸��Ч
					SET_DEV_UNAVAILABLE(devs, i);
				}
			}

			//�ָ�Ϊ֮ǰ���õ�״̬
			SetCardEnable(devs.pDev[i].DevNo, stat);
		}

#if 0
		
		CARD_FEATURE_STAT ftrst;
		ftrst.cmd = 0;
		
		ReadRegister(zt.nChNo, STAT_FEATURE_REG, (unsigned int*)&ftrst.cmd);
		
//         CARD_FEATURE_PROP ftrprp;
//         ftrprp.cmd = 0;
//         ftrprp.spec.ParamFeature = 0;
//         WriteRegister(zt.nChNo, PROP_FEATURE_REG, ftrprp.cmd);
// 
//         ftrst.cmd = 0;
//         ReadRegister(zt.nChNo, STAT_FEATURE_REG, (unsigned int*)&ftrst.cmd);
		
		if (ftrst.sepc.ParamFeature)
		{
			bHardParam = True;
		}
		else
		{
			bHardParam = False;
		}
#endif
	}
	//memset(&bDeviceStaus, 0, MAX_DEV_NUM * sizeof(BOOL));
	
	//memset(card_ver, 0, sizeof(card_ver));
	
	
    if ((!bHardParam) && (!hWaveToHitSemaph))
    {
        hWaveToHitSemaph = CreateSemaphore(NULL, 1, 1, NULL);
    }
	
	return OpenCardNum;
}

/*******************************************************************************
 Function Name:	SetCardPause
 Description  : ���ð忨�ɼ���ͣ����
 Input        :	unsigned short CardNo --- �忨��
                BOOL bStatus          --- ��ͣ״̬��TRUE��ʾ��ͣ��FALSE��ʾȡ����ͣ
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetCardPause(unsigned short CardNo, BOOL bStatus)
{
	int i;
	CH_FUNC_PROP RegVal;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return FALSE;
	}

	for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
    {
        ReadRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);

        if(bStatus)
		{
            RegVal.spec.AdEn = 0;  //������ͣ����    
		}
        else
		{
            RegVal.spec.AdEn = 1;  //ȡ����ͣ����
		}
		
        WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, RegVal.cmd);
    }
	
	static DWORD ExparaEnOld = 0;
	GLB_EXPARAM_PROP ExRegVal;
	ReadRegister(CardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_EXPARAM_REG, (unsigned int*)&ExRegVal.cmd);
	if (bStatus)
	{		
		ExparaEnOld = ExRegVal.spec.ExparamEn;
		ExRegVal.spec.ExparamEn = 0;
	}
	else
	{
		ExRegVal.spec.ExparamEn = ExparaEnOld;
	}
	WriteRegister(CardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_EXPARAM_REG , ExRegVal.cmd);
	
	return TRUE;
}

// void WINAPI SetExParamGain(short gain)
// {
// 	 hardware.usbGain = gain;
// }

/*******************************************************************************
 Function Name:	SetSampleMode
 Description  : ���ð忨�ɼ�ģʽ
 Input        :	unsigned short chanNo --- ͨ����
                int mode              --- �ɼ�ģʽ
				int SampleSum         --- ǰ��ɵ���
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetSampleMode(unsigned short chanNo, int mode, int SampleSum)
{
    short	cardNo;
	UINT regValue;
	
	cardNo = chanNo / CHANNEL_NUMBER_PERCARD;
	chanNo = chanNo % CHANNEL_NUMBER_PERCARD;

	if(cardNo >= devs.MaxDevNum || ppOpenedDevTab[cardNo] == NULL || ppOpenedDevTab[cardNo]->enalbed == FALSE)
	{
		return FALSE;
	}

    CH_SAMP_MODE_PROP RegVal;
	
    ReadRegister(cardNo, ChRegBaseAddrs[chanNo] + PROP_CH_SAMP_MODE_REG, (unsigned int*)&RegVal.cmd);

    switch (mode)
    {
    case 1:
        RegVal.spec.PreCaptureEn = 1;
        RegVal.spec.PostCaptureEn = 0;
        RegVal.spec.TrigDelay = SampleSum;
        break;
    case 2:
        RegVal.spec.PreCaptureEn = 0;
        RegVal.spec.PostCaptureEn = 1;
        RegVal.spec.TrigDelay = SampleSum;
        break;
    default:
        RegVal.spec.PreCaptureEn = 0;
        RegVal.spec.PostCaptureEn = 0;
        break;
    }
	
    WriteRegister(cardNo, ChRegBaseAddrs[chanNo] + PROP_CH_SAMP_MODE_REG, RegVal.cmd);

	return TRUE;
}

/*******************************************************************************
 Function Name:	SetExparamAttri
 Description  : ���ð忨��βɼ�ģʽ
 Input        :	unsigned short cardNo --- �忨��
                DWORD dwExparamAttri  --- ��βɼ�ģʽ
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetExparamAttri(unsigned short cardNo, DWORD dwExparamAttri)
{
	if(cardNo >= devs.MaxDevNum || ppOpenedDevTab[cardNo] == NULL || ppOpenedDevTab[cardNo]->enalbed == FALSE)
	{
		return FALSE;
	}

	GLB_EXPARAM_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.ExparamADC = 80 *( dwExparamAttri & 0x0000000F);
	RegVal.spec.ExparamEn = dwExparamAttri >> (16 + 4 * cardNo);
	RegVal.spec.ExparamGain = dwExparamAttri >> 4;
	if (RegVal.spec.ExparamEn != 0)
	{
		exParamEn = TRUE;
	}
	else
	{
		exParamEn = FALSE;
	}
	switch(RegVal.spec.ExparamGain)
	{
	case 0:
		RegVal.spec.ExparamGain = 4;
		break;
	case 1 :
		RegVal.spec.ExparamGain = 2;
		break;
	case 2:
		RegVal.spec.ExparamGain = 8;
		break;
	case  3:
		RegVal.spec.ExparamGain = 1;
		break;
	default:
		break;
	}

	WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_EXPARAM_REG , RegVal.cmd);

	return TRUE;
}

/*******************************************************************************
 Function Name:	SetExparamFixed
 Description  : ������γ�ʱ���ԼĴ���
 Input        :	unsigned short chanNo --- ͨ����
                DWORD outInterval     --- ��γ�ʱʱ��
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetExparamFixed(unsigned short chanNo, DWORD outInterval)
{
    unsigned short	cardNo;
	
	cardNo = chanNo / CHANNEL_NUMBER_PERCARD;
	chanNo = chanNo % CHANNEL_NUMBER_PERCARD;

	if(cardNo >= devs.MaxDevNum || ppOpenedDevTab[cardNo] == NULL || ppOpenedDevTab[cardNo]->enalbed == FALSE)
	{
		return FALSE;
	}
	
    WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_EPFIXEDTIME_REG, (DWORD)(outInterval*80000));
	
	return TRUE;
}

/*******************************************************************************
 Function Name:	EnableSysTimer
 Description  : ���ð忨ʱ��֡����ʱ������Ӳ����ÿ���̶�ʱ�䣬����һ��ʱ��֡
 Input        :	unsigned short cardNo --- �忨��
                DWORD sysTimer        --- ʱ��֡�������(��λ��100ns)
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::EnableSysTimer(unsigned short cardNo, DWORD sysTimer)
{
	if(cardNo >= devs.MaxDevNum || ppOpenedDevTab[cardNo] == NULL || ppOpenedDevTab[cardNo]->enalbed == FALSE)
	{
		return FALSE;
	}
	
    sysTimer = 0;
	
    GLB_TIMESCALE_PROP RegVal;
	
    if (sysTimer > 0)
    {
        RegVal.spec.timeout = sysTimer;
        RegVal.spec.EnTimebaseFrm = 1;
    }
    else
    {
        RegVal.spec.EnTimebaseFrm = 0;
    }
	
    WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_TIMESCALE_REG, RegVal.cmd);
	
	return TRUE;
}

/*******************************************************************************
 Function Name:	GetVersionConf
 Description  : 
 Input        :	unsigned short cardNo --- �忨��
 Output       :
 Return       : 
 Note         :                            			   
*******************************************************************************/
UINT SocketHardware::GetVersionConf(unsigned short cardNo)
{
	return 0;
}

/*******************************************************************************
 Function Name:	GetFirFilterOrder
 Description  : ���FIR�����˲�������
 Input        :	
 Output       :
 Return       : FIR�����˲�������
 Note         :                            			   
*******************************************************************************/
DWORD SocketHardware::GetFirFilterOrder()
{
	return FirFilterOrder;
}

/*******************************************************************************
 Function Name:	SetFirFilter
 Description  : ����FIR�˲���������FIRϵ����������FIR���ԼĴ�����FIR�˲�������
                ϵ���Ĵ������������ã������øÿ�������ͨ��
 Input        :	short cardNo  --- �忨��
                double* pPara --- FIR�˲���ϵ������ָ��
				int order     --- FIR�˲�������
 Output       :
 Return       : ��ȷ���� 0�����󷵻� -1
 Note         :                            			   
*******************************************************************************/
int SocketHardware::SetFirFilter(short CardNo, double* pPara, int order)
{
	int i, j;
	CH_FIR_CFG_PROP RegVal;
	CH_FIR_COEF_PROP CoefVal;
	CH_FUNC_PROP FuncVal;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return -1;
	}

	if (order != FIR_ORDER)
	{
		return -1;
	}
	
	short *filter_coef = new short[FIR_ORDER / 2 + 1];

	if (filter_coef == NULL)
	{
		return -1;
	}

    for (i = 0; i < FIR_ORDER / 2 + 1; i++)
    {
        filter_coef[i] = (short)(pPara[i] * 32767);
    }
    
    /**********************�޸����ֵΪ32767*********************************/
//     double coeff_max = pPara[0];
//     for (i = 0; i < FIR_ORDER / 2 + 1; i++)
//     {
//         if (coeff_max < pPara[i])
//         {
//             coeff_max = pPara[i];
//         }
// 	}
//     for (i = 0; i < FIR_ORDER / 2 + 1; i++)
//     {
//         filter_coef[i] = (short)(pPara[i] * 32767 / coeff_max);
//     }
    /************************************************************************/

    /************************************************************************/
//     char* pFileName;
//     FILE *fp;
//     double sum = 0;
//     pFileName = "fir_coeff.txt";
//     
//     fp = fopen(pFileName, "ab+");
//     
//     fseek(fp, 0, SEEK_END);
//     
//     char info[40];
//     for (i = 0; i < FIR_ORDER / 2 + 1; i++)
//     {
//         fprintf(fp, "%f\r\n", pPara[i]);
// //         fprintf(fp, "%d\r\n", filter_coef[i]);
// 
//         sum += pPara[i] * 2;
//     }
//     sum -= pPara[i - 1];
//     for (; i < FIR_ORDER; i++)
//     {
//         fprintf(fp, "%f\r\n", pPara[FIR_ORDER  - i - 1]);
// //         fprintf(fp, "%d\r\n", filter_coef[FIR_ORDER  - i - 1]);
//     }
//     fprintf(fp, "sum = %f\r\n\r\n", sum);
//     
//     fclose(fp);
    /************************************************************************/

	//�������˲���ϵ��������˳��
#if (FIR_ORDER == 159)
	//159���˲���ϵ������˳��
	unsigned coef_seq_80 [FIR_ORDER / 2 + 1] = {79, 9, 19, 29, 39, 49, 59, 69, 78, 8, 18, 28, 38, 48, 58, 68, 77, 7, 17, 27, 37, 47,
		57, 67, 76, 6, 16, 26, 36, 46, 56, 66, 75, 5, 15, 25, 35, 45, 55, 65, 74, 4, 14, 24,
		34, 44, 54, 64, 73, 3, 13, 23, 33, 43, 53, 63, 72, 2, 12, 22, 32, 42, 52, 62, 71, 1,
        11, 21, 31, 41, 51, 61, 70, 0, 10, 20, 30, 40, 50, 60};
#elif (FIR_ORDER == 63)
	//63���˲���ϵ������˳��
// 	unsigned coef_seq_32 [FIR_ORDER / 2 + 1] = {31, 3, 7, 11, 15, 19, 23, 27, 30, 2, 6, 10, 14, 18, 22, 26, 29, 1, 5,
// 		9, 13, 17, 21, 25, 28, 0, 4, 8, 12, 16, 20, 24};
	unsigned coef_seq_32 [FIR_ORDER / 2 + 1] = {31, 7, 15, 23, 30, 6, 14, 22, 29, 5, 13, 21, 28, 4, 12, 20, 27, 3, 11,
		19, 26, 2, 10, 18, 25, 1, 9, 17, 24, 0, 8, 16};
#elif (FIR_ORDER == 59)
	//59���˲���ϵ������˳��
	unsigned coef_seq_32 [FIR_ORDER / 2 + 3] = {29, 1, 5, 9, 13, 17, 21, 25, 28, 0, 4, 8, 12, 16, 20,
		24, 27, 0, 3, 7, 11, 15, 19, 23, 26, 0, 2, 6, 10, 14, 18, 22};
#endif

	RegVal.cmd = 0;
	RegVal.spec.RstCmd = 0;		//��λ�˲���ģ��
	WriteRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FIR_CFG_REG, RegVal.cmd);
	
	RegVal.spec.FilterEn = 1;
	RegVal.spec.RstCmd = 1;
	Sleep(1);

	//��ϵ��д��ϵ����������
	for (j = 0; j < CHANNEL_NUMBER_PERCARD; j++)
	{
#if (FIR_ORDER == 159)
		unsigned *coef_seq = coef_seq_80;
		for (i = 0; i < FIR_ORDER / 2 + 1; i++)
#elif (FIR_ORDER == 63)
		unsigned *coef_seq = coef_seq_32;
		for (i = 0; i < FIR_ORDER / 2 + 1; i++)
#elif (FIR_ORDER == 59)
		unsigned *coef_seq = coef_seq_32;
		for (i = 0; i < FIR_ORDER / 2 + 3; i++)
#endif
		/*++
		����ΪFIR�˲���ϵ��д�����RegVal.spec.CoefWrCmd ��0-1֮�䣬д��һ��ϵ����FIR�˲�������ϵ���Ĵ���
		--*/
		{
			RegVal.spec.CoefWrCmd = 0;
			WriteRegister(CardNo, ChRegBaseAddrs[j] + PROP_CH_FIR_CFG_REG, RegVal.cmd);
			CoefVal.cmd = 0;
			CoefVal.spec.coef = filter_coef[coef_seq[i]];
			WriteRegister(CardNo, ChRegBaseAddrs[j] + PROP_CH_FIR_COEF_DATA_REG, CoefVal.cmd);     //д��һ��ϵ��
			RegVal.spec.CoefWrCmd = 1;
			WriteRegister(CardNo, ChRegBaseAddrs[j] + PROP_CH_FIR_CFG_REG , RegVal.cmd);
		}
		RegVal.spec.CoefCfgCmd = 1;                     //����FIR���ã�����ϵ���������е�����д���˲�����  
		WriteRegister(CardNo, ChRegBaseAddrs[j] + PROP_CH_FIR_CFG_REG, RegVal.cmd); 
		Sleep(1);

		ReadRegister(CardNo, ChRegBaseAddrs[j] + PROP_CH_FUNCTION_REG, (unsigned int*)&FuncVal.cmd);
		FuncVal.spec.FirEn = 1;
		WriteRegister(CardNo, ChRegBaseAddrs[j] + PROP_CH_FUNCTION_REG, FuncVal.cmd);
	}	
	delete []filter_coef;

	return 0;
}

/*******************************************************************************
 Function Name:	DisableFirFilter
 Description  : ��λFIR�˲�����������FIR���ԼĴ����ĸ�λλ
	            �������ã������øÿ�������ͨ��
 Input        :	short cardNo  --- �忨��
 Output       :
 Return       : ��ȷ���� 0�����󷵻� -1
 Note         :                            			   
*******************************************************************************/
int SocketHardware::DisableFirFilter(short CardNo)
{
	CH_FIR_CFG_PROP RegVal;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return -1;
	}

	RegVal.cmd = 0;
	RegVal.spec.RstCmd = 0;
	
	WriteRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FIR_CFG_REG, RegVal.cmd);
	WriteRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FIR_CFG_REG, RegVal.cmd);
	
	return 0;
}

/*******************************************************************************
 Function Name:	SetFFTWorkMode
 Description  : ����FFT����ģʽ��������FFT���ԼĴ���,����FFT��ʹ�ܵ�����£����ò�������2
	            �������ã������øÿ�������ͨ��
 Input        :	short cardNo  --- �忨��
                DWORD mode    --- ��ֵ����16λ�忨ʱ��ֵ�����ڴ�����λ����
				                  ����λ��0  - ͨ��0 FFTʹ��λ;     1  - ͨ��1 FFTʹ��λ;
				                  2  - ͨ��0 ��������λ;    3  - ͨ��1 ��������λ;
				                  4  - ͨ��0 ���ɴ���λ;    5  - ͨ��1 ���ɴ���λ;
				                  8  - ͨ��0 ������ʹ��λ;  9  - ͨ��1 ������ʹ��λ;//��18λ��δ�õ�
				                  10 - ͨ��0 �Ƿ���δ�;    11 - ͨ��1 ֪����δ�;

 Output       :
 Return       : ��ȷ���� 0�����󷵻� -1
 Note         :                            			   
*******************************************************************************/
int SocketHardware::SetFFTWorkMode(short CardNo, DWORD mode)
{
	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return -1;
	}

	CH_FUNC_PROP RegVal;
	CH_FFT_CFG_PROP ConfValue_CH0;
	CH_FFT_CFG_PROP ConfValue_CH1;

	ConfValue_CH0.cmd = 0;
	ConfValue_CH1.cmd = 0;
	ConfValue_CH0.spec.FtfEn = mode;
	fftEn = ConfValue_CH0.spec.FtfEn;
	if (ConfValue_CH0.spec.FtfEn)
	{
		//ParamType = enFixedLen;
		ReadRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
		RegVal.spec.FftEn = 1;
		WriteRegister(CardNo,ChRegBaseAddrs[0] + PROP_CH_FUNCTION_REG, RegVal.cmd);
		
		ReadRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
		RegVal.spec.FftEn = 1;
		WriteRegister(CardNo,ChRegBaseAddrs[1] + PROP_CH_FUNCTION_REG, RegVal.cmd);
		
		ConfValue_CH0.spec.HitTrigEn = mode>> 2;
		ConfValue_CH0.spec.FreeRun = mode>> 4;
		ConfValue_CH0.spec.RectWinEn = mode>> 10;
		
		ConfValue_CH1.spec.FtfEn = mode>>1;
		ConfValue_CH1.spec.HitTrigEn = mode>> 3;
		ConfValue_CH1.spec.FreeRun = mode>> 5;
		ConfValue_CH1.spec.RectWinEn = mode>> 11;
		
		WriteRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FFT_CFG_REG, ConfValue_CH0.cmd);
		WriteRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FFT_CFG_REG, ConfValue_CH1.cmd);
		
		
		CH_FUNC_PROP FuncVal;
		
		ReadRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FUNCTION_REG, (unsigned int*)&FuncVal.cmd);
		//������Ӳ����ǰ״̬��һ��
		if (((mode & AE_FFT_CFG_DATA_SAVE_EN0) && (FuncVal.spec.FftWaveEn == 0))
			|| ((mode & AE_FFT_CFG_DATA_SAVE_EN0 == 0) && (FuncVal.spec.FftWaveEn == 1)))
		{
			FuncVal.spec.FftWaveEn = ~FuncVal.spec.FftWaveEn;
			WriteRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FUNCTION_REG, FuncVal.cmd);
		}
		
		ReadRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FUNCTION_REG, (unsigned int*)&FuncVal.cmd);
		//������Ӳ����ǰ״̬��һ��
		if (((mode & AE_FFT_CFG_DATA_SAVE_EN1) && (FuncVal.spec.FftWaveEn == 0))
			|| ((mode & AE_FFT_CFG_DATA_SAVE_EN1 == 0) && (FuncVal.spec.FftWaveEn == 1)))
		{
			FuncVal.spec.FftWaveEn = ~FuncVal.spec.FftWaveEn;
			WriteRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FUNCTION_REG, FuncVal.cmd);
		}
	}
	else
	{
		//ParamType = enFixedVer2;
		ReadRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
		RegVal.spec.FftEn = 0;
		WriteRegister(CardNo,ChRegBaseAddrs[0] + PROP_CH_FUNCTION_REG, RegVal.cmd);
		ReadRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
		RegVal.spec.FftEn = 0;
		WriteRegister(CardNo,ChRegBaseAddrs[1] + PROP_CH_FUNCTION_REG, RegVal.cmd);
		
		WriteRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FFT_CFG_REG, ConfValue_CH0.cmd);
		WriteRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FFT_CFG_REG, ConfValue_CH1.cmd);
	}
	return 0;
}

/*******************************************************************************
 Function Name:	SetFFTWaveTrigPara
 Description  : ����FFT�������ޣ�������FFT�������޼Ĵ���
	            �������ã������øÿ�������ͨ��
 Input        :	DWORD CardNo           --- �忨��
                DWORD fftWaveThreshold --- FFT���δ�������ֵ
 Output       :
 Return       : ��ȷ���� 0�����󷵻� -1
 Note         :                            			   
*******************************************************************************/
int SocketHardware::SetFFTWaveTrigPara(DWORD CardNo, DWORD fftWaveThreshold)
{
	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return -1;
	}

	CH_FFT_THRESHOLD_CFG_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.threshold = fftWaveThreshold;
	WriteRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FFT_THRESHOLD_REG, RegVal.cmd);
	//WriteRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FFT_THRESHOLD_REG, RegVal.cmd);
	
	return 0;
}

/*******************************************************************************
 Function Name:	SetChFFTResultScale
 Description  : ����FFT����ϵ����������FFT�������ԼĴ���; ��ͨ�����ã�ͨ����Ϊ
                ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
 Input        :	unsigned short ChanNo --- ͨ����
                double scale          --- FFT����ϵ��
 Output       :
 Return       : ��ȷ���� 0�����󷵻� -1
 Note         :                            			   
*******************************************************************************/
int SocketHardware::SetChFFTResultScale(unsigned short ChanNo, double scale)
{
	unsigned short CardNo;
	unsigned char addr;
	unsigned int uScale = 0;
	
	CardNo = ChanNo / CHANNEL_NUMBER_PERCARD;
	ChanNo = ChanNo % CHANNEL_NUMBER_PERCARD;
	
	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return -1;
	}

	CH_FFT_SCALE_CFG_PROP RegVal;
	RegVal.cmd = 0;
	//Scale����ת��
	RegVal.spec.scale = scale * 32768;
	WriteRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FFT_SCALE_CFG_REG, RegVal.cmd);
	WriteRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FFT_SCALE_CFG_REG, RegVal.cmd);
	
	return 0;
}

/*******************************************************************************
 Function Name:	SetChFFTWindowFunction
 Description  : ����ͨ��FFT��������������FFT�����ԼĴ���; ��ͨ�����ã�ͨ����Ϊ
                ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
 Input        :	unsigned short ChanNo --- ͨ����
                BOOL bEnableWindow    --- ������ʹ���źţ�TUREΪʹ��
                double *pWinFunCoef   --- ������ϵ�������ָ��
				int len               --- ������ϵ������
 Output       :
 Return       : ��ȷ���� 0�����󷵻� -1
 Note         :                            			   
*******************************************************************************/
int SocketHardware::SetChFFTWindowFunction(unsigned short ChanNo, BOOL bEnableWindow, double *pWinFunCoef, int len)
{
	int i;
	
	unsigned short CardNo;
	unsigned char addr;
	
	CardNo = ChanNo / CHANNEL_NUMBER_PERCARD;
	ChanNo = ChanNo % CHANNEL_NUMBER_PERCARD;
	
	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return -1;
	}

	CH_FFT_WIN_CFG_PROP RegVal;
	if (bEnableWindow)
	{
		if (len > WIN_FUNC_COEF_SIZE)
		{
			return -1;
		}
		
		//������ϵ��ת��
		int *pTmpCoef = new int[len];
		int tmpCoef  = (1L << (GetOneCount(AE_HIT_CFG_WIN_COEF_DATA_MASK) - 1)) - 1;
		for (i = 0; i < len; i++)
		{
			pTmpCoef[i] = (int)(pWinFunCoef[i] * tmpCoef);
		}
		
		//��λ������
		RegVal.cmd = 0;
		WriteRegister(CardNo, ChRegBaseAddrs[ChanNo] + PROP_CH_FFT_WIN_CFG_REG, RegVal.cmd);
		
		//дϵ��
		for (i = 0; i < len; i++)
		{
			RegVal.spec.CoefAddr = i;
			RegVal.spec.coef= pTmpCoef[i];
			RegVal.spec.CoefWrCmd = 0;
			WriteRegister(CardNo, ChRegBaseAddrs[ChanNo] + PROP_CH_FFT_WIN_CFG_REG, RegVal.cmd);
			RegVal.spec.CoefWrCmd = 1;
			WriteRegister(CardNo, ChRegBaseAddrs[ChanNo] + PROP_CH_FFT_WIN_CFG_REG, RegVal.cmd);
		}
		
		//ʹ�ܴ�����
		//WriteRegister(CardNo, addr + AE_HIT_CFG_WINFUNC_REG, AE_HIT_CFG_WIN_EN);
		delete []pTmpCoef;
	}
	else
	{
		WriteRegister(CardNo, ChRegBaseAddrs[ChanNo] + PROP_CH_FFT_WIN_CFG_REG, 0);
	}
	
	return 0;
}

/*******************************************************************************
 Function Name:	SetChFFTSaveLen
 Description  : ����ͨ��FFT���������泤�ȣ�������FFT�������������ԼĴ���;
                ��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
 Input        :	unsigned short ChanNo --- ͨ����
				int len               --- FFT����������
 Output       :
 Return       : ��ȷ���� 0�����󷵻� -1
 Note         :                            			   
*******************************************************************************/
int SocketHardware::SetChFFTSaveLen(unsigned short ChanNo, int len)
{
	return -1;
}

/*******************************************************************************
 Function Name:	SetChFFTDecimateRate
 Description  : ����ͨ��FFT�źų�ȡ�ʣ�������FFT��Ƶϵ���Ĵ���;
                ��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
 Input        :	unsigned short ChanNo --- ͨ����
				int val               --- FFT�źų�ȡ�ʣ����Ϊ65535����СΪ1��ע����Ҫͬ�˲������õ����
 Output       :
 Return       : ��ȷ���� 0�����󷵻� -1
 Note         :                            			   
*******************************************************************************/
int SocketHardware::SetChFFTDecimateRate(unsigned short ChanNo, int val)
{
	unsigned short CardNo;
	unsigned char addr;
	
	CardNo = ChanNo / CHANNEL_NUMBER_PERCARD;
	ChanNo = ChanNo % CHANNEL_NUMBER_PERCARD;
	
	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return -1;
	}

	CH_FFT_DECIMATE_CFG_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.DecimateRate = val & AE_HIT_CFG_FFT_DECIMATE_RATE_MASK;
	WriteRegister(CardNo, ChRegBaseAddrs[ChanNo] + PROP_CH_FFT_DECIMATE_RATE_REG, RegVal.cmd);
	
	return 0;
}

/*******************************************************************************
 Function Name:	SetChFFTPartialPowerSegment
 Description  : ����ͨ��FFT�ֲ����������üĴ���;
                ��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
 Input        :	unsigned short ChanNo --- ͨ����
                unsigned int id       --- �����, 0 - (MAX_FFT_PARTIAL_POW_SEGMENTS - 1)
				int StartBin          --- ��ʼBIN���
				int EndBin            --- �յ�BIN���
 Output       :
 Return       : ��ȷ���� 0�����󷵻� -1
 Note         :                            			   
*******************************************************************************/
int SocketHardware::SetChFFTPartialPowerSegment(unsigned short ChanNo, unsigned int id, int StartBin, int EndBin)
{
	unsigned short CardNo;
	unsigned char index_addr;
	
	CardNo = ChanNo / CHANNEL_NUMBER_PERCARD;
	ChanNo = ChanNo % CHANNEL_NUMBER_PERCARD;
	
	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return -1;
	}
	
	if (id >= MAX_FFT_PARTIAL_POW_SEGMENTS)
	{
		return -1;
	}

	CH_FFT_PP_CFG_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.MaxBin = EndBin;
	RegVal.spec.MinBin = StartBin;
	
	index_addr = PROP_CH_FFT_PP0_REG;
	index_addr += id;
	
	WriteRegister(CardNo,ChRegBaseAddrs[ChanNo] + index_addr, RegVal.cmd);
    return 0;
}

/*******************************************************************************
 Function Name:	SetChStreamingMode
 Description  : ����ͨ�������ɼ�ģʽ���������������δ���ģʽ�Ĵ�����������ͨ���������ԼĴ���Ϊ�����ɼ�
                ��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
 Input        :	unsigned short chanNo --- ͨ����
                BOOL bEnabled         --- �����ɼ�ʹ��
				int TrigMode          --- ����ģʽ
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetChStreamingMode(unsigned short chanNo, BOOL bEnabled, int TrigMode)
{
    UINT regvalue;    
    unsigned short CardNo;

    CardNo = chanNo / CHANNEL_NUMBER_PERCARD;
    chanNo = chanNo % CHANNEL_NUMBER_PERCARD;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return FALSE;
	}
	
    CH_FUNC_PROP RegVal;
    
    if (bEnabled)
    {
        ReadRegister(CardNo, ChRegBaseAddrs[chanNo] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
        RegVal.spec.StreamWaveEn = 1;
		RegVal.spec.FftEn = 0;
		RegVal.spec.ThresholdWaveEn = 0;
		RegVal.spec.StateFrmEn = 1;
        WriteRegister(CardNo, ChRegBaseAddrs[chanNo] + PROP_CH_FUNCTION_REG, RegVal.cmd);
		
        CH_STREAM_CFG_PROP TrigVal;
        TrigVal.cmd = 0;
        switch (TrigMode)
        {
        case enStreamTrigSrcInternal: //�ڲ�����
            TrigVal.spec.InternalTrig = 1;
            break;
        case enStreamTrigSrcExternal: //�ⲿ����
            TrigVal.spec.ExternalTrig = 1;
            break;
        case enStreamTrigSrcThreshold: //���޴���
            TrigVal.spec.ThresholdTrig = 1;
            break;
        default:
            TrigVal.spec.InternalTrig = 1;
            break;
        }
		TrigVal.spec.GiveupEn = 1;
        WriteRegister(CardNo, ChRegBaseAddrs[chanNo] + PROP_CH_STREAM_CFG_REG, TrigVal.cmd);
		
        if (TrigMode == enStreamTrigSrcInternal)
        {
			ppOpenedDevTab[CardNo]->bStartStreamingInternalTrig = TRUE;
        }
		else
		{
			ppOpenedDevTab[CardNo]->bStartStreamingInternalTrig = FALSE;
		}
    }
    else
    {
        ReadRegister(CardNo, ChRegBaseAddrs[chanNo] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
        RegVal.spec.StreamWaveEn = 0;
        WriteRegister(CardNo, ChRegBaseAddrs[chanNo] + PROP_CH_FUNCTION_REG, RegVal.cmd);
    }
	
    return TRUE;
}

/*******************************************************************************
 Function Name:	StartChStreamingInternalTrig
 Description  : ����ͨ�������ɼ��ڲ���������д����ȫ���������βɼ����ƼĴ���
                ��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
 Input        :	unsigned short chanNo --- ͨ����
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::StartChStreamingInternalTrig(unsigned short chanNo)
{
    UINT regvalue;
    
    unsigned short CardNo;
    CardNo = chanNo / CHANNEL_NUMBER_PERCARD;
    chanNo = chanNo % CHANNEL_NUMBER_PERCARD;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return FALSE;
	}
    
    GLB_STREAM_CTRL_CMD StrmVal;
    StrmVal.cmd = 0;
    
    StrmVal.spec.InterTrig = 1;
    
    WriteRegister(CardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_STREAM_CTRL_REG, StrmVal.cmd);
	
    return TRUE;
}

/*******************************************************************************
 Function Name:	SetAdg1439
 Description  : 
 Input        :	DWORD CardNo        --- �忨��
                unsigned long dat_l --- 
				unsigned long dat_h --- 
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::SetAdg1439(DWORD CardNo, unsigned long dat_l, unsigned long dat_h)
{
    return FALSE;
}

/*******************************************************************************
 Function Name:	GetTransmitStatisticData
 Description  : ���ָ���忨�Ĵ���ͳ������
 Input        :	unsigned short CardNo   --- �忨��
                unsigned __int64 val[4] --- ͳ������buffer
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::GetTransmitStatisticData(unsigned short CardNo, unsigned __int64 val[4])
{
    return FALSE;
}

/*******************************************************************************
 Function Name:	ClearTransmitStatisticData
 Description  : ���ָ���忨�Ĵ���ͳ������
 Input        :	unsigned short CardNo   --- �忨��
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::ClearTransmitStatisticData(unsigned short CardNo)
{
    return FALSE;
}

/*******************************************************************************
 Function Name:	ReadRegister
 Description  : ���Ĵ�������
 Input        :	short CardId --- �忨��
                UCHAR addr   --- �Ĵ�����ַ
				UINT *value  --- �Ĵ���ֵ�����ַ
 Output       :
 Return       : 
 Note         :                            			   
*******************************************************************************/
void SocketHardware::ReadRegister(short CardId, UCHAR addr, UINT *value)
{
	CmdCommProc(CardId, enuDeviceEnabled, enuMcuCmdReadRegister, enuFpgaCmdReadRegister, addr, value);
}

/*******************************************************************************
 Function Name:	WriteRegister
 Description  : д�Ĵ�������
 Input        :	short CardId --- �忨��
                UCHAR addr   --- �Ĵ�����ַ
				UINT value   --- �Ĵ���ֵ
 Output       :
 Return       : 
 Note         :                            			   
*******************************************************************************/
void SocketHardware::WriteRegister(short CardId, UCHAR addr, UINT value)
{
	CmdCommProc(CardId, enuDeviceEnabled, enuMcuCmdWriteRegister, enuFpgaCmdWriteRegister, addr, &value);
}

//#ifdef _DEBUG
// void WINAPI ReadCardRegister(short CardId, UCHAR addr, UINT *value)
// {
//     hardware.ReadRegister(CardId, addr, value);
// }
// 
// void WINAPI WriteCardRegister(short CardId, UCHAR addr, UINT value)
// 
// {
//     hardware.WriteRegister(CardId, addr, value);
// }

/*******************************************************************************
 Function Name:	GetOutputInfo
 Description  : ��ÿ������Ϣ
 Input        :	UINT input[10] --- ������Ϣ
                PCHAR pStrBuf  --- �����Ϣ���ַ���buffer
				int bufSize    --- �����Ϣbuffer�ĳ��ȣ���λ���ֽ�
 Output       :
 Return       : 
 Note         :                            			   
*******************************************************************************/
void SocketHardware::GetOutputInfo(UINT input[10], PCHAR pStrBuf, int bufSize)
{
    memset(pStrBuf, 0, bufSize);
	
    //����
    UINT val = 0;
    
    ReadRegister(0, 0, &val);
	
    //�����Ϣ�ַ������ȱ���С��bufSize
    sprintf(pStrBuf, "%x \n", val);
}

/*******************************************************************************
 Function Name:	GetOutputInfo
 Description  : ��ÿ������Ϣ
 Input        :	UINT input[10] --- ������Ϣ
 Output       :
 Return       : �ַ�����Ϣͷָ�룬ʹ������Ҫ�ⲿ�ͷ��ַ���ռ�õ��ڴ�
 Note         :                            			   
*******************************************************************************/
char * SocketHardware::GetOutputInfo(UINT input[10])
{
	PCHAR pStrBuf;
    int bufSize;
	
    bufSize = 1024 * 4;
	
    pStrBuf = (char*)GlobalAlloc(GPTR, bufSize);
	
    memset(pStrBuf, 0, bufSize);
	
    //����
    UINT val = 0;
    
    ReadRegister(0, 0, &val);
	
    //�����Ϣ�ַ������ȱ���С��bufSize
    sprintf(pStrBuf, "%x \n", val);
	
    return pStrBuf;
}

/*******************************************************************************
 Function Name:	ConfigureBeforeStart
 Description  : ��StartSample����֮ǰ����
 Input        :	
 Output       :
 Return       : 
 Note         :                            			   
*******************************************************************************/
void SocketHardware::ConfigureBeforeStart()
{

}

/*******************************************************************************
 Function Name:	ConfigureAfterStart
 Description  : ��StartSample����֮�����
 Input        :	
 Output       :
 Return       : 
 Note         :                            			   
*******************************************************************************/
void SocketHardware::ConfigureAfterStart()
{

}

/*******************************************************************************
 Function Name:	GetMbFwVersion
 Description  : �������̼��汾��
 Input        :	short ChassisId --- �����
                UINT *val       --- ����buffer��ַ
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::GetMbFwVersion(short ChassisId, UINT *val)
{
	return FALSE;
}

/*******************************************************************************
 Function Name:	GetAECardFwVersion
 Description  : �������̼��汾��
 Input        :	short CardId --- �忨��
                UINT *val    --- ����buffer��ַ
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::GetAECardFwVersion(short CardId, UINT *val)
{
	if(CardId >= devs.MaxDevNum || ppOpenedDevTab[CardId] == NULL)
	{
		return FALSE;
	}
	
	if (bHardParam)
	{
		*val = ppOpenedDevTab[CardId]->FpgaVer | HARD_HIT_FLAG;
	}
	else
	{
		*val = ppOpenedDevTab[CardId]->FpgaVer;
	}

	return TRUE;
}

/*******************************************************************************
 Function Name:	SetEncoding
 Description  : ���ð忨ͨ�Ż������������汾�š�֡�汾�š�֡���뷽ʽ�Լ�DPCM����λ��
 Input        :	unsigned short CardNo --- �忨��
                DWORD PackingVer      --- ���汾��
				DWORD FramingVer      --- ֡�汾��
				DWORD encoding        --- ֡���뷽ʽ
				DWORD bits            --- DPCM����λ��
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
void SocketHardware::SetEncoding(unsigned short CardNo, DWORD PackingVer, DWORD FramingVer, DWORD encoding, DWORD bits)
{
	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL)
	{
		return;
	}

// 	ppOpenedDevTab[CardNo]->PackVer = PackingVer;
//     ppOpenedDevTab[CardNo]->FrmVer = FramingVer;
//     ppOpenedDevTab[CardNo]->FrmEncodeType = encoding;
//     ppOpenedDevTab[CardNo]->FrmDpcmBits = bits;
}

/*******************************************************************************
 Function Name:	GetCardStreamingState
 Description  : ���ͨ�������ɼ�״̬������ֵ��16λ��ʾCH0��ʧ����������16λ��ʾCH1��ʧ������
 Input        :	DWORD CardNo          --- �忨��
                unsigned long *states --- ���汾��
 Output       :
 Return       : �ɹ�����TRUE��ʧ�ܷ���FALSE
 Note         :                            			   
*******************************************************************************/
BOOL SocketHardware::GetCardStreamingState(DWORD CardNo, unsigned long *states)
{
	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL)
	{
		return FALSE;
	}

    *states = ( unsigned long)ppOpenedDevTab[CardNo]->ChStreamingState;
	return TRUE;
}

/*******************************************************************************
 Function Name:	OutputChAlarm
 Description  : �������
 Input        :	DWORD ChNo --- ͨ����
                DWORD mode --- ����ģʽ
 Output       :
 Return       : ��ȷ���� 0�����󷵻� -1
 Note         :                            			   
*******************************************************************************/
int SocketHardware::OutputChAlarm(DWORD ChNo, DWORD mode)
{
    unsigned short CardNo;
    unsigned char addr;
    
    CardNo = ChNo / CHANNEL_NUMBER_PERCARD;
    //ChNo = ChNo % CHANNEL_NUMBER_PERCARD;
    
	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return -1;
	}
	
    GLB_ALARM_CMD RegVal;
    RegVal.cmd = 0;
    RegVal.spec.CmdVld = 1;
    if (mode & enuAlarmBuzzer)
    {
        RegVal.spec.EnableBuzzer = 1;
    }
    if (mode & enuAlarmLight)
    {
        RegVal.spec.EnableLight = 1;
    }
    if (mode & enuAlarmRelay)
    {
        RegVal.spec.EnableRelay = 1;
    }
    
    WriteRegister(CardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_ALARM_REG, RegVal.cmd);
	
    return 0;
}

/*******************************************************************************
 Function Name:	SetCardAlarmTimeout
 Description  : ���ñ���ʧЧʱ��
 Input        :	DWORD CardNo --- �忨��
                DWORD ms     --- ����ʱ�䣬��λms
 Output       :
 Return       : ��ȷ���� 0�����󷵻� -1
 Note         :                            			   
*******************************************************************************/
int SocketHardware::SetCardAlarmTimeout(DWORD CardNo, DWORD ms)
{
	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return -1;
	}
    
    GLB_ALARM_TIMEOUT_PROP RegVal;
    RegVal.cmd = 0;
    RegVal.spec.timeout = ms;
    
    WriteRegister(CardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_ALARM_TIMEOUT_REG, RegVal.cmd);
    
    return 0;
}

/*******************************************************************************
 Function Name:	StopChAlarm
 Description  : ֹͣ�������
 Input        :	DWORD ChNo --- ͨ����
 Output       :
 Return       : ��ȷ���� 0�����󷵻� -1
 Note         :                            			   
*******************************************************************************/
int SocketHardware::StopChAlarm(DWORD ChNo)
{
	unsigned short CardNo;
    
    CardNo = ChNo / CHANNEL_NUMBER_PERCARD;

	if(CardNo >= devs.MaxDevNum || ppOpenedDevTab[CardNo] == NULL || ppOpenedDevTab[CardNo]->enalbed == FALSE)
	{
		return -1;
	}

	GLB_ALARM_CMD RegVal;
    RegVal.cmd = 0;
    RegVal.spec.CmdVld = 1;
    RegVal.spec.ResetAlarm = 1;
	
    WriteRegister(CardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_ALARM_REG, RegVal.cmd);
    
    return 0;
}

/*******************************************************************************
 Function Name:	GetSocketError
 Description  : �������ͨ�Ź����룬�������ڵ��øú������Զ����
 Input        :	
 Output       :
 Return       : 
 Note         :                            			   
*******************************************************************************/
int SocketHardware::GetSocketError()
{
	int err = SocketError;
	SocketError = enSocketOk;
	return err;
}

/*******************************************************************************
 Function Name:	SetEnableGPS
 Description  : ����GPS���ܿ���
 Input        :	BOOL bEnable --- GPSʹ�ܱ�ǣ�TRUE��ʾʹ��GPS��FALSE��ʾ����GPS
 Output       :
 Return       : 
 Note         :                            			   
*******************************************************************************/
void SocketHardware::SetEnableGPS(BOOL bEnable)
{
	bGpsSyncEnabled = bEnable;
}

/*******************************************************************************
 Function Name:	PrepareCardGpsStatus
 Description  : ׼��GPS�ź�״̬��ÿ��ִ�м������2��
 Input        :	unsigned short CardNo  --- �忨��
 Output       :
 Return       :
 Note         : �ɹ�����TRUE��ʧ�ܷ���FALSE                           			   
*******************************************************************************/
BOOL SocketHardware::PrepareCardGpsStatus(unsigned short CardNo)
{
	return CmdCommProc(CardNo, enuDeviceAvailable, enuMcuCmdGpsPrepare);
}

/*******************************************************************************
 Function Name:	GetCardGpsStatus
 Description  : ���GPS�ź�״̬
 Input        :	unsigned short CardNo  --- �忨��
 Output       :
 Return       :
 Note         : �ɹ�����TRUE��ʧ�ܷ���FALSE                           			   
*******************************************************************************/
BOOL SocketHardware::GetCardGpsStatus(unsigned short CardNo, UINT *val)
{
	return CmdCommProc(CardNo, enuDeviceAvailable, enuMcuCmdGpsRead, 0, 0, val);
}

/*******************************************************************************
 Function Name:	PrepareCardWifiStatus
 Description  : ׼��WIFI�ź�״̬��ÿ��ִ�м������200����
 Input        :	unsigned short CardNo  --- �忨��
 Output       :
 Return       :
 Note         : �ɹ�����TRUE��ʧ�ܷ���FALSE                           			   
*******************************************************************************/
BOOL SocketHardware::PrepareCardWifiStatus(unsigned short CardNo)
{
	return CmdCommProc(CardNo, enuDeviceAvailable, enuMcuCmdWifiPrepare);
}

/*******************************************************************************
 Function Name:	GetCardWifiStatus
 Description  : ���WIFI�ź�״̬
 Input        :	unsigned short CardNo  --- �忨��
 Output       :
 Return       :
 Note         : �ɹ�����TRUE��ʧ�ܷ���FALSE                           			   
*******************************************************************************/
BOOL SocketHardware::GetCardWifiStatus(unsigned short CardNo, UINT *val)
{
	return CmdCommProc(CardNo, enuDeviceAvailable, enuMcuCmdWifiRead, 0, 0, val);
}

/*******************************************************************************
 Function Name:	SetCardWifiPower
 Description  : ����WIFI����
 Input        :	unsigned short CardNo  --- �忨��
 Output       :
 Return       :
 Note         : �ɹ�����TRUE��ʧ�ܷ���FALSE                           			   
*******************************************************************************/
BOOL SocketHardware::SetCardWifiPower(unsigned short CardNo, UINT val)
{
	return CmdCommProc(CardNo, enuDeviceAvailable, enuMcuCmdWifiPowerSet, 0, 0, &val);
}

/*******************************************************************************
 Function Name:	GetWaveToHitEntry
 Description  : ��ò���ת����ģ�����
 Input        :	
 Output       :
 Return       : PWAVETOHIT_STRUCT --- ����ת����ģ����ڵ�ַ
 Note         :                            			   
*******************************************************************************/
PWAVETOHIT_STRUCT SocketHardware::GetWaveToHitEntry()
{
    return NULL;
}

/*********************************End of File**********************************/
