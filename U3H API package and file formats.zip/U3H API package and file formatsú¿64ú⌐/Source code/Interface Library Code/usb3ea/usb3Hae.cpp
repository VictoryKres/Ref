// pciae.cpp : Defines the initialization routines for the DLL.
//

//#include "usbAEhardware.h"
//#include "UsbaeHardware18Bit.h"
//#include "SocketHardware.h"
//#include "SocketHardwareNew.h"
#include "usb3hae.h"
#include "WAEDrive_USB30_16Bit.h"
#include "Usb7kCIoctl.h"

//#ifdef BGA_16BITS_10M_NEW_VERSION 
// 	class UsbaeHardware16BitNew hardware;
//#else
//	class usbAEhardware  hardware;
//#endif
class CWAEDrive_USB30_16Bit hardware;

USB3AE_API void OpenAllCard(BOOL *bDeviceFlag, DWORD SampleLength, BOOL reset/* = TRUE*/)
{
	hardware.OpenAllCard(bDeviceFlag,SampleLength,reset);
}

USB3AE_API BOOL SetCardParamThreshold(DWORD chanNo, DWORD value)
{
	return hardware.SetCardParamThreshold((short)chanNo,value);
}

USB3AE_API BOOL SetCardSampleThreshold(DWORD chanNo, DWORD value)
{
	return hardware.SetCardSampleThreshold((short)chanNo,value);
}

USB3AE_API BOOL SetCardSampleLength(DWORD CardNo, DWORD value)
{
	return hardware.SetCardSampleLength((short)CardNo,value);
}

USB3AE_API BOOL GetCardSampleFreq(DWORD CardNo, WORD *value)
{
	return hardware.GetCardSampleFreq((short)CardNo,value);
}

USB3AE_API BOOL SetCardSampleFreq(DWORD CardNo, WORD value)
{
	return hardware.SetCardSampleFreq((short)CardNo,value);
}

USB3AE_API BOOL SetCardParamEventInterval(DWORD CardNo, DWORD value)
{
	return hardware.SetCardParamEventInterval((short)CardNo,value);
}

USB3AE_API BOOL SetCardParamEventLockOut(DWORD CardNo, DWORD value)
{
	return hardware.SetCardParamEventLockOut((short)CardNo,value);
}

USB3AE_API BOOL SetCardParamEventPdt(DWORD CardNo, DWORD value)
{
	return hardware.SetCardParamEventPdt((short)CardNo,value);
}

USB3AE_API BOOL SetCardEnableWaveformParam(DWORD CardNo, WORD EnableWavefrom, WORD EnableParam)
{
	return hardware.SetCardEnableWaveformParam((short)CardNo,EnableWavefrom,EnableParam);
}

USB3AE_API BOOL SetCardSelectLight(DWORD CardNo, WORD value)
{
	return hardware.SetCardSelectLight((short)CardNo,value);
}


USB3AE_API BOOL SetCardGain(unsigned short chanNo, unsigned short gain)
{
	return hardware.SetCardGain(chanNo, gain);
}

USB3AE_API BOOL SetIncrementDB(unsigned short cardNo, unsigned short value)
{
	return hardware.SetIncrementDB(cardNo, value);
}


USB3AE_API BOOL SetFrontPower(unsigned short chanNo, unsigned short value)
{
	return hardware.SetFrontPower(chanNo, value);
}


USB3AE_API BOOL SetFilterGain(unsigned short chanNo, unsigned short filter, unsigned short gain)
{
	return hardware.SetFilterGain(chanNo, filter,gain);
}

USB3AE_API BOOL SetCardFilterGain(unsigned short CardNo, unsigned short ch0_filter, unsigned short ch0_gain,
                                                             unsigned short ch1_filter, unsigned short ch1_gain)

{
    return hardware.SetCardFilterGain(CardNo, ch0_filter, ch0_gain, ch1_filter, ch1_gain);
}

USB3AE_API BOOL SetExnTrig(DWORD CardNo, BOOL bStatus)
{
	//return hardware.SetExnTrig((short)CardNo,bStatus);
	return false;
}

USB3AE_API BOOL GetCardDriverVersion(DWORD CardNo, short *MajorVersion,short *MinorVersion,short *BuildVersion)
{
	//EZUSB_DRIVER_VERSION DriverVersion;
	BOOL status = hardware.GetCardDriverVersion((short)CardNo,MajorVersion, MinorVersion, BuildVersion);
	return status;
}

USB3AE_API BOOL StartSample()
{
	return hardware.StartSample();
}

USB3AE_API void StopSample()
{
	hardware.StopSample();
}

USB3AE_API void CloseAllCard()
{
	hardware.CloseAllCard();
}

USB3AE_API DWORD GetRawDataFromBuf(char *pBuf, DWORD& dwDataSize)
{
	return hardware.GetWaveDataFromBuf(pBuf, dwDataSize);
}

USB3AE_API DWORD GetFftDataFromBuf(char *pBuf, DWORD& dwDataSize)
{
	return hardware.GetFFTDataFromBuf(pBuf, dwDataSize);
}

USB3AE_API DWORD GetParamFromBuf(char *pBuf, DWORD& dwDataSize)
{
	return hardware.GetParamDataFromBuf(pBuf, dwDataSize);
}

USB3AE_API BOOL OnPluseTrig(int chanNo,int Trigvalue)
{
	return hardware.PluseTrig(chanNo,Trigvalue);
}

USB3AE_API BOOL OnPluseTrigStop(int chanNo)
{
	//return hardware.OnPluseTrigStop(chanNo);
	return true;
}

USB3AE_API DWORD GetsingleChannelBufLen()
{
	_variant_t vt;
	hardware.GetCardInfo(CARDINFO_WAVEFRAMELEN, 0, &vt);
	
	return vt.ulVal;	
	//return (((hardware.singleChannelBufLen - 8) >> 2) + 2);
}

USB3AE_API DWORD GetsingleFftBufLen()
{
	return 2048 * 2 + 48;
   //return (((hardware.singleFftBufLen - 8) >> 1) + 2);
}

USB3AE_API DWORD GetCardStatus(BOOL *bDeviceFlag, BOOL reset/* = TRUE*/)
{
	DWORD nCount = hardware.InitCards(reset);
	return nCount;
}

USB3AE_API BOOL SetCardPause(DWORD CardNo, BOOL bStatus)
{
	return hardware.SetCardPause((short)CardNo,bStatus);
}

USB3AE_API void SetExParamGain(short gain)
{
	 //hardware.usbGain = gain;
}

USB3AE_API BOOL SetSampleMode(unsigned short chanNo, int mode, int SampleSum, BOOL bIsStreaming )
{
	return hardware.SetSampleMode(chanNo, mode, SampleSum, bIsStreaming );
}

USB3AE_API BOOL SetExparamAttri(unsigned short cardNo, DWORD dwExparamAttri)
{
    return hardware.SetExparamAttri(cardNo, dwExparamAttri );
}

USB3AE_API BOOL SetExparamFixed(unsigned short chanNo, DWORD outInterval )
{
   return hardware.SetExparamFixed(chanNo, outInterval);
}
USB3AE_API BOOL  EnableSysTimer(unsigned short cardNo, DWORD sysTimer)
{
	return hardware.EnableSysTimer(cardNo, sysTimer);
}

USB3AE_API UINT GetVersionConf(unsigned short cardNo)
{
	return hardware.GetVersionConf(cardNo);
}

USB3AE_API DWORD GetFirFilterOrder()
{
	return hardware.GetFirFilterOrder();
}

USB3AE_API int SetFirFilter(DWORD CardNo, short type, short low, short high)
{
	return hardware.SetFirFilter((short)CardNo, type, low, high);
}

USB3AE_API int DisableFirFilter(DWORD CardNo)
{
	return hardware.DisableFirFilter((short)CardNo);
}

USB3AE_API int SetFFTWorkMode(DWORD CardNo, DWORD mode)
{
	return hardware.SetFFTWorkMode((short)CardNo, mode);
}
USB3AE_API int SetFFTWaveTrigPara(DWORD CardNo, DWORD fftWaveThreshold)
{
	return hardware.SetFFTWaveTrigPara((short) CardNo, fftWaveThreshold);
}
USB3AE_API int SetChFFTResultScale(unsigned short ChanNo, double scale)
{
	return hardware.SetChFFTResultScale(ChanNo, scale);
}

USB3AE_API int SetChFFTWindowFunction(unsigned short ChanNo, BOOL bEnableWindow, int iFftWinType, int len)
{
	return hardware.SetChFFTWindowFunction(ChanNo, bEnableWindow, iFftWinType, len);
}

USB3AE_API int SetChFFTSaveLen(unsigned short ChanNo, int len)
{
	return hardware.SetChFFTSaveLen(ChanNo, len);
}

USB3AE_API int SetChFFTDecimateRate(unsigned short ChanNo, int val)
{
	return hardware.SetChFFTDecimateRate(ChanNo, val);
}

USB3AE_API int SetChFFTPartialPowerSegment(unsigned short ChanNo, unsigned int id, int StartBin, int EndBin)
{
	return hardware.SetChFFTPartialPowerSegment(ChanNo, id, StartBin, EndBin);
}

USB3AE_API int SetChStreamingMode(unsigned short ChanNo, BOOL bEnabled, int TrigMode)
{
    return hardware.SetChStreamingMode(ChanNo, bEnabled, TrigMode);
}

USB3AE_API BOOL StartChStreamingInternalTrig(unsigned short chanNo)
{
    return hardware.StartChStreamingInternalTrig(chanNo);
}

USB3AE_API BOOL SetAdg1439(DWORD CardNo, unsigned long dat_l, unsigned long dat_h)
{
    return hardware.SetAdg1439(CardNo, dat_l, dat_h);
}

USB3AE_API BOOL GetTransmitStatisticData(unsigned short CardNo, unsigned __int64 val[4])
{
    //return hardware.GetTransmitStatisticData(CardNo, val);
	return false;
}

USB3AE_API BOOL ClearTransmitStatisticData(unsigned short CardNo)
{
    //return hardware.ClearTransmitStatisticData(CardNo);
	return false;
}

//#ifdef _DEBUG
USB3AE_API void ReadCardRegister(short CardId, UCHAR addr, UINT *value)
{
    hardware.ReadRegister(CardId, addr, value);
}

USB3AE_API void WriteCardRegister(short CardId, UCHAR addr, UINT value)

{
    hardware.WriteRegister(CardId, addr, value);
}

USB3AE_API void GetOutputInfo(UINT input[10], PCHAR pStrBuf, int bufSize)
{
    //hardware.GetOutputInfo(input, pStrBuf, bufSize);
}

USB3AE_API char* GetOutputInfo1(UINT input[10])
{
    //return hardware.GetOutputInfo(input);
	return NULL;
}

USB3AE_API void ConfigureBeforeStart()
{
    //hardware.ConfigureBeforeStart();
}

USB3AE_API void ConfigureAfterStart()
{
    //hardware.ConfigureAfterStart();
}

USB3AE_API BOOL GetMbFwVersion(short ChassisId, UINT *val)
{
	//return hardware.GetMbFwVersion(ChassisId, val);
	return false;
}

USB3AE_API BOOL GetAECardFwVersion(short CardId, UINT *val)
{
	_variant_t vt;
	hardware.GetCardInfo(CARDINFO_FPGAVERSION, CardId, &vt);
	*val = vt.ulVal;
	return true;
	//return hardware.GetAECardFwVersion(CardId, val);
}

USB3AE_API void SetEncoding(unsigned short CardNo, DWORD PackingVer, DWORD FramingVer, DWORD encoding, DWORD bits)
{
    //hardware.SetEncoding(CardNo, PackingVer, FramingVer, encoding, bits);	
}

USB3AE_API BOOL GetCardStreamingState(DWORD CardNo, unsigned long *states)
{
    //return hardware.GetCardStreamingState(CardNo, states);
	return false;
}

USB3AE_API int OutputChAlarm(DWORD ChNo, DWORD mode)
{
    //return hardware.OutputChAlarm(ChNo, mode);
	return 0;
}

USB3AE_API int SetCardAlarmTimeout(DWORD CardNo, DWORD ms)
{
    return hardware.SetCardAlarmTimeout(CardNo, ms);
}

USB3AE_API int StopChAlarm(DWORD ChNo)
{
    //return hardware.StopChAlarm(ChNo);
	return 0;
}


