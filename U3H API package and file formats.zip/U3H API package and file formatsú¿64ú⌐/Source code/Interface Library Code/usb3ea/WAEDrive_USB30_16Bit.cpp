// WAEDrive_USB_16Bit.cpp : implementation file
//

#include "WAEDrive_USB30_16Bit.h"
#include "Usb7kC.h"
//#include "hardware.h"
//#include "WAECommDebugToolDlg.h"
#include "USB30_16bit_Data_Thread.h"
//#include "..\WAEDialog/WAESystemSetDlg_Usb30_16Bit.h"
//#include "Arithmetic.h"
#include "DriveDataDefine.h"
//#include "hardware.h"
#include "math.h"
#include "Arithmetic.h"

#pragma comment(lib, "CyUSB.lib")
#pragma comment(lib, "Arithmetic.lib")

using namespace Usb7kCio_USB3016Bit;

#define SOUNDWEL_VID         0x01037085
#define USB_HUB_16BIT_NEW_PID    0x0131
//#define CHANNEL_COUNT_PERCARD		4		//ÿ�����ϵ����ͨ����

const UINT g_ChRegBaseAddrs[] = {PROP_CH0_REG_BASEADDR, PROP_CH1_REG_BASEADDR, PROP_CH2_REG_BASEADDR
	, PROP_CH3_REG_BASEADDR, PROP_CH4_REG_BASEADDR, PROP_CH5_REG_BASEADDR};

#define FIR_ORDER	63		//FIR�˲�������
#define     AE_EXPARAM_FIXED					0xa
#define     AE_SAMPLE_MODE						0xc
#define     AE_FFT_MODE_REG						0xe		//FFT����ģʽ�Ĵ���
#define     AE_FIR_CFG_REG						0xf		//FIR�˲������üĴ�����ַ
/**************FIR���üĴ���λ����***************************************/
#define     AE_FIR_CFG_COEF_DATA_MASK			0xFFFF	//�˲���ϵ��
//0ͨ���˲���ϵ��д��Ч�����ź���������Ч����Чʱ���Ὣcfg_coef_dataд��ϵ���������С�
#define     AE_FIR_CFG_COEF_WR					0x10000
//��ʼ����0ͨ���˲���ϵ�������ź���������Ч����Чʱ���Ὣϵ���������е�ϵ�����õ�ͨ��0���˲�����
#define     AE_FIR_CFG_COEF_CFG_CH0				0x020000
//��ʼ����1ͨ���˲���ϵ�������ź���������Ч����Чʱ���Ὣϵ���������е�ϵ�����õ�ͨ��1���˲�����
#define     AE_FIR_CFG_COEF_CFG_CH1				0x040000
//�˲�����λ�źţ�����Ч����ϵͳ��Ч������£������ô�λ��Ϊ0����λ�˲��������߼���
//Ȼ���ٽ���λ��Ϊ1����ʼ�����˲���ϵ����                                                                                                                                            
#define     AE_FIR_CFG_RSTN						0x080000
#define     AE_FIR_CFG_EN_CH0					0x100000//Ϊ1ʱ��ʹ��ͨ��0���˲�����
#define     AE_FIR_CFG_EN_CH1					0x200000//Ϊ1ʱ��ʹ��ͨ��1���˲�����
/************************************************************************/

#define     AE_HIT_CFG_BASEADDR_CH0				0x10	//ͨ��0�������û���ַ
#define     AE_HIT_CFG_BASEADDR_CH1				0x20	//ͨ��1�������û���ַ
/**************ͨ����������ƫ�Ƶ�ַ��Ѱַ��ʽΪ(����ַ+ƫ�Ƶ�ַ)*********/
#define     AE_HIT_CFG_FFTSCALE_REG				0x08	//FFT���scale���üĴ���
//��ʹ�ܴ�����ʱ�����ڴ������������棬Ϊ�˽��������������Ϊ1����Ҫ��FFT
//����Ľ��������Ӧ����������. �˼Ĵ���Ϊ2�Ĳ����ʾ�Ķ�����
#define     AE_HIT_CFG_FFTSCALE_DATAMASK		0x3FFFF

#define		AE_HIT_CFG_WINFUNC_REG				0x07	//�������������üĴ���
#define		AE_HIT_CFG_WIN_COEF_ADDR_MASK		0x3FF	//���������ݴ洢����ַ�����ŵ�ͬ�ڴ��������е���š�
#define     AE_HIT_CFG_WIN_COEF_DATA_MASK		0xFFFFC00	//����������
#define		AE_HIT_CFG_WIN_WR					0x10000000	//������д�����źš��ź���������Ч
//#define		AE_HIT_CFG_WIN_EN					0x20000000	//��Чʱ��ʹ�ܴ������������ֹ������

#define		AE_HIT_CFG_FFT_SAVELEN_REG			0x06		//FFT���������泤�ȼĴ���
#define		AE_HIT_CFG_FFT_SAVELEN_MASK			0xFFFF		//

#define		AE_HIT_CFG_FFT_DECIMATE_RATE_REG	0x09		//ͨ���źų�ȡ���ʼĴ���
#define		AE_HIT_CFG_FFT_DECIMATE_RATE_MASK	0xFFFF		//�źų�ȡ�ʡ����Ϊ65535����СΪ1��ע����Ҫͬ�˲������õ����

#define		AE_HIT_CFG_FFT_PARTIALPOW_REG0		0x0A		//��1��Partial Power�����СBin�Ĵ���
#define		AE_HIT_CFG_FFT_PARTIALPOW_REG1		0x0B		//��2��Partial Power�����СBin�Ĵ���
#define		AE_HIT_CFG_FFT_PARTIALPOW_REG2		0x0C		//��3��Partial Power�����СBin�Ĵ���
#define		AE_HIT_CFG_FFT_PARTIALPOW_REG3		0x0D		//��4��Partial Power�����СBin�Ĵ���
#define		AE_HIT_CFG_FFT_PARTIALPOW_REG4		0x0E		//��5��Partial Power�����СBin�Ĵ���
#define		AE_HIT_CFG_FFT_PARTIALPOW_MIN_MASK	0x1FF		//��ʼFFT Bin

UINT g_nLostCount = 0;


#define USB30POINTCOUNT 252

CHardWare_USB30_16Bit::CHardWare_USB30_16Bit(DWORD dwChanCount ): CWAE_HardWare(dwChanCount)
{
	m_dwDevStatus = USB_DEV_UNINITIAL;

	m_nPackVer = 0;
	m_nFrmVer = 0;
	m_nFrmEncodeType = 1;
	m_nFrmDpcmBits = 0x0D;	
	m_hDataEvent = NULL;
	m_iPackageStatus = USB16BIT_ALLFINISH;
	m_iRestPackageCount = 0;
	for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		m_nWavePointCount[i] = 0;
	}
	
	//m_nWavePointCount[0] = 0;
	//m_nWavePointCount[1] = 0;
	memset(&m_ovReadData,0,sizeof(OVERLAPPED));
	//memset(m_exParamBuf, 0, 12 * sizeof(short));
	m_recvbuffer = NULL;
	m_recvbuffer = new UCHAR[USB30_BUFFER_SIZE];
	m_bExParamEnable = FALSE;

	m_bEnableGPS = FALSE;      //�Ƿ�����GPS


	m_dwExParamFixTime = 1000; //��ζ�ʱ����ʱ��
	m_bExParamEnable = FALSE;   //�Ƿ�ɼ����


	//FFT����
	m_bFFTEnable = FALSE;
	m_iFftWinType = enFFTWinRect;         //FFT������
	m_iFftParaTrigType = enHitTrigParaThres;    //FFT����������ʽ
	m_iFftParaTrigPara = 0;    //FFT�����������ò���ֵ
	m_iFftWaveDataType = enFFTWaveDataAll;    //FFT������������,ָԭʼFFT���ݺͷ���������
	m_iFftWaveTrigType = enTrigSrcFreeRun;    //FFT���δ�����ʽ
	m_iFftWaveTrigPara = 0;    //FFT���δ������ò���ֵ

	for (int i = 0; i < MAX_FFT_PART_POWER_NUM; i++)
	{
		m_bFftPartPowerEnables[i] = FALSE;	//ʹ�ֲܾ������ײ���
		m_iFftPartPowerFroms[i] = 0;			//�ֲ���������ʼƵ��
		m_iFftPartPowerTos[i] = 0;			//�ֲ���������ֹƵ��
	}
	m_iFftTotalPowerFrom = 0; //��������ʼƵ��
	m_iFftTotalPowerTo = 0;    //��������ֹƵ��
	m_dwFftRamSize = 0;	       //���Ϸ����RAM��С
	m_dwFftLen = 1;	           //FFT��������
	m_dwFftDecimateRate = 2;   //��ȡ��
	m_dwFftWorkMode = AE_FFT_CFG_FREE_RUN0 | AE_FFT_CFG_FREE_RUN1;  //FFT����ģʽ

	m_pXmitBuf = NULL;
	
}
CHardWare_USB30_16Bit::~CHardWare_USB30_16Bit()
{
	if( m_recvbuffer )
	{
		delete[] m_recvbuffer;
		m_recvbuffer = NULL;
	}
	if( m_pXmitBuf )
	{
		delete[] m_pXmitBuf;
		m_pXmitBuf = NULL;
	}
}

void CHardWare_USB30_16Bit::SetSampleLength( DWORD dwLength )
{
	//m_paramFIFO.ReleaseBuf();
	//m_waveFIFO.ReleaseBuf();
	//m_paramFIFO.AllocateBuf(20000);
	m_waveFIFO.SetWaveDataSize(dwLength * 2 + 48 );

	for (int i = 0; i< m_iChanCount; i++)
	{
		m_pChannels[i].m_dwSampleLength = dwLength;
		m_nWavePointCount[i] = 0;
	}
	//m_nWavePointCount[0] = 0;
	//m_nWavePointCount[1] = 0;
	m_iRestPackageCount = 0;
	m_iPackageStatus = 0;
	
	//ǰ�ŵ�Դ
	if( m_pDriver == NULL )
		return;

	if( m_dwDevStatus != USB_DEV_OPEN )
		OpenUSB7kC_ByCardNo((short)m_dwCardNo);
	for (int j = 0; j < m_iChanCount; j++)
	{
		((CWAEDrive_USB30_16Bit*)m_pDriver)->WriteRegister((short)m_dwCardNo, g_ChRegBaseAddrs[j] + PROP_CH_FRONT_POWER, 1<< m_pChannels[j].m_nFrontPower);
	}
	//CloseUSB7kC((short)m_dwCardNo);
	//m_dwDevStatus = USB_DEV_CLOSE;
	
}

#ifdef OLD_USB16BIT
void CHardWare_USB30_16Bit::OnReceiveData(char* buff, int count)
{
	if( count < 1 || m_pDriver == NULL ) return;
	if (m_dwDevStatus != USB_DEV_OPEN) return;
	memcpy(&m_analybuffer[BLOCK_SIZE * m_iRestPackageCount], m_recvbuffer, count);
	CWAEDrive_USB30_16Bit* pDirve = (CWAEDrive_USB30_16Bit*)m_pDriver;
	int iPackageCount = count / BLOCK_SIZE + m_iRestPackageCount; 
	PACK_HEAD *pPackHead = NULL;
	char *pDataBuf = NULL;
	int  iDataLen = 0;
	int iRawDataLen = (m_pChannels[0].m_dwSampleLength << 1)  + 8;
	int iRawPackCount = (iRawDataLen + BLOCK_SIZE -1) / BLOCK_SIZE;
	int iFFTDataLen = (MAX_FFTDATA_LENGTH << 1) + 8;;
	int iFFTPackCount = (iFFTDataLen + BLOCK_SIZE -1) / BLOCK_SIZE;


	for(int i = 0; i < iPackageCount; )
	{

		pPackHead = (PACK_HEAD*)&m_analybuffer[i*BLOCK_SIZE];

		pDataBuf = (char*)&m_analybuffer[i*BLOCK_SIZE];
		iDataLen = BLOCK_SIZE;

		if( m_iPackageStatus == USB16BIT_RESTWAVE || (m_iPackageStatus == USB16BIT_ALLFINISH &&  (((USHORT*)pDataBuf)[0] & 0xC000) == 0x8000) )
		{
			if(i + iRawPackCount <= iPackageCount) 
			{ 
				FRAME_FLAG *pFrmFlag = (FRAME_FLAG *)pDataBuf;
				m_waveData[0].StartTag = WAVESTARTTAG;
				m_waveData[0].ChannelId = pFrmFlag->spec.card * CHANNEL_COUNT_PERCARD + pFrmFlag->spec.ChOfCard + 1;
				m_waveData[0].FrameNo = 0;
				m_waveData[0].SampleFreq = m_pChannels[0].m_dwSampleFreq;
				m_waveData[0].SampleLength = m_pChannels[0].m_dwSampleLength;
				m_waveData[0].WaveType = WAVE_DATA;
				m_waveData[0].ValueType = VALUE_16Bit;
				m_waveData[0].ArrivingTimens = (((unsigned __int64)(((DWORD*)pDataBuf)[1] ) << 16) | ((unsigned __int64)(((DWORD*)pDataBuf)[0]) >> 16)) * 100;		
				m_waveData[0].ArrivingTimens *= 100;
				GetArriveTime(&m_waveData[0].ArrivingTimeST, &pDirve->GetSampleStartTime(), m_waveData[0].ArrivingTimens);
				short *pDpcm = (short*)&pDataBuf[8];	
				memcpy(&m_waveData[0].WaveValue[0], pDpcm, sizeof(short)*m_pChannels[0].m_dwSampleLength);
				//for (DWORD k = 0; k < m_pChannels[0].m_dwSampleLength; k++)
				//{
				//	//m_waveData[0].WaveValue[k] = (int)pDpcm[k];
				//	// Edited by mengl 2016-5-17;
				//	// purpose:����ֵ��short���ͽ��д洢;
				//	//m_waveData[0].WaveValue[k] = ((int)(pDpcm[k] & 0xFFF8) << 16) >> (19 - (pDpcm[k] & 0x0007)) >> 2;
				//	m_waveData[0].WaveValue[k] = ((pDpcm[k] & 0xFFF8) << 16) >> (19 - (pDpcm[k] & 0x0007)) >> 2;
				//}

				m_waveFIFO.pushsingle(&m_waveData[0]);
				i +=  iRawPackCount;
				m_iRestPackageCount = 0;
				m_iPackageStatus = USB16BIT_ALLFINISH;
			}else 
			{ 
				if( i != 0 )
					memcpy(&m_analybuffer, &m_analybuffer[i*BLOCK_SIZE], (iPackageCount -i) * BLOCK_SIZE );
				m_iRestPackageCount = iPackageCount -i;
				m_iPackageStatus = USB16BIT_RESTWAVE;
				break;
			}

		}else if( m_iPackageStatus == USB16BIT_RESTFFT || (m_iPackageStatus == USB16BIT_ALLFINISH &&  (((USHORT*)pDataBuf)[0] & 0xC000) == 0xC000))
		{
			if(i + iFFTPackCount <= iPackageCount) 
			{ 
				FRAME_FLAG *pFrmFlag = (FRAME_FLAG *)pDataBuf;
				m_fftData[0].StartTag = WAVESTARTTAG;
				m_fftData[0].ChannelId = pFrmFlag->spec.card * CHANNEL_COUNT_PERCARD + pFrmFlag->spec.ChOfCard + 1;
				m_fftData[0].FrameNo = 0;
				m_fftData[0].SampleFreq = m_pChannels[0].m_dwSampleFreq;
				m_fftData[0].SampleLength = m_pChannels[0].m_dwSampleLength;
				m_fftData[0].WaveType = FFT_DATA;
				m_waveData[0].ValueType = VALUE_16Bit;
				m_fftData[0].ArrivingTimens = ((unsigned __int64)(((DWORD*)pDataBuf)[1] ) << 16) | ((unsigned __int64)(((DWORD*)pDataBuf)[0]) >> 16);
				m_fftData[0].ArrivingTimens *= 100;
				GetArriveTime(&m_fftData[0].ArrivingTimeST, &pDirve->GetSampleStartTime(), m_fftData[0].ArrivingTimens);
				short *pDpcm = (short*)&pDataBuf[8];
				// Edited by mengl 2016-5-17;
				// purpose:����ֵ��short���ͽ��д洢;
				memcpy(&m_fftData[0].WaveValue[0], pDpcm, sizeof(short)*MAX_FFTDATA_LENGTH);
				//for (DWORD k = 0; k < MAX_FFTDATA_LENGTH; k++)
				//{
				//	m_fftData[0].WaveValue[k] = pDpcm[k];
				//}
				//m_fftFIFO.pushsingle(&m_fftData[0]);
				i +=  iFFTPackCount;
				m_iRestPackageCount = 0;
				m_iPackageStatus = USB16BIT_ALLFINISH;
			}else 
			{  
				if( i != 0 )
					memcpy(&m_analybuffer, &m_analybuffer[i*BLOCK_SIZE], (iPackageCount -i) * BLOCK_SIZE );
				m_iRestPackageCount = iPackageCount -i;
				m_iPackageStatus = USB16BIT_RESTFFT;
				break;
			}
		}else
		{			
			PARAM *curParam =(PARAM*)pDataBuf;
			for( int j= 0;  j < PARAM_SUM_EACH_PACKAGE; j++, curParam ++)
			{
				if ((curParam->ArriveTime.Time1 == 0) && (curParam->ArriveTime.Time2 == 0))
					break;			

				FRAME_FLAG *pFrmFlag = (FRAME_FLAG *)curParam;
				if ((curParam->ChNo & 0xE000) == STATE_FLAG)
				{
					//״̬֡
					STPARAM_TYPE_0 *tempStParam = (STPARAM_TYPE_0 *)curParam;
					DWORD cardno = pFrmFlag->spec.card;
					m_pChannels[0].m_bIsStreaming = tempStParam->Ch0_State;
					m_pChannels[1].m_bIsStreaming = tempStParam->Ch1_State;
				}
				else if ((curParam->ChNo & 0xE000) == SYSTIME_FLAG)
				{
					//ʱ��֡
					//Param2CommonParam(&m_paramBuff[0], curParam);
					//m_paramFIFO.pushsingle(&m_paramBuff[0]);
				}
				else if ((curParam->ChNo & 0xE000) == EXPARA_FLAG)
				{
					if (m_dwDevStatus != USB_DEV_OPEN) continue;	
					//���֡
					DWORD cardno = pFrmFlag->spec.card;	
					curParam->ChNo = cardno + pFrmFlag->spec.ChOfCard;
					if (curParam->ChNo > 0)
					{
						continue;
					}
					m_exParamBuf[cardno * 4    ] = curParam->exparam[0];
					m_exParamBuf[cardno * 4 + 1] = curParam->exparam[1];
					m_exParamBuf[cardno * 4 + 2] = curParam->exparam[2];
					m_exParamBuf[cardno * 4 + 3] = curParam->exparam[3];
					memset(&curParam->MaxAmp, 0, sizeof(PARAM) - sizeof(TIME) - sizeof(unsigned short));
					memcpy(curParam->exparam, m_exParamBuf, sizeof(short) * 12);					
					Param2CommonParam(&m_paramBuff[0], curParam);
					m_paramBuff[0].DurationTimeus = m_paramBuff[0].ArrivingTimeus;
					m_paramBuff[0].RiseTimeus = m_paramBuff[0].ArrivingTimeus;
					m_paramBuff[0].ASL = 0;
					m_paramFIFO[(m_paramBuff[0].ChannelId+1)%CHANNEL_COUNT_PERCARD].pushsingle(&m_paramBuff[0]);
				}
				else
				{
					if (m_dwDevStatus != USB_DEV_OPEN) continue;	
					//��ͨ����֡
					DWORD chno = pFrmFlag->spec.card * CHANNEL_COUNT_PERCARD + pFrmFlag->spec.ChOfCard;
					if (chno >= MAX_CARDNUM*CHANNEL_COUNT_PERCARD)
					{
						continue;
					}
					curParam->ChNo = (USHORT)chno;
					if (m_bExParamEnable)
					{
						if (m_bFFTEnable)
						{
							memcpy(curParam->exparam, m_exParamBuf, sizeof(short) * 5);
						}
						else
						{
							memcpy(curParam->exparam, m_exParamBuf, sizeof(short) * 12);
						}
					}
					Param2CommonParam(&m_paramBuff[0], curParam);	
					// Edited by mengl 2016-11-25;
					// purpose:������������ע�͵�
					//if(CWAESystemConfigManager::GetInstance().GetParamFilter().FilterPara(&m_paramBuff[0]))
					m_paramFIFO[(m_paramBuff[0].ChannelId+1)%CHANNEL_COUNT_PERCARD].pushsingle(&m_paramBuff[0]);
					//TRACE("CHNO:%d, ARRiVETIme: %llu\n",m_paramBuff[0].ChannelId, m_paramBuff[0].ArrivingTimens);
				}					   
			}
			i++; 
		}
	}
}
#else
DWORD g_nParamCount = 0;
void CHardWare_USB30_16Bit::OnReceiveData(char* buff, int count)
{
	if( count < 1 || m_pDriver == NULL ) return;
	if (m_dwDevStatus != USB_DEV_OPEN) return;
	memcpy(&m_analybuffer[BLOCK_SIZE * m_iRestPackageCount], m_recvbuffer, count);
	CWAEDrive_USB30_16Bit* pDirve = (CWAEDrive_USB30_16Bit*)m_pDriver;
	int iPackageCount = count / BLOCK_SIZE + m_iRestPackageCount; 
	PACK_HEAD *pPackHead = NULL;
	char *pDataBuf = NULL;
	int  iDataLen = 0;
	int iRawDataLen = (m_pChannels[0].m_dwSampleLength << 1)  + 8;
	int iRawPackCount = (iRawDataLen + BLOCK_SIZE -1) / BLOCK_SIZE;
	int iFFTDataLen = (MAX_FFTDATA_LENGTH << 1) + 8;;
	int iFFTPackCount = (iFFTDataLen + BLOCK_SIZE -1) / BLOCK_SIZE;

	//TRACE("Recieve start\n");
	for(int i = 0; i < iPackageCount; )
	{

		pPackHead = (PACK_HEAD*)&m_analybuffer[i*BLOCK_SIZE];

		pDataBuf = (char*)&m_analybuffer[i*BLOCK_SIZE];
		iDataLen = BLOCK_SIZE;
		
		if( m_iPackageStatus == USB16BIT_RESTWAVE || (m_iPackageStatus == USB16BIT_ALLFINISH &&  (((USHORT*)pDataBuf)[0] & 0xC000) == 0x8000) )
		{
			FRAME_FLAG *pFrmFlag = (FRAME_FLAG *)pDataBuf;
			if( pFrmFlag->spec.ChOfCard >= m_iChanCount ) break;
			if(m_pChannels[pFrmFlag->spec.ChOfCard].m_bIsStreaming)
			{				
				if( m_nWavePointCount[pFrmFlag->spec.ChOfCard] == 0 )
				{
					m_waveData[pFrmFlag->spec.ChOfCard].StartTag = WAVESTARTTAG;
					m_waveData[pFrmFlag->spec.ChOfCard].ChannelId = pFrmFlag->spec.card * CHANNEL_COUNT_PERCARD + pFrmFlag->spec.ChOfCard + 1;
					m_waveData[pFrmFlag->spec.ChOfCard].FrameNo = 0;
					m_waveData[pFrmFlag->spec.ChOfCard].SampleFreq = m_pChannels[pFrmFlag->spec.ChOfCard].m_dwSampleFreq;
					m_waveData[pFrmFlag->spec.ChOfCard].SampleLength = m_pChannels[pFrmFlag->spec.ChOfCard].m_dwSampleLength;
					m_waveData[pFrmFlag->spec.ChOfCard].WaveType = WAVE_DATA;
					m_waveData[pFrmFlag->spec.ChOfCard].ValueType = VALUE_U3H_0 + m_pChannels[pFrmFlag->spec.ChOfCard].m_nGain;
					m_waveData[pFrmFlag->spec.ChOfCard].ArrivingTimens = (((unsigned __int64)(((DWORD*)pDataBuf)[1] ) << 16) | ((unsigned __int64)(((DWORD*)pDataBuf)[0]) >> 16)) * 100;		
					GetArriveTime(&m_waveData[pFrmFlag->spec.ChOfCard].ArrivingTimeST, &pDirve->GetSampleStartTime(), m_waveData[pFrmFlag->spec.ChOfCard].ArrivingTimens);
					short *pDpcm = (short*)&pDataBuf[8];	
					memcpy(&m_waveData[pFrmFlag->spec.ChOfCard].WaveValue[m_nWavePointCount[pFrmFlag->spec.ChOfCard]], pDpcm, sizeof(short)*USB30POINTCOUNT);
					m_nWavePointCount[pFrmFlag->spec.ChOfCard] += USB30POINTCOUNT;
					if( m_nWavePointCount[pFrmFlag->spec.ChOfCard] >= m_waveData[pFrmFlag->spec.ChOfCard].SampleLength)
					{
						m_waveFIFO.pushsingle(&m_waveData[pFrmFlag->spec.ChOfCard]);
						m_nWavePointCount[pFrmFlag->spec.ChOfCard] = 0;	

					}
				}else if( m_nWavePointCount[pFrmFlag->spec.ChOfCard] < m_pChannels[pFrmFlag->spec.ChOfCard].m_dwSampleLength)
				{
					int nCount = (((((unsigned __int64)(((DWORD*)pDataBuf)[1] ) << 16) | ((unsigned __int64)(((DWORD*)pDataBuf)[0]) >> 16)) * 100 - m_waveData[pFrmFlag->spec.ChOfCard].ArrivingTimens)*m_waveData[pFrmFlag->spec.ChOfCard].SampleFreq)/1000000;
					short *pDpcm = (short*)&pDataBuf[8];	
					if(m_nWavePointCount[pFrmFlag->spec.ChOfCard] < nCount  )//����
					{
						if( nCount  >= m_waveData[pFrmFlag->spec.ChOfCard].SampleLength)
						{
							memset(&m_waveData[pFrmFlag->spec.ChOfCard].WaveValue[m_nWavePointCount[pFrmFlag->spec.ChOfCard]], 0, sizeof(short)*(m_waveData[pFrmFlag->spec.ChOfCard].SampleLength - m_nWavePointCount[pFrmFlag->spec.ChOfCard] ));
							//TRACE("lost count %d\n", (m_waveData[pFrmFlag->spec.ChOfCard].SampleLength - m_nWavePointCount[pFrmFlag->spec.ChOfCard] )/USB30POINTCOUNT);
							m_nWavePointCount[pFrmFlag->spec.ChOfCard] += m_pChannels[pFrmFlag->spec.ChOfCard].m_dwSampleLength;				
							m_waveFIFO.pushsingle(&m_waveData[pFrmFlag->spec.ChOfCard]);
							m_nWavePointCount[pFrmFlag->spec.ChOfCard] = 0;				
							//i -= 1;
							continue;
						}else
						{
							memset(&m_waveData[pFrmFlag->spec.ChOfCard].WaveValue[m_nWavePointCount[pFrmFlag->spec.ChOfCard]], 0, sizeof(short)*(m_waveData[pFrmFlag->spec.ChOfCard].SampleLength - m_nWavePointCount[pFrmFlag->spec.ChOfCard] ));
							//g_nLostCount += (nCount - m_nWavePointCount[pFrmFlag->spec.ChOfCard] )/USB30POINTCOUNT;
							//TRACE("lost count %d\n", (nCount - m_nWavePointCount[pFrmFlag->spec.ChOfCard] )/USB30POINTCOUNT);
							memcpy(&m_waveData[pFrmFlag->spec.ChOfCard].WaveValue[nCount], pDpcm, sizeof(short)*USB30POINTCOUNT);
							m_nWavePointCount[pFrmFlag->spec.ChOfCard] += nCount + USB30POINTCOUNT;		
							if( m_nWavePointCount[pFrmFlag->spec.ChOfCard] >= m_waveData[pFrmFlag->spec.ChOfCard].SampleLength)
							{
								m_waveFIFO.pushsingle(&m_waveData[pFrmFlag->spec.ChOfCard]);
								m_nWavePointCount[pFrmFlag->spec.ChOfCard] = 0;				
							}						
						}

					}else
					{					
						memcpy(&m_waveData[pFrmFlag->spec.ChOfCard].WaveValue[m_nWavePointCount[pFrmFlag->spec.ChOfCard]], pDpcm, sizeof(short)*USB30POINTCOUNT);
						m_nWavePointCount[pFrmFlag->spec.ChOfCard] += USB30POINTCOUNT;
						if( m_nWavePointCount[pFrmFlag->spec.ChOfCard] >= m_waveData[pFrmFlag->spec.ChOfCard].SampleLength)
						{
							m_waveFIFO.pushsingle(&m_waveData[pFrmFlag->spec.ChOfCard]);
							m_nWavePointCount[pFrmFlag->spec.ChOfCard] = 0;				
						}
					}
				}
				i++;
				m_iRestPackageCount = 0;
				m_iPackageStatus = USB16BIT_ALLFINISH;
			}else
			{
				if(i + iRawPackCount <= iPackageCount) 
				{ 
					//FRAME_FLAG *pFrmFlag = (FRAME_FLAG *)pDataBuf;
					m_waveData[pFrmFlag->spec.ChOfCard].StartTag = WAVESTARTTAG;
					m_waveData[pFrmFlag->spec.ChOfCard].ChannelId = pFrmFlag->spec.card * CHANNEL_COUNT_PERCARD + pFrmFlag->spec.ChOfCard + 1;
					m_waveData[pFrmFlag->spec.ChOfCard].FrameNo = 0;
					m_waveData[pFrmFlag->spec.ChOfCard].SampleFreq = m_pChannels[pFrmFlag->spec.ChOfCard].m_dwSampleFreq;
					m_waveData[pFrmFlag->spec.ChOfCard].SampleLength = m_pChannels[pFrmFlag->spec.ChOfCard].m_dwSampleLength;
					m_waveData[pFrmFlag->spec.ChOfCard].WaveType = WAVE_DATA;
					m_waveData[pFrmFlag->spec.ChOfCard].ValueType = VALUE_U3H_0 + m_pChannels[pFrmFlag->spec.ChOfCard].m_nGain;
					m_waveData[pFrmFlag->spec.ChOfCard].ArrivingTimens = (((unsigned __int64)(((DWORD*)pDataBuf)[1] ) << 16) | ((unsigned __int64)(((DWORD*)pDataBuf)[0]) >> 16)) * 100;		
					GetArriveTime(&m_waveData[pFrmFlag->spec.ChOfCard].ArrivingTimeST, &pDirve->GetSampleStartTime(), m_waveData[pFrmFlag->spec.ChOfCard].ArrivingTimens);
					short *pDpcm = (short*)&pDataBuf[8];	
					memcpy(&m_waveData[pFrmFlag->spec.ChOfCard].WaveValue[0], pDpcm, sizeof(short)*m_pChannels[pFrmFlag->spec.ChOfCard].m_dwSampleLength);
					m_waveFIFO.pushsingle(&m_waveData[pFrmFlag->spec.ChOfCard]);
					i +=  iRawPackCount;
					m_iRestPackageCount = 0;
					m_iPackageStatus = USB16BIT_ALLFINISH;
				}else 
				{ 
					if( i != 0 )
						memcpy(&m_analybuffer, &m_analybuffer[i*BLOCK_SIZE], (iPackageCount -i) * BLOCK_SIZE );
					m_iRestPackageCount = iPackageCount -i;
					m_iPackageStatus = USB16BIT_RESTWAVE;
					break;
				}
			}


		}else if( m_iPackageStatus == USB16BIT_RESTFFT || (m_iPackageStatus == USB16BIT_ALLFINISH &&  (((USHORT*)pDataBuf)[0] & 0xC000) == 0xC000))
		{
			if(i + iFFTPackCount <= iPackageCount) 
			{ 
				FRAME_FLAG *pFrmFlag = (FRAME_FLAG *)pDataBuf;
				m_fftData[0].StartTag = WAVESTARTTAG;
				m_fftData[0].ChannelId = pFrmFlag->spec.card * CHANNEL_COUNT_PERCARD + pFrmFlag->spec.ChOfCard + 1;
				m_fftData[0].FrameNo = 0;
				m_fftData[0].SampleFreq = m_pChannels[0].m_dwSampleFreq;
				m_fftData[0].SampleLength = m_pChannels[0].m_dwSampleLength;
				m_fftData[0].WaveType = FFT_DATA;
				m_waveData[0].ValueType = VALUE_16Bit;
				m_fftData[0].ArrivingTimens = ((unsigned __int64)(((DWORD*)pDataBuf)[1] ) << 16) | ((unsigned __int64)(((DWORD*)pDataBuf)[0]) >> 16);
				m_fftData[0].ArrivingTimens *= 100;
				GetArriveTime(&m_fftData[0].ArrivingTimeST, &pDirve->GetSampleStartTime(), m_fftData[0].ArrivingTimens);
				short *pDpcm = (short*)&pDataBuf[8];
				// Edited by mengl 2016-5-17;
				// purpose:����ֵ��short���ͽ��д洢;
				memcpy(&m_fftData[0].WaveValue[0], pDpcm, sizeof(short)*MAX_FFTDATA_LENGTH);
				//for (DWORD k = 0; k < MAX_FFTDATA_LENGTH; k++)
				//{
				//	m_fftData[0].WaveValue[k] = pDpcm[k];
				//}
				//m_fftFIFO.pushsingle(&m_fftData[0]);
				i +=  iFFTPackCount;
				m_iRestPackageCount = 0;
				m_iPackageStatus = USB16BIT_ALLFINISH;
			}else 
			{  
				if( i != 0 )
					memcpy(&m_analybuffer, &m_analybuffer[i*BLOCK_SIZE], (iPackageCount -i) * BLOCK_SIZE );
				m_iRestPackageCount = iPackageCount -i;
				m_iPackageStatus = USB16BIT_RESTFFT;
				break;
			}
		}else
		{			
			PARAM *curParam =(PARAM*)pDataBuf;
			for( int j= 0;  j < PARAM_SUM_EACH_PACKAGE; j++, curParam ++)
			{
				if ((curParam->ArriveTime.Time1 == 0) && (curParam->ArriveTime.Time2 == 0))
					break;			

				FRAME_FLAG *pFrmFlag = (FRAME_FLAG *)curParam;
				if ((curParam->ChNo & 0xE000) == STATE_FLAG)
				{
					//״̬֡
					STPARAM_TYPE_0 *tempStParam = (STPARAM_TYPE_0 *)curParam;
					DWORD cardno = pFrmFlag->spec.card;
					// Added by mengl 2017-2-27;
					// purpose:���bug,���ϴ�������ȷ�����޸�
					//m_pChannels[0].m_bIsStreaming = tempStParam->Ch0_State;
					//m_pChannels[1].m_bIsStreaming = tempStParam->Ch1_State;
				}
				else if ((curParam->ChNo & 0xE000) == SYSTIME_FLAG)
				{
					//ʱ��֡
					//Param2CommonParam(&m_paramBuff[0], curParam);
					//m_paramFIFO.pushsingle(&m_paramBuff[0]);
				}
				else if ((curParam->ChNo & 0xE000) == EXPARA_FLAG)
				{
					if (m_dwDevStatus != USB_DEV_OPEN) continue;	
					//���֡
					DWORD cardno = pFrmFlag->spec.card;	
					curParam->ChNo = cardno + pFrmFlag->spec.ChOfCard;
					if (cardno > 2)
					{
						continue;
					}
					pDirve->m_exParamBuf[cardno * 4    ] = curParam->exparam[0];
					pDirve->m_exParamBuf[cardno * 4 + 1] = curParam->exparam[1];
					pDirve->m_exParamBuf[cardno * 4 + 2] = curParam->exparam[2];
					pDirve->m_exParamBuf[cardno * 4 + 3] = curParam->exparam[3];
					memset(&curParam->MaxAmp, 0, sizeof(PARAM) - sizeof(TIME) - sizeof(unsigned short));
					memcpy(curParam->exparam, pDirve->m_exParamBuf, sizeof(short) * 12);					
					Param2CommonParam(&m_paramBuff[0], curParam);
					m_paramBuff[0].DurationTimeus = m_paramBuff[0].ArrivingTimeus;
					m_paramBuff[0].RiseTimeus = m_paramBuff[0].ArrivingTimeus;
					m_paramBuff[0].ASL = 0;
					m_paramFIFO[(m_paramBuff[0].ChannelId-1)%CHANNEL_COUNT_PERCARD].pushsingle(&m_paramBuff[0]);
				}
				else
				{
					if (m_dwDevStatus != USB_DEV_OPEN) continue;	
					//��ͨ����֡
					DWORD chno = pFrmFlag->spec.card * CHANNEL_COUNT_PERCARD + pFrmFlag->spec.ChOfCard;

					// Edited by mengl 2017-7-5;
					// purpose:�˳�33ͨ������
					//if (chno >= MAX_CARDNUM*CHANNEL_COUNT_PERCARD)
					//{
					//	continue;
					//}
					if (pFrmFlag->spec.card != m_dwCardNo)
					{
						continue;
					}
		
					curParam->ChNo = (USHORT)chno;
					//if (m_bExParamEnable)
					{
						if (m_bFFTEnable)
						{
							memcpy(curParam->exparam, pDirve->m_exParamBuf, sizeof(short) * 5);
						}
						else
						{
							memcpy(curParam->exparam, pDirve->m_exParamBuf, sizeof(short) * 12);
						}
					}
					if(Param2CommonParam(&m_paramBuff[0], curParam))	
						m_paramFIFO[(m_paramBuff[0].ChannelId-1)%CHANNEL_COUNT_PERCARD].pushsingle(&m_paramBuff[0],FALSE);
					g_nParamCount++;
					// Edited by mengl 2016-11-25;
					// purpose:������������ע�͵�
					//if(CWAESystemConfigManager::GetInstance().GetParamFilter().FilterPara(&m_paramBuff[0]))
					//m_paramFIFO[(m_paramBuff[0].ChannelId+1)%2].pushsingle(&m_paramBuff[0]);
					//TRACE("CHNO:%d, ARRiVETIme: %llu\n",m_paramBuff[0].ChannelId, m_paramBuff[0].ArrivingTimens);
				}					   
			}
			i++; 
		}
	}
}
#endif




BOOL CHardWare_USB30_16Bit::Param2CommonParam(COMPARAMDATA* pComParam, PARAM* pParam)
{
	if( pComParam == NULL || pParam == NULL ) return FALSE;
	CWAEDrive_USB30_16Bit* pDirve = (CWAEDrive_USB30_16Bit*)m_pDriver;
	if( pDirve == NULL ) return  FALSE;

	pComParam->ChannelId = /*m_dwCardNo * m_iChanCount + 1 +*/ pParam->ChNo + 1;
	if( pComParam->ChannelId > CHSUM) 
	{
		return  FALSE;
	}
	double iIncrement = pow(10.f, m_pChannels[pParam->ChNo%CHANNEL_COUNT_PERCARD].m_iIncrementDB/20);

	float nVp = 10.0;
	switch(m_pChannels[pParam->ChNo%CHANNEL_COUNT_PERCARD].m_nGain)
	{
	case 0:
		nVp = 10.0;
		break;
	case 1:
		nVp = 5.0;
		break;
	case 2:
		nVp = 2.0;
		break;
	case 3:
		nVp = 1.0;
		break;
	case 4:
		nVp = 0.1;
		break;
	default:
		nVp = 10.0;
		break;
	}

	if(pParam->MaxAmp > 0 ) 
	{
		pComParam->Amp= (20*log10(nVp*pParam->MaxAmp/32768) + 120 - m_pChannels[pParam->ChNo%CHANNEL_COUNT_PERCARD].m_iIncrementDB);
	}else
	{
		pComParam->Amp = 0;
		//return  FALSE;
	}
	// Edited by mengl 2016-9-19
	// purpose: �޸�����,asl�ļ��㷽ʽ
	//pComParam->Enery= pParam->Energy*10*1000/(double)32768 *(1000.0/m_pChannels[0].m_dwSampleFreq) /iIncrement;

	pComParam->RingdownCount = pParam->AllRing;

	pComParam->RisingRingdownCount=pParam->riseRing;

	unsigned __int64 iCurDataTm; //��ǰ����ʱ��
	iCurDataTm = (((unsigned __int64) pParam->ArriveTime.Time2) << 32) + pParam->ArriveTime.Time1;
	unsigned __int64 tmpX = 0;
	unsigned __int64 x2,x4;
	tmpX = pParam->ArriveTime.Time2;
	x2= pParam->ArriveTime.Time1 | (tmpX << 32);

	x4=x2;
	pComParam->ArrivingTimens = x2*100;//ns
	pComParam->ArrivingTimeus = pComParam->ArrivingTimens/1000;//us  
	tmpX = pParam->endTime.Time2;
	x2= pParam->endTime.Time1 | (tmpX << 32);
	pComParam->DurationTimens = x2*100;//ns
	pComParam->DurationTimeus=pComParam->DurationTimens/1000;//us

	tmpX = pParam->maxTime.Time2;
	x2=pParam->maxTime.Time1 | (tmpX << 32);
	pComParam->RiseTimens =  x2*TIME_COUNTER;//ns
	pComParam->RiseTimeus = pComParam->RiseTimens/1000;//us
	unsigned __int64 curdiff0=x4*100;//����

	pComParam->nsInArrivingTime= curdiff0%1000000;//���ns
	GetArriveTime(&pComParam->ArrivingTimeST, &pDirve->GetSampleStartTime(), curdiff0);

	pComParam->usInArrivingTime = (DWORD)(curdiff0/1000);//���������ص�ʱ�䣬��λ��

	//if(pComParam->ArrivingTimens > pComParam->DurationTimens || pComParam->ArrivingTimens > pComParam->RiseTimens  )
	//	return FALSE;

	double  sampleSum;
	if( pComParam->DurationTimens == 0)
	{
		sampleSum = m_pChannels[pParam->ChNo%CHANNEL_COUNT_PERCARD].m_lParamInterval* m_pChannels[pParam->ChNo%CHANNEL_COUNT_PERCARD].m_dwSampleFreq/1000.0;
	}
	else
	{
		sampleSum = (pComParam->DurationTimens - pComParam->ArrivingTimens)*m_pChannels[pParam->ChNo%CHANNEL_COUNT_PERCARD].m_dwSampleFreq/1000000.0;
	}
	// Edited by mengl 2016-9-19
	// purpose: �޸�����,asl�ļ��㷽ʽ
	//if(sampleSum < 100)
	//	sampleSum = 1;
	//else
	//	sampleSum /= 100;

	//pComParam->RMS = sqrt((__int64) pParam->rms/ sampleSum)/32768*10/iIncrement * 1000;


	//pComParam->ASL = (double)pParam->Energy/sampleSum;
	//pComParam->ASL=(20*log10(10.0*pComParam->ASL/32768)+120-m_pChannels[pComParam->ChannelId%CHANNEL_COUNT_PERCARD].m_iIncrementDB);
	if( sampleSum < 1)
		sampleSum = 1;
	//ULONGLONG un = pParam->rms >>32 | ((pParam->rms & 0xffffffff) << 32);
	pComParam->RMS = sqrt(pParam->rms / sampleSum )*nVp/iIncrement/32767.0* 1000;	
	//��λpJ
	pComParam->Enery = pParam->rms/32768.0/32768.0*nVp*nVp /iIncrement/iIncrement/10/sampleSum*(pComParam->DurationTimens - pComParam->ArrivingTimens);

	pComParam->ASL = (double)pParam->Energy /sampleSum;
	pComParam->ASL=(20*log10(nVp*pComParam->ASL/32768)+120-m_pChannels[pParam->ChNo%CHANNEL_COUNT_PERCARD].m_iIncrementDB);

	for(int j = 0; j < 5/*PARAM_EXTERNAL_SUM*/; j ++)
	{
		pComParam->ExParam[j] = pParam->exparam[j] * 10.0/32768.0;         
	}
	if (m_bFFTEnable)
	{
		//���Ӷ�FFT�����Ĵ���
		pComParam->ExParam[5] = (USHORT)(pParam->exparam[5]);	//peak frequency
		pComParam->ExParam[6] = ((USHORT)pParam->exparam[6]) / 64.f;	//frequency centroid
		pComParam->ExParam[7] = ((USHORT)pParam->exparam[7]) * 100.f / 65535;	//partial pow[0]
		pComParam->ExParam[8] = ((USHORT)pParam->exparam[8]) * 100.f / 65535;	//partial pow[1]
		pComParam->ExParam[9] = ((USHORT)pParam->exparam[9]) * 100.f / 65535;	//partial pow[2]
		pComParam->ExParam[10] = ((USHORT)pParam->exparam[10]) * 100.f / 65535;	//partial pow[3]
		pComParam->ExParam[11] = ((USHORT)pParam->exparam[11]) * 100.f / 65535;	//partial pow[4]
		//end fft process
	}else
	{
		for(int j = 5; j < PARAM_EXTERNAL_SUM; j ++)
		{
			pComParam->ExParam[j] = pParam->exparam[j] * 10.0/32768.0;
		}
	}
	return TRUE;
	//pComParam->RMS = sqrt((__int64) pParam->rms/ sampleSum)/32768*10/iIncrement * 1000;

}





CWAEDrive_USB30_16Bit::CWAEDrive_USB30_16Bit()
{
	m_bIsCardOpened = FALSE;

	m_bInitialized = FALSE;
	m_bHardParam = FALSE;
	m_hWaveToHitSemaph = NULL;
	m_nParamType = 0;


	
	////���ݱ�������
	//m_strProject = _T("information:");
	//m_strSaveFileName = _T(""); //�ļ���
	//m_strPathName = _T("");    //·��
	m_dwFileSaveSize = 4000; //���洢��MB
	m_FileSaveSum = 2;    //�ļ�����
	m_bFileSaveCycle =  FALSE;		//�����ļ�ѭ���洢�Զ�����
	m_bParaFileCycleCover = FALSE;	//�����ļ�ѭ���洢�Զ�����
	m_WaveSwapSize = 0;         //
	m_bIsPrompt = TRUE;            //�Ƿ���ʾ��������
	m_bSmallFileMode = FALSE;        //С�ļ�ģʽ����ģʽ��ÿ50M�������ݱ���Ϊһ���ļ�	
	m_bIsSaveFile = TRUE;           //�Ƿ񱣴��������
	m_dwParamCount = 0; 
	m_pDataReadThread = NULL;
	//m_pSaveParamThread = NULL;
	//m_pSaveWaveThread = NULL;
	m_dwDriveType = USB16BIT;
	m_bHaveStream = FALSE;
}

CWAEDrive_USB30_16Bit::~CWAEDrive_USB30_16Bit()
{
	if (m_hWaveToHitSemaph)
	{
		CloseHandle(m_hWaveToHitSemaph);
		m_hWaveToHitSemaph = NULL;
	}
	ClearHardWare();
}


void CWAEDrive_USB30_16Bit::ClearHardWare()
{
	CHardWare_USB30_16Bit* pHardware = NULL;
	//TRACE("ClearHardWare Lock\n");
	::EnterCriticalSection(&m_csHardwareMapLock);		
	for (int i = 0; i< MAX_CARDNUM; i++)
	{	
		pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[i];
		if(pHardware)
		{
			m_HardWareArray[i] = NULL;
			delete pHardware;
			pHardware = NULL;
		}
	}
	::LeaveCriticalSection(&m_csHardwareMapLock);
	//TRACE("ClearHardWare Unlock\n");
}



// CWAEDrive_USB30_16Bit member functions

/*++
����:
	���Ĵ������������Ĵ����ȷ���10�ֽڵĶ�������յ�4�ֽڵĵ�����
	��дָ�� 0D 02 XX [DATA]
	  ��ָ�� [DATA]
����:
	__in  CardId - ����
	__in  addr   - �Ĵ�����ַ
	__out value  - ����ָ�룬��ȡ���Ĵ�����ֵ
����ֵ:
	VOID
--*/
void CWAEDrive_USB30_16Bit::ReadRegister(short CardId,UCHAR addr, UINT *value)
{
    
    UCHAR bufOutput[33];

	memset(&bufOutput,0,sizeof(bufOutput));	
	
	bufOutput[0] = 0x52;
	bufOutput[1] = 0;
	bufOutput[2] = addr;
	bufOutput[3] = 0;
    USBWriteEP(CardId,0x01,8,bufOutput);
	memset(&bufOutput,0,sizeof(bufOutput));	
	USBReadEP(CardId,0x81,4,bufOutput);

    *value = *(UINT *)&bufOutput[0];
}

/*++
����:
	д�Ĵ���������д�Ĵ���ÿ�η���33�ֽ����ݣ���һ�ֽ�ΪUSB�������ͣ��ڶ��ֽ�ΪFPGA�������ͣ������ֽ�Ϊ�Ĵ�����ַ
	����ͷΪ 0A 01 XX [DATA]
����:
	__in  CardId - ����
	__in  addr   - �Ĵ�����ַ
	__in  value  - ��д��Ĵ�����ֵ
����ֵ:
	VOID
--*/
void CWAEDrive_USB30_16Bit::WriteRegister(short CardId,UCHAR addr, UINT value)
{
	UCHAR bufOutput[33];

	memset(&bufOutput,0,sizeof(bufOutput));
	bufOutput[0] = 0x57 ;					// USB��������
	bufOutput[1]  = 0;					// FPGA��������
	bufOutput[2]  = addr;		        // �Ĵ�����ַ
	bufOutput[3] = 0;
	char *valuebuf =(char*)&value;
    
	//bufOutput[3] = valuebuf[3];
	bufOutput[4] = valuebuf[3];
	bufOutput[5] = valuebuf[2];
	bufOutput[6] = valuebuf[1];
	bufOutput[7] = valuebuf[0];
    USBWriteEP(CardId,0x01,8,bufOutput);	
}


DWORD CWAEDrive_USB30_16Bit::InitCards( BOOL bReset)
{
	if(m_bInitialized && !bReset)
		return 0;
	UINT uCardVer;
	uCardVer = 0;

	ClearHardWare();
//#define OLD_CODE
#ifdef OLD_CODE
	ZT_PCIBOARD zt;
	for(int i =0; i < MAX_CARDNUM; i++)
	{
		zt.lIndex = i;
		if(OpenUSB7kC(&zt) == 0)
		{
			//ʶ��PID&VID
			UINT vid;
			PID_STAT pid;

			ReadRegister(zt.nChNo, VID_REG, &vid);
			ReadRegister(zt.nChNo, PID_REG, (unsigned int *)&pid.cmd);
			if ((vid == SOUNDWEL_VID) && (pid.spec.pid == USB_HUB_16BIT_NEW_PID))
			{
				if( bReset )
				{
					UCHAR cmddata[8];	
					long totalTransferSize = 0;//sizeof(cmddata);
					cyusb_control_xfer_synch(zt.nChNo, 0,(PUCHAR)(&cmddata), &totalTransferSize,1000);
	
				}
				CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)AddHardWare(NULL, zt.nChNo);


				//CARD_FEATURE_STAT ftrst;
				//ftrst.cmd = 0;
				//ReadRegister(zt.nChNo, STAT_FEATURE_REG, (unsigned int*)&ftrst.cmd);

				//if (ftrst.sepc.ParamFeature)
				//{
				//	m_bHardParam = True;
				//}
				//else
				//{
				//	m_bHardParam = False;
				//}
				ReadRegister(zt.nChNo, FW_VER_REG, &pHardware->m_nVer_Card);
				pHardware->m_dwDevStatus = USB_DEV_INITIAL;

				UINT nDDRInit = 0;
				while (1)
				{
					ReadRegister(zt.nChNo, 0x24, &nDDRInit);
					if( (nDDRInit & 0x03) == 0x03)
						break;
				}

				//DDR�ڴ����
				WriteRegister(zt.nChNo, 0x19, 0x80008452);
				WriteRegister(zt.nChNo, 0x00, 0x00000008);

				DWORD timeout = GetTickCount();
				while(1)
				{
					ReadRegister(zt.nChNo, 0x26, &uCardVer);
					if(uCardVer & 0x80000000)
						break;
					if( GetTickCount() - timeout > 1000)
						break;
				}
				WriteRegister(zt.nChNo, 0x19, 0x00008452);
				WriteRegister(zt.nChNo, 0x00, 0x00000000);

				CloseUSB7kC(zt.nChNo);//���رտ��ƿ�;
			}

			//CloseUSB7kC(zt.nChNo);
		}
	}
#else
	ZT_USBBOARD zt;
	for(int i =0; i < MAX_CARDNUM; i++)
	{
		zt.Index = i;
		zt.USBDevice = NULL;

		if(OpenUSB7kC(&zt) == 0)
		{
			//ʶ��PID&VID
			UINT vid;
			PID_STAT pid;

			ReadRegister(zt.CardNo, VID_REG, &vid);
			ReadRegister(zt.CardNo, PID_REG, (unsigned int *)&pid.cmd);
			if ((vid == SOUNDWEL_VID) && (pid.spec.pid == USB_HUB_16BIT_NEW_PID))
			{
				if( /*FALSE*/bReset )
				{
					UCHAR cmddata[8];	
					long totalTransferSize = 4;//sizeof(cmddata);
					CYUSB_Control_Reset(zt.CardNo, 0,(PUCHAR)(&cmddata), &totalTransferSize,1000);
					Sleep(30);
				}
				CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)AddHardWare(NULL, zt.CardNo);


				//CARD_FEATURE_STAT ftrst;
				//ftrst.cmd = 0;
				//ReadRegister(zt.nChNo, STAT_FEATURE_REG, (unsigned int*)&ftrst.cmd);

				//if (ftrst.sepc.ParamFeature)
				//{
				//	m_bHardParam = True;
				//}
				//else
				//{
				//	m_bHardParam = False;
				//}
				ReadRegister(zt.CardNo, FW_VER_REG, &pHardware->m_nVer_Card);
				pHardware->m_dwDevStatus = USB_DEV_OPEN;

				UINT nDDRInit = 0;
				DWORD timeout = GetTickCount();
				while (1)
				{
					ReadRegister(zt.CardNo, 0x2C, &nDDRInit);
					if( (nDDRInit & 0x03) == 0x03)
						break;
					if( GetTickCount() - timeout > 1000)
						break;
				}

				////DDR�ڴ����
				//WriteRegister(zt.CardNo, 0x19, 0x80008452);
				//WriteRegister(zt.CardNo, 0x00, 0x00000008);

				//timeout = GetTickCount();
				//while(1)
				//{
				//	ReadRegister(zt.CardNo, 0x26, &uCardVer);
				//	if(uCardVer & 0x80000000)
				//		break;
				//	if( GetTickCount() - timeout > 1000)
				//		break;
				//}
				//WriteRegister(zt.CardNo, 0x19, 0x00008452);
				//WriteRegister(zt.CardNo, 0x00, 0x00000000);

				////CloseUSB7kC(zt.CardNo);//���رտ��ƿ�;
			}

			//CloseUSB7kC(zt.nChNo);
		}
	}
#endif

	//ddr test
	CHardWare_USB30_16Bit* pHardware = NULL;
	::EnterCriticalSection(&m_csHardwareMapLock);	
	for (int i = 0; i< MAX_CARDNUM; i++)
	{	
		pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[i];
		if(pHardware)
		{
			WriteRegister(pHardware->m_dwCardNo, 0x19, 0x80008452);
			WriteRegister(pHardware->m_dwCardNo, 0x00, 0x00000008);
		}
	}
	for (int i = 0; i< MAX_CARDNUM; i++)
	{	
		pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[i];
		if(pHardware)
		{
			DWORD timeout = GetTickCount();
			while(1)
			{
				ReadRegister(pHardware->m_dwCardNo, 0x26, &uCardVer);
				if(uCardVer & 0x80000000)
					break;
				if( GetTickCount() - timeout > 1000)
					break;
			}
			WriteRegister(pHardware->m_dwCardNo, 0x19, 0x00008452);
			WriteRegister(pHardware->m_dwCardNo, 0x00, 0x00000000);
		}
	}
	::LeaveCriticalSection(&m_csHardwareMapLock);


	if ((!m_bHardParam) && (!m_hWaveToHitSemaph))
	{
		m_hWaveToHitSemaph = CreateSemaphore(NULL, 1, 1, NULL);
	}

	m_bInitialized = TRUE;
	
	int iCount = 0;
	//CHardWare_USB30_16Bit* pHardware = NULL;
	//TRACE("InitCards Lock\n");
	::EnterCriticalSection(&m_csHardwareMapLock);	
	for (int i = 0; i< MAX_CARDNUM; i++)
	{	
		pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[i];
		if(pHardware)
		{
			iCount++;
		}
	}
	::LeaveCriticalSection(&m_csHardwareMapLock);
	//TRACE("InitCards Unlock\n");
	return iCount;
}
void CWAEDrive_USB30_16Bit::OpenAllCard(BOOL *bDeviceFlag, DWORD dwSampleLength, BOOL bReset/* = TRUE*/)
{
	UCHAR bufOutput[32];
	DWORD dwOpenSum = 0;
	UINT regvalue=0;	
	if(m_bIsCardOpened && bReset)
	{
		CloseAllCard();
		ClearHardWare();
		m_bIsCardOpened = FALSE;
		m_bInitialized = FALSE;
	}
	m_bIsCardOpened = TRUE;
	if( !m_bInitialized )
	{	
		InitCards(FALSE);
		//����Ӳ������
	}
	CHardWare_USB30_16Bit* pHardware = NULL;
	//TRACE("OpenAllCard lock\n");
	::EnterCriticalSection(&m_csHardwareMapLock);
	for (int j = 0; j< MAX_CARDNUM; j++)
	{	
		pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[j];
		if(pHardware)
		{
			int i = pHardware->m_dwCardNo;
			if( bDeviceFlag[i] && OpenUSB7kC_ByCardNo(i) == 0 )
			{
				//if (bReset)
				//{
				//	bufOutput[0] = 11 ;				//RST_FPGA
				//	USBWriteEP(i,0,8,bufOutput);
				//	bufOutput[0] = 12 ;
				//	USBWriteEP(i,0,8,bufOutput);
				//	//reset fifo
				//	bufOutput[0] = 3 ;
				//	USBWriteEP(i,0,8,bufOutput);
				//}
				//����ȫ�ֳɰ����ԼĴ���
				GLB_PKG_PROP PkgCfg;
				PkgCfg.cmd = 0;
				PkgCfg.spec.ver = pHardware->m_nPackVer;
				WriteRegister(i, PROP_GLB_REG_BASEADDR + PROP_GLB_PKG_REG, PkgCfg.cmd);

				//����ȫ�ֳ�֡���ԼĴ���			
				GLB_FRM_PORP FrmCfg;
				FrmCfg.cmd = 0;
				FrmCfg.spec.TimeFrmEncode = m_nParamType;
				FrmCfg.spec.HitFrmEncode = m_nParamType;
				FrmCfg.spec.WaveFrmEncode = pHardware->m_nFrmEncodeType; //FrmEncodeType[i];
				FrmCfg.spec.ver = pHardware->m_nFrmVer;
				WriteRegister(i, PROP_GLB_REG_BASEADDR + PROP_GLB_FRM_REG, FrmCfg.cmd);
				//����ȫ��DPCM�������ԼĴ���
				GLB_DPCM_PROP RegVal;
				RegVal.cmd = 0;
				RegVal.spec.bits = pHardware->m_nFrmDpcmBits;//FrmDpcmBits[i];
				WriteRegister(i, PROP_GLB_REG_BASEADDR + PROP_GLB_DPCM_REG, RegVal.cmd);
				pHardware->m_dwDevStatus = USB_DEV_OPEN;
				if (bReset)
				{
					for (int k = 0; k < CHANNEL_COUNT_PERCARD; k++ )
					{
						pHardware->m_pChannels[k].m_bIsStreaming =FALSE;
					}
					//pHardware->m_pChannels[0].m_bIsStreaming =FALSE;
					//pHardware->m_pChannels[1].m_bIsStreaming =FALSE;
				}
				//pHardware->m_pChannels[0].m_dwSampleLength =dwSampleLength;
				//pHardware->m_pChannels[1].m_dwSampleLength =dwSampleLength;
				//SetCardEnableWaveformParam(i, 3, 3);

			}else
			{
				pHardware->m_dwDevStatus = USB_DEV_CLOSE;
			}

			//pHardware->m_dwExParamFixTime = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_dwExParamFixTime;
			//pHardware->m_bExParamEnable = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_bExParamEnable;

			//pHardware->m_bFFTEnable = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_bFFTEnable;
			//pHardware->m_iFftWinType = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_iFftWinType;
			//pHardware->m_iFftParaTrigType = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_iFftParaTrigType;
			//pHardware->m_iFftParaTrigPara = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_iFftParaTrigPara;
			//pHardware->m_iFftWaveDataType = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_iFftWaveDataType;
			//pHardware->m_iFftWaveTrigType = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_iFftWaveTrigType;
			//pHardware->m_iFftWaveTrigPara = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_iFftWaveTrigPara;
			//pHardware->m_iFftTotalPowerFrom = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_iFftTotalPowerFrom;
			//pHardware->m_iFftTotalPowerTo = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_iFftTotalPowerTo;
			//pHardware->m_dwFftRamSize = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_dwFftRamSize;
			//pHardware->m_dwFftLen = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_dwFftLen;
			//pHardware->m_dwFftDecimateRate = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_dwFftDecimateRate;
			//pHardware->m_dwFftWorkMode = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_dwFftWorkMode;
			//for (int k = 0; k < MAX_FFT_PART_POWER_NUM; k++ )
			//{
			//	pHardware->m_bFftPartPowerEnables[k] = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_bFftPartPowerEnables[k];
			//	pHardware->m_iFftPartPowerFroms[k] = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_iFftPartPowerFroms[k];
			//	pHardware->m_iFftPartPowerTos[k] = CWAESystemConfigManager::GetInstance().m_ExParamInfo.m_iFftPartPowerTos[k];

			//}
		}
	}
	::LeaveCriticalSection(&m_csHardwareMapLock);	
	//TRACE("OpenAllCard unlock\n");
}
void CWAEDrive_USB30_16Bit::CloseAllCard()
{
	if( !m_bInitialized )
		return;

	CHardWare_USB30_16Bit* pHardware = NULL;
	//TRACE("CloseAllCard lock\n");
	::EnterCriticalSection(&m_csHardwareMapLock);
	for (int j = 0; j< MAX_CARDNUM; j++)
	{	
		pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[j];
		if( pHardware && pHardware->m_dwDevStatus == USB_DEV_OPEN )
		{
			CloseUSB7kC((short)pHardware->m_dwCardNo);
			pHardware->m_dwDevStatus = USB_DEV_CLOSE;
		}
	}
	::LeaveCriticalSection(&m_csHardwareMapLock);
	//TRACE("CloseAllCard unlock\n");
	m_bIsCardOpened = FALSE;
	//m_bInitialized = FALSE;
}



const double max_adc_val = 0x7fff;//32767;

BOOL CWAEDrive_USB30_16Bit::StartSample()
{	
	if( m_dwSampleStatus == SAMPLEING)
		return TRUE;
	CWAEDrive::StartSample();
	//TRACE("StartSample  start\n");
	
	//BOOL bRet = CWAEDataFileManager::GetInstance().SetDataFilePathName(CWAESystemConfigManager::GetInstance().m_strDataFilePath,
	//	CWAESystemConfigManager::GetInstance().m_strDataFileName/* + CWAESystemConfigManager::GetInstance().m_strDataFileLabel*/);
	//TRACE("SetDataFilePathName  end\n");
	//if( !bRet )
	//{		
	//	AfxMessageBox(LoadStringFromId(IDS_CREATEFILE_FAILED));
	//	return FALSE;
	//}
	DWORD nTickCount = GetTickCount();

	//CHardWare_USB30_16Bit* pHardware = NULL;
	//m_bHaveStream = FALSE;
	//BOOL OpenFlag[MAX_CARDNUM];
	//memset(OpenFlag, 0, sizeof(BOOL)*MAX_CARDNUM);
	//for(int i = 0; i < MAX_CARDNUM; i++)
	//{
	//	pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[i];
	//	if( pHardware )
	//	{
	//		OpenFlag[i] = FALSE;
	//		for (int j = 0; j < CHANNEL_COUNT_PERCARD; j++)
	//		{
	//			if(pHardware->m_pChannels[j].m_bWaveEnable || pHardware->m_pChannels[j].m_bParamEnable)
	//				OpenFlag[i] = TRUE;
	//			if( pHardware->m_pChannels[j].m_bIsStreaming )
	//				m_bHaveStream = TRUE;
	//		}
	//	}
	//}
	//OpenAllCard(OpenFlag, 2048, FALSE);
	//double dFFTWinCoef[FFT_CALC_LEN];
	//double dFFTGain;

	//::EnterCriticalSection(&m_csHardwareMapLock);
	//for (int t = 0; t< MAX_CARDNUM; t++)
	//{	
	//	pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[t];
	//	if( pHardware && pHardware->m_dwDevStatus == USB_DEV_OPEN )
	//	{
	//		WindowFunction(dFFTWinCoef, pHardware->m_iFftWinType, FFT_CALC_LEN, &dFFTGain);

	//		WORD wEnableWave = 0;
	//		WORD wEnableParam = 0;
	//		USHORT chFilter[CHANNEL_COUNT_PERCARD]; 
	//		for (int j = 0; j < pHardware->m_iChanCount; j++)
	//		{
	//			double dTemp;
	//			DWORD dwValue;
	//			int nThreadSholdPlus = 0;		
	//			switch(pHardware->m_pChannels[j].m_nGain)
	//			{
	//			case 0:
	//				nThreadSholdPlus = 0;
	//				break;
	//			case 1:
	//				nThreadSholdPlus = 6;
	//				break;
	//			case 2:
	//				nThreadSholdPlus = 14;
	//				break;
	//			case 3:
	//				nThreadSholdPlus = 20;
	//				break;
	//			case 4:
	//				nThreadSholdPlus = 40;
	//				break;
	//			default:
	//				nThreadSholdPlus = 0;
	//				break;
	//			}
	//			dTemp = pHardware->m_pChannels[j].m_iParamThreashold + nThreadSholdPlus;
	//			dwValue = (DWORD) (pow((double)10.0,(double)(dTemp +
	//				pHardware->m_pChannels[j].m_iIncrementDB-120.0)/(double)20)*max_adc_val/10.0);//DB_10VTO2V;
	//			//����
	//			if(dwValue < 1)
	//				dTemp = 0;
	//			else
	//				dTemp = 20 * log10(dwValue * 10.0 / max_adc_val) - pHardware->m_pChannels[j].m_iIncrementDB + 120.0;

	//			if (dTemp < pHardware->m_pChannels[j].m_iParamThreashold + nThreadSholdPlus)
	//			{
	//				dwValue++;
	//			}
	//			if(dwValue > max_adc_val)
	//				dwValue = (DWORD)max_adc_val;

	//			SetCardParamThreshold(short(pHardware->m_dwCardNo * pHardware->m_iChanCount + j), dwValue);
	//			//ǰ�ŵ�Դ
	//			WriteRegister(pHardware->m_dwCardNo, g_ChRegBaseAddrs[j] + PROP_CH_FRONT_POWER, 1<< pHardware->m_pChannels[j].m_nFrontPower);
	//			SetSampleMode(short(pHardware->m_dwCardNo * pHardware->m_iChanCount + j), pHardware->m_pChannels[j].m_nWaveMode, pHardware->m_pChannels[j].m_dwPreSampleLength, pHardware->m_pChannels[j].m_bIsStreaming);
	//			SetChStreamingMode(short(pHardware->m_dwCardNo * pHardware->m_iChanCount + j), pHardware->m_pChannels[j].m_bIsStreaming , 0);
	//			dTemp = pHardware->m_pChannels[j].m_iSampleThreshold + nThreadSholdPlus;
	//			dwValue = (DWORD)(pow((double)10.0,(double)(dTemp +
	//				pHardware->m_pChannels[j].m_iIncrementDB-120.0)/(double)20)*max_adc_val/10.0);//DB_10VTO2V;
	//			//����
	//			dTemp = 20 * log10(dwValue * 10.0 / max_adc_val) - pHardware->m_pChannels[j].m_iIncrementDB + 120.0;

	//			if (dTemp < pHardware->m_pChannels[j].m_iSampleThreshold + nThreadSholdPlus)
	//			{
	//				dwValue++;
	//			}
	//			if(dwValue > max_adc_val)
	//				dwValue = (DWORD)max_adc_val;

	//			SetCardSampleThreshold(short(pHardware->m_dwCardNo * pHardware->m_iChanCount + j), dwValue);
	//			SetExparamFixed(short(pHardware->m_dwCardNo * pHardware->m_iChanCount + j), pHardware->m_dwExParamFixTime);
	//			
	//			if ((pHardware->m_iFftWinType > enFFTWinRect) && (pHardware->m_iFftWinType < enFFTWinFuncSum))
	//			{
	//				SetChFFTWindowFunction(short(pHardware->m_dwCardNo * pHardware->m_iChanCount + j), TRUE, dFFTWinCoef, FFT_CALC_LEN);
	//			}				

	//			SetChFFTResultScale(short(pHardware->m_dwCardNo * pHardware->m_iChanCount + j), dFFTGain);
	//			SetChFFTDecimateRate(short(pHardware->m_dwCardNo * pHardware->m_iChanCount + j), pHardware->m_dwFftDecimateRate);
	//
	//			for (int k = 0; k < 5; k++)	//��ʱ����
	//			{
	//				if (pHardware->m_bFftPartPowerEnables[k]) 
	//				{
	//					int tmpFFTMaxSampleFreq = pHardware->m_pChannels[j].m_dwSampleFreq / (2 * pHardware->m_dwFftDecimateRate);
	//					if (pHardware->m_iFftPartPowerFroms[k] >= tmpFFTMaxSampleFreq)
	//					{
	//						SetChFFTPartialPowerSegment(short(pHardware->m_dwCardNo * pHardware->m_iChanCount + j), k, 0, 0);	//����Ϊ��Ч
	//					}
	//					else if (pHardware->m_iFftPartPowerTos[k] > tmpFFTMaxSampleFreq)
	//					{
	//						SetChFFTPartialPowerSegment(short(pHardware->m_dwCardNo * pHardware->m_iChanCount + j), k, 	
	//							max (0, pHardware->m_iFftPartPowerFroms[k] * 511 / tmpFFTMaxSampleFreq), 511);
	//					}
	//					else
	//					{
	//						SetChFFTPartialPowerSegment(short(pHardware->m_dwCardNo * pHardware->m_iChanCount + j), k, 
	//							max (0, pHardware->m_iFftPartPowerFroms[k] * 511 / tmpFFTMaxSampleFreq),
	//							max (0, pHardware->m_iFftPartPowerTos[k] * 511 / tmpFFTMaxSampleFreq ));
	//					}
	//					continue;
	//				}
	//				SetChFFTPartialPowerSegment(short(pHardware->m_dwCardNo * pHardware->m_iChanCount + j), k, 0, 0);	//����Ϊ��Ч
	//			}
	//			
	//			chFilter[j] = pHardware->m_pChannels[j].m_nFilterHigh << 8; 
	//			chFilter[j] += pHardware->m_pChannels[j].m_nFilterLow;

	//			SetFilterGain(short(pHardware->m_dwCardNo * pHardware->m_iChanCount + j), chFilter[j], pHardware->m_pChannels[j].m_nGain );
	//			if(pHardware->m_pChannels[j].m_bWaveEnable)//����
	//				wEnableWave |= (1 << j);
	//			if(pHardware->m_pChannels[j].m_bParamEnable)//����
	//				wEnableParam |= (1 << j);	

	//		}

	//		if ((pHardware->m_iFftWinType > enFFTWinRect) && (pHardware->m_iFftWinType < enFFTWinFuncSum))
	//		{
	//			SetFFTWorkMode((short)pHardware->m_dwCardNo, pHardware->m_dwFftWorkMode & (~AE_FFT_CFG_RECT_WIN_EN0) & (~AE_FFT_CFG_RECT_WIN_EN1));
	//		}
	//		else
	//		{
	//			SetFFTWorkMode((short)pHardware->m_dwCardNo, pHardware->m_dwFftWorkMode | AE_FFT_CFG_RECT_WIN_EN0 | AE_FFT_CFG_RECT_WIN_EN1);
	//		}
	//		double tmp1 = pHardware->m_iFftWaveTrigPara;
	//		long tempFFTWaveTrig =
	//			pow((double)10.0,(double)(tmp1 +
	//			pHardware->m_pChannels[0].m_iIncrementDB-120.0 + 0.1)/(double)20)*max_adc_val/10.0 + 0.5;//DB_10VTO2V;

	//		//����
	//		double tmp2 = 20 * log10(tempFFTWaveTrig * 10.0 / max_adc_val) - pHardware->m_pChannels[0].m_iIncrementDB + 120.0;
	//		if (tmp2 < tmp1)
	//		{
	//			tempFFTWaveTrig++;
	//		}
	//		if(tempFFTWaveTrig > max_adc_val)
	//			tempFFTWaveTrig = max_adc_val;
	//		SetFFTWaveTrigPara((short)pHardware->m_dwCardNo,tempFFTWaveTrig);

	//		SetCardEnableWaveformParam((short)pHardware->m_dwCardNo, wEnableWave, wEnableParam);
	//		if( pHardware->m_pChannels[0].m_bIsStreaming || pHardware->m_pChannels[1].m_bIsStreaming)
	//		{
	//			SetCardSampleLength((short)pHardware->m_dwCardNo, USB30POINTCOUNT);
	//			pHardware->SetSampleLength(pHardware->m_pChannels[0].m_dwSampleLength);
	//		}else
	//		{
	//			SetCardSampleLength((short)pHardware->m_dwCardNo, pHardware->m_pChannels[0].m_dwSampleLength);
	//			pHardware->SetSampleLength(pHardware->m_pChannels[0].m_dwSampleLength);
	//		}

	//		SetCardSampleFreq((short)pHardware->m_dwCardNo, (short)(250000/pHardware->m_pChannels[0].m_dwSampleFreq));

	//		SetCardFilterGain((short)pHardware->m_dwCardNo, chFilter[0], pHardware->m_pChannels[0].m_nGain, chFilter[1],  pHardware->m_pChannels[1].m_nGain);

	//		SetCardParamEventInterval((short)pHardware->m_dwCardNo, pHardware->m_pChannels[0].m_lParamInterval * pHardware->m_pChannels[0].m_dwSampleFreq /1000);
	//		SetCardParamEventLockOut((short)pHardware->m_dwCardNo, pHardware->m_pChannels[0].m_lParamLockOut* pHardware->m_pChannels[0].m_dwSampleFreq /1000);
	//		SetCardParamEventPdt((short)pHardware->m_dwCardNo, pHardware->m_pChannels[0].m_dwParamPDT* pHardware->m_pChannels[0].m_dwSampleFreq /1000);
	//		SetCardSelectLight((short)pHardware->m_dwCardNo, 0);

	//		if( pHardware->m_bExParamEnable)
	//			SetExparamAttri((short)pHardware->m_dwCardNo, 0xffff0101);
	//		else
	//			SetExparamAttri((short)pHardware->m_dwCardNo, 0);
	//		

	//		//���������˲���ϵ��	
	//		firls_Initialize(FIR_ORDER, pHardware->m_pChannels[0].m_nDigFilterType);
	//		int err;
	//		double *pFirCoef = NULL;
	//		if (pHardware->m_pChannels[0].m_nDigFilterType == enDigFilterLowPass)
	//		{
	//			pFirCoef = firls_Calculate(FIR_ORDER,
	//				pHardware->m_pChannels[0].m_nDigFilterType,
	//				pHardware->m_pChannels[0].m_dwDigFilterHigh * 1000,
	//				pHardware->m_pChannels[0].m_dwDigFilterHigh * 1000,
	//				0,
	//				0,
	//				pHardware->m_pChannels[0].m_dwSampleFreq*1000,
	//				err);
	//		}
	//		else if (pHardware->m_pChannels[0].m_nDigFilterType == enDigFilterHighPass)
	//		{
	//			pFirCoef = firls_Calculate(FIR_ORDER,
	//				pHardware->m_pChannels[0].m_nDigFilterType,
	//				pHardware->m_pChannels[0].m_dwDigFilterLow * 1000,
	//				pHardware->m_pChannels[0].m_dwDigFilterLow * 1000,
	//				0,
	//				0,
	//				pHardware->m_pChannels[0].m_dwSampleFreq*1000,
	//				err);
	//		}
	//		else if ((pHardware->m_pChannels[0].m_nDigFilterType == enDigFilterBandPass) || (pHardware->m_pChannels[0].m_nDigFilterType == enDigFilterBandStop))
	//		{
	//			pFirCoef = firls_Calculate(FIR_ORDER,
	//				pHardware->m_pChannels[0].m_nDigFilterType,
	//				pHardware->m_pChannels[0].m_dwDigFilterLow * 1000,
	//				pHardware->m_pChannels[0].m_dwDigFilterLow * 1000,
	//				pHardware->m_pChannels[0].m_dwDigFilterHigh * 1000,
	//				pHardware->m_pChannels[0].m_dwDigFilterHigh * 1000,
	//				pHardware->m_pChannels[0].m_dwSampleFreq*1000,
	//				err);
	//		}

	//		//���������˲���
	//		if (((pHardware->m_pChannels[0].m_nDigFilterType == enDigFilterHighPass) ||
	//			(pHardware->m_pChannels[0].m_nDigFilterType == enDigFilterLowPass) || 
	//			(pHardware->m_pChannels[0].m_nDigFilterType == enDigFilterBandPass) ||
	//			(pHardware->m_pChannels[0].m_nDigFilterType == enDigFilterBandStop))
	//			)
	//		{
	//			SetFirFilter((short)pHardware->m_dwCardNo, pFirCoef, FIR_ORDER);
	//		}
	//		else
	//		{
	//			DisableFirFilter((short)pHardware->m_dwCardNo);			
	//		}
	//		//����FIR�˲���ϵ��
	//		firls_Terminated();
	//	}	

	//}
	//::LeaveCriticalSection(&m_csHardwareMapLock);

	UCHAR bufOutput;

	CH_AD_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.DcOffsetEn = 1;
	RegVal.spec.run = 1;

	char tempStr[12];
	int k = 0;
	CHardWare_USB30_16Bit* pHardware = NULL;
	::EnterCriticalSection(&m_csHardwareMapLock);
	for (int t = 0; t< MAX_CARDNUM; t++)
	{
		pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[t];
		if( pHardware && pHardware->m_dwDevStatus == USB_DEV_OPEN )
		{
			int i = pHardware->m_dwCardNo;
			bufOutput = 3 ;
			//sprintf_s(tempStr, "CardEvent%u", i);
			//pHardware->m_hDataEvent = CreateEvent(NULL, TRUE, FALSE, tempStr);
			//pHardware->m_ovReadData.hEvent = pHardware->m_hDataEvent;

			for (int j = 0; j < pHardware->m_iChanCount; j++)
			{
				//���� cfg_ad_ch0   (�������� ֱ��ƫ��)
				WriteRegister(i, g_ChRegBaseAddrs[j] + PROP_CH_AD_REG, RegVal.cmd);
			}
		}
	}
	::LeaveCriticalSection(&m_csHardwareMapLock);

	if( !StartThread( THREAD_DATA ) )
		return FALSE;
	if( !StartThread( THREAD_PARAM ) )
		return FALSE;
	if( !StartThread( THREAD_WAVE ) )
		return FALSE;

	//�ȴ�������ɣ�αusb3.0��Ҫ
	Sleep(300);

	////start AD
	UCHAR bufOutput1[8];
	bufOutput1[0] = 0x57;
	bufOutput1[1] = 0x00;//��ʼ1,�ر���0;
	bufOutput1[2] = 0x00;
	bufOutput1[3] = 0x00;
	bufOutput1[4] = 0xFF;
	bufOutput1[5] = 0xFF;//��ʼ1,�ر���0;
	bufOutput1[6] = 0xFF;
	bufOutput1[7] = 0xFF;
	USBWriteEP(MAX_CARDNUM, 0x02, 8, bufOutput1);
	

	::EnterCriticalSection(&m_csHardwareMapLock);
	for (int t = 0; t< MAX_CARDNUM; t++)
	{
		pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[t];
		if( pHardware && pHardware->m_dwDevStatus == USB_DEV_OPEN  && (pHardware->m_pChannels[0].m_bIsStreaming || pHardware->m_pChannels[1].m_bIsStreaming))
		{
			GLB_STREAM_CTRL_CMD StrmVal;
			StrmVal.cmd = 0;
			StrmVal.spec.InterTrig = 1;
			WriteRegister((short)pHardware->m_dwCardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_STREAM_CTRL_REG, StrmVal.cmd);
		}
	}
	::LeaveCriticalSection(&m_csHardwareMapLock);
	//TRACE("StartSample2 unlock\n");

	GetLocalTime(&m_SampleStartTime);
	m_dwSampleStatus = SAMPLEING;
	return TRUE;
}
void CWAEDrive_USB30_16Bit::StopSample()
{
	CWAEDrive::StopSample();	

	////�ر�������������
	UCHAR bufOutput1[8];
	bufOutput1[0] = 0x57;
	bufOutput1[1] = 0x00;
	bufOutput1[2] = 0x02;
	bufOutput1[3] = 0x00;
	bufOutput1[4] = 0x00;
	bufOutput1[5] = 0x00;//����;
	bufOutput1[6] = 0x00;
	bufOutput1[7] = 0x00;

	USBWriteEP(MAX_CARDNUM, 0x02, 8, bufOutput1);

	//UCHAR bufOutput1[8];
	bufOutput1[0] = 0x57;
	bufOutput1[1] = 0x00;//��ʼ1,�ر���0;
	bufOutput1[2] = 0x00;
	bufOutput1[3] = 0x00;
	bufOutput1[4] = 0x00;
	bufOutput1[5] = 0x00;//��ʼ1,�ر���0;
	bufOutput1[6] = 0x00;
	bufOutput1[7] = 0x00;
	USBWriteEP(MAX_CARDNUM, 0x02, 8, bufOutput1);
	Sleep(250);
	StopThread( THREAD_DATA );

	StopThread( THREAD_PARAM );
	StopThread( THREAD_WAVE );

	CH_FUNC_PROP RegVal;
	RegVal.cmd = 0;	
	
	CHardWare_USB30_16Bit* pHardware = NULL;
	//TRACE("StopSample lock\n");
	::EnterCriticalSection(&m_csHardwareMapLock);
	for (int t = 0; t< MAX_CARDNUM-1; t++)
	{
		pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[t];
		if( pHardware && pHardware->m_dwDevStatus == USB_DEV_OPEN )
		{
			SetCardSample((USHORT)pHardware->m_dwCardNo, FALSE);
			CloseHandle(pHardware->m_hDataEvent);
			pHardware->m_hDataEvent	=	NULL;
	
			DisableFirFilter(pHardware->m_dwCardNo);
			for (int k = 0; k < CHANNEL_COUNT_PERCARD; k++)
			{
				WriteRegister(pHardware->m_dwCardNo, g_ChRegBaseAddrs[k] + PROP_CH_FUNCTION_REG, RegVal.cmd);
			}
			UCHAR cmddata[8];	
			long totalTransferSize = 4;//sizeof(cmddata);

#ifdef OLD_CODE
	cyusb_control_xfer_synch(pHardware->m_dwCardNo, 0,(PUCHAR)(&cmddata), &totalTransferSize,1000);
#else
	CYUSB_Control_Reset(pHardware->m_dwCardNo, 0,(PUCHAR)(&cmddata), &totalTransferSize,1000);
	Sleep(30);
#endif		
			

			pHardware->ClearBuffData();
		}
	}
	::LeaveCriticalSection(&m_csHardwareMapLock);
	m_dwSampleStatus = SAMPLESTOP;
	CloseAllCard();

}



BOOL  CWAEDrive_USB30_16Bit::SetCardInfo(DWORD dwInfoType, DWORD chanNo, _variant_t* value)
{
	return FALSE;
}
BOOL  CWAEDrive_USB30_16Bit::GetCardInfo(DWORD dwInfoType, DWORD chanNo, _variant_t* value)
{
	switch( dwInfoType )
	{
	case CARDINFO_CARDCOUNT:
		{
			CHardWare_USB30_16Bit* pHardware = NULL;
			int iCount = 0;
	    	::EnterCriticalSection(&m_csHardwareMapLock);
			for (int i = 0; i< MAX_CARDNUM; i++)
			{	
				pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[i];
				if(pHardware)		
					iCount++;				
			}
			::LeaveCriticalSection(&m_csHardwareMapLock);

			*value = iCount;
			return TRUE;
		}
		break;
	case CARDINFO_CHANNELCOUNT:
		{
			CHardWare_USB30_16Bit* pHardware = NULL;
			int iCount = 0;
		
			::EnterCriticalSection(&m_csHardwareMapLock);
			for (int i = 0; i< MAX_CARDNUM; i++)
			{	
				pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[i];
				if(pHardware)		
					iCount++;				
			}
			::LeaveCriticalSection(&m_csHardwareMapLock);

			*value = iCount * CHANNEL_COUNT_PERCARD;
			return TRUE;
		}
		break;
	case CARDINFO_FPGAVERSION:
		{
			UINT ver = 0;
			CHardWare_USB30_16Bit* pHardware = NULL;
			pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[chanNo];
		
			if( pHardware )
			{
				*value = pHardware->m_nVer_Card;
				return TRUE;
			}
			return FALSE;
		}
		break;
	case CARDINFO_WAVEFRAMELEN:
		{
			unsigned short	cardNo;

			cardNo = chanNo/CHANNEL_COUNT_PERCARD;
			chanNo = chanNo%CHANNEL_COUNT_PERCARD;
			UINT ver = 0;
			CHardWare_USB30_16Bit* pHardware = NULL;
			pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];

			if( pHardware )
			{
				*value = pHardware->m_pChannels[chanNo].m_dwSampleLength * 2 + 48;
				return TRUE;
			}
			return FALSE;
		}
		break;
	case CARDINFO_FPGAREG:
		{
			//CString str;
			//CString str1;
			//CHardWare_USB30_16Bit* pHardware = NULL;

			//for (int j = 0; j< MAX_CARDNUM; j++)
			//{	
			//	pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[j];
			//	if(pHardware)		
			//	{
			//		str.Format("CardNo:%2d \n", pHardware->m_dwCardNo);
			//		for (int i = 0; i < 0x80; i++)
			//		{
			//			CH_PDT_CFG_PROP RegVal;
			//			RegVal.cmd = 0;
			//			ReadRegister(pHardware->m_dwCardNo, i, (unsigned int *)&RegVal.cmd);

			//			str1.Format(" addr:%02X, value:%08X.  ", i, RegVal.cmd);
			//			str += str1;
			//			if( i % 3 == 0)
			//				str += "\n";
			//		}
			//		AfxMessageBox(str);
			//	}			
			//}

			break;
		}
	}
	return TRUE;
}

BOOL  CWAEDrive_USB30_16Bit::GetCardDriverVersion(DWORD CardNo, short *MajorVersion,short *MinorVersion,short *BuildVersion)
{
	//EZUSB_DRIVER_VERSION DriverVersion;
	//BOOL status = hardware.GetCardDriverVersion((short)CardNo,&DriverVersion);
	//if (status)
	//{
	//	*MajorVersion = DriverVersion.MajorVersion;
	//	*MinorVersion = DriverVersion.MinorVersion;
	//	*BuildVersion = DriverVersion.BuildVersion;
	//}

	return FALSE;
}

void  CWAEDrive_USB30_16Bit::ShowSettingDialog()
{
	//CWAESystemSetDlg_Usb30_16Bit *pPropSheet = new CWAESystemSetDlg_Usb30_16Bit(CMFCPropertySheet::PropSheetLook_OutlookBar, IDB_FILELARGE, 32);

	//pPropSheet->EnablePageHeader(FALSE);
	//pPropSheet->DoModal();

	//delete pPropSheet;
}
void  CWAEDrive_USB30_16Bit::ShowTestDialog()
{

}



BOOL CWAEDrive_USB30_16Bit::SetCardSample(unsigned short CardNo, BOOL bStatus)
{
	if(CardNo >= MAX_CARDNUM)
		return FALSE;

	CH_AD_PROP RegVal;

	for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		ReadRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_AD_REG, (unsigned int*)&RegVal.cmd);

		if(bStatus)
			RegVal.spec.run = 1;
		else
			RegVal.spec.run = 0;

		WriteRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_AD_REG, RegVal.cmd);
	}

	return TRUE;
}

BOOL CWAEDrive_USB30_16Bit::SetCardEnableWaveformParam(unsigned short CardNo, WORD EnableWavefrom, WORD EnableParam)
{
	if(CardNo >= MAX_CARDNUM )
		return FALSE;

	CH_FUNC_PROP RegVal;
	int i;
	BOOL bHardParam = TRUE;
	for (i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		ReadRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);

		if (EnableWavefrom & (1 << i))
		{
			RegVal.spec.ThresholdWaveEn = 1;
		}
		else
		{
			RegVal.spec.ThresholdWaveEn = 0;
		}

		if (EnableParam & (1 << i))
		{
			if (bHardParam)
			{
				RegVal.spec.ThresholdHitEn = 1;				
			}
			else
			{
				RegVal.spec.ThresholdHitEn = 0;	
			}
		}
		else
		{
			RegVal.spec.ThresholdHitEn = 0;	
		}

		RegVal.spec.AdEn = 1;
		WriteRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, RegVal.cmd);
	}

	return TRUE;
}


/*++
����:
	������Σ�������ȫ��������üĴ���
	��������
	FPGA�������Ƶ�ʹ�ʽΪ��80M/128/
����:
	__in  CardNo		   - ����
	__in  dwExparamAttri   - ��ֵ����16λ�忨ʱ��ֵ�����ڴ�����λ����
		����λ��0  - 3  ��Ƶϵ��;
				4  - 7  �������;
				9       ��ι���ʹ��λ��δ�ã�
				16 - 27 ���ͨ��ʹ�ܱ�־����12�����ͨ�����ڴ�ÿ�ſ���4�����ͨ��������3�ſ���;
����ֵ:
	��ȷ���� TRUE
	���󷵻� FALSE
--*/
BOOL CWAEDrive_USB30_16Bit::SetExparamAttri(unsigned short cardNo, DWORD dwExparamAttri)
{
	if(cardNo >= MAX_CARDNUM)
		return FALSE;
	GLB_EXPARAM_PROP RegVal;
	RegVal.spec.ExparamADC = dwExparamAttri & 0x0000FFFF;
	RegVal.spec.ExparamEn = dwExparamAttri>>16;
	RegVal.spec.ExparamGain = 1;//��������
	RegVal.spec.ExparamPDE = 1;//����
	if( RegVal.spec.ExparamEn )
		RegVal.spec.MasterChannel = 0xF;
	else
		RegVal.spec.MasterChannel = 0x0;
	switch(RegVal.spec.ExparamGain)
	{
	case 0:
		RegVal.spec.ExparamGain = 4;
		break;
	case 1 :
		RegVal.spec.ExparamGain = 2;
		break;
	case 2:
		RegVal.spec.ExparamGain = 8;
		break;
	case  3:
		RegVal.spec.ExparamGain = 1;
		break;
	default:
		break;
	}
	WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_EXPARAM_REG , RegVal.cmd);
	return TRUE;
}

/*++
����:
	������γ�ʱ���ԼĴ���
����:
	__in  chanNo      - ͨ����
	__in  outInterval - ��γ�ʱʱ��
����ֵ:
	��ȷ���� TRUE
	���󷵻� FALSE		
--*/
BOOL CWAEDrive_USB30_16Bit::SetExparamFixed(unsigned short chanNo, DWORD outInterval)
{
    unsigned short	cardNo;

	cardNo = chanNo/CHANNEL_COUNT_PERCARD;
	chanNo = chanNo%CHANNEL_COUNT_PERCARD;
	if(cardNo >= MAX_CARDNUM )
		return FALSE;
	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];
	if( pHardware == NULL ) return FALSE;
	pHardware->m_dwExParamFixTime = outInterval;
	
    //WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_EPFIXEDTIME_REG, (DWORD)(outInterval*1000000/12.5));
    WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_EPFIXEDTIME_REG, (DWORD)(outInterval*80000));

	return TRUE;
}
UINT CWAEDrive_USB30_16Bit::GetVersionConf(unsigned short cardNo)
{
	UINT ver = 0;
	CHardWare_USB30_16Bit* pHardware = NULL;
	pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];

	if( pHardware )
	{
		ver = pHardware->m_nVer_Card;	
	}
	return ver;
}

/*++
����:
	���ð忨ʱ��֡����ʱ������Ӳ����ÿ���̶�ʱ�䣬����һ��ʱ��֡
����:
	__in  CardNo   - ����
	__in  sysTimer - ʱ��֡�������(��λ��100ns)
����ֵ:
	��ȷ���� TRUE
	���󷵻� FALSE		
--*/
BOOL CWAEDrive_USB30_16Bit::EnableSysTimer(unsigned short cardNo, DWORD sysTimer)
{
	typedef union   //ϵͳʱ�����ԼĴ���cfg_glb_timescale��0x7��
	{
		U32 cmd;
		struct _PropGlbTimescaleSpec
		{
			U32 timeout : 31;           //��ʱʱ�䣨��λ��100ns��
			U32 EnTimebaseFrm : 1;      //�Ƿ�����ʱ��֡
		} spec;
	} GLB_TIMESCALE_PROP;


	if(cardNo >= MAX_CARDNUM)
		return FALSE;

    //sysTimer = 0;

    GLB_TIMESCALE_PROP RegVal;

    if (sysTimer > 0)
    {
        RegVal.spec.timeout = sysTimer;
        RegVal.spec.EnTimebaseFrm = 1;
    }
    else
    {
        RegVal.spec.EnTimebaseFrm = 0;
    }

    WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_TIMESCALE_REG, RegVal.cmd);

	return TRUE;
}
/*++
����:
	����ͨ������ģʽ
����:
	__in  chanNo    - ͨ����
	__in  mode      - ����ģʽ
					  SAMPLE_MODE_NORMAL    0
					  SAMPLE_MODE_PRE       1
					  SAMPLE_MODE_POST      2
	__in  SampleSum - ������ʱ����
����ֵ:
	��ȷ���� TRUE
	���󷵻� FALSE		
--*/
BOOL CWAEDrive_USB30_16Bit::SetSampleMode(unsigned short chanNo, int mode, int SampleSum, BOOL bIsStreaming)
{
    short	cardNo;
	cardNo = chanNo/CHANNEL_COUNT_PERCARD;
	chanNo = chanNo%CHANNEL_COUNT_PERCARD;
	if(cardNo >= MAX_CARDNUM )
		return FALSE;

	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];
	if( pHardware == NULL ) return FALSE;
	pHardware->m_pChannels[chanNo].m_nWaveMode = mode;
	pHardware->m_pChannels[chanNo].m_dwPreSampleLength = SampleSum;
	pHardware->m_pChannels[chanNo].m_bIsStreaming = bIsStreaming;

    CH_SAMP_MODE_PROP_U3H RegVal;

    ReadRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_SAMP_MODE_REG, (unsigned int*)&RegVal.cmd);
	RegVal.spec.TrigDelay = SampleSum;
	if(bIsStreaming )
		mode = 2;
    switch (mode)
    {
    case 1:    
		RegVal.spec.ManulTrigCaptureEn = 0; 
		RegVal.spec.TimerTrigCaptureEn = 0; 
		RegVal.spec.ExParamTrigCaptureEn = 0;
		RegVal.spec.ChannelTrigCaptureEn = 0;
		RegVal.spec.ParamWaveSyncEn = 0;    
		RegVal.spec.StreamCaptureEn = 0;    
		RegVal.spec.NormalCaptureEn = 0;    
		RegVal.spec.PreCaptureEn = 1;       
        break;
    case 2:
		RegVal.spec.ManulTrigCaptureEn = 0; 
		RegVal.spec.TimerTrigCaptureEn = 0; 
		RegVal.spec.ExParamTrigCaptureEn = 0;
		RegVal.spec.ChannelTrigCaptureEn = 0;
		RegVal.spec.ParamWaveSyncEn = 0;    
		RegVal.spec.StreamCaptureEn = 1;    
		RegVal.spec.NormalCaptureEn = 0;    
		RegVal.spec.PreCaptureEn = 0;       
        break;
    default:
		RegVal.spec.ManulTrigCaptureEn = 0; 
		RegVal.spec.TimerTrigCaptureEn = 0; 
		RegVal.spec.ExParamTrigCaptureEn = 0;
		RegVal.spec.ChannelTrigCaptureEn = 0;
		RegVal.spec.ParamWaveSyncEn = 0;    
		RegVal.spec.StreamCaptureEn = 0;    
		RegVal.spec.NormalCaptureEn = 1;    
		RegVal.spec.PreCaptureEn = 0;       
        break;
    }

    WriteRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_SAMP_MODE_REG, RegVal.cmd);
	return TRUE;
}



BOOL CWAEDrive_USB30_16Bit::SetFilterGain(unsigned short chanNo, unsigned short filter, unsigned short gain)
{
	short	cardNo;
	
	cardNo = chanNo/CHANNEL_COUNT_PERCARD;
	chanNo = chanNo%CHANNEL_COUNT_PERCARD;
	if(cardNo >= MAX_CARDNUM )
		return FALSE;

	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];
	if( pHardware == NULL ) return FALSE;


	UCHAR	bufOutput[33];
    UCHAR  m_ch_l,m_ch_h;

	m_ch_l = filter & 0x00FF;
	m_ch_h = filter >> 8;

	pHardware->m_pChannels[chanNo].m_nFilterHigh = m_ch_h;
	pHardware->m_pChannels[chanNo].m_nFilterLow = m_ch_l;
	pHardware->m_pChannels[chanNo].m_nGain = gain;

	UCHAR reg = 0x30 + 0x1c;
	switch(chanNo)
	{
	case 0:
		reg = 0x30 + 0x1c;
		break;
	case 1:
		reg = 0x50 + 0x1c;
		break;
	case 2:
		reg = 0x90 + 0x1c;
		break;
	case 3:
		reg = 0xB0 + 0x1c;
		break;
	default:
		break;
	}
	bufOutput[0] = 0x57;
	bufOutput[1] = 0;
	bufOutput[2] = reg;//1ͨ�� 0x50+ 0x1C;
    bufOutput[3] = 0;

	bufOutput[7] = 1 << m_ch_l;//low
	bufOutput[6] = 1 << m_ch_h;//high
	bufOutput[5] = (1 << gain) ;//gain
	bufOutput[4] = 0;							

	USBWriteEP(cardNo,0x01,8,bufOutput);	
	return TRUE;
}

BOOL CWAEDrive_USB30_16Bit::SetCardFilterGain(unsigned short CardNo, unsigned short ch0_filter, unsigned short ch0_gain,
											  unsigned short ch1_filter, unsigned short ch1_gain)
{
	UCHAR	bufOutput[33];
	short	cardNo = CardNo;
	UCHAR  m_ch_l,m_ch_h;
	
    unsigned short filter;
	unsigned short gain;
	
    if(CardNo >= MAX_CARDNUM)
        return FALSE;
	
	
	GLB_START_CMD CfgCmd;
    CfgCmd.cmd = 0;
    CfgCmd.spec.StartAnalog = 1;
	
    WriteRegister(cardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_START_REG, CfgCmd.cmd);

	//�ȴ�ֱ��ƫ���������
    GLB_AD_STAT AdStat;
	AdStat.cmd = 0;
	DWORD timeout = GetTickCount();
    while (1)
    {
        ReadRegister(cardNo, STAT_GLB_REG_BASEADDR + STAT_GLB_AD_REG, (unsigned int*)&AdStat.cmd);
        if (AdStat.spec.DcOffsetRdy)
        {
            break;
        }
		if( GetTickCount() - timeout > 1000)
			break;
    }

	return TRUE;
}



BOOL CWAEDrive_USB30_16Bit::SetCardPause(unsigned short CardNo, BOOL bStatus)
{
	if(CardNo >= MAX_CARDNUM)
		return FALSE;
	
	CH_FUNC_PROP RegVal;
	for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
    {
        ReadRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
        if(bStatus)
            RegVal.spec.AdEn = 0;  //������ͣ����    
        else
            RegVal.spec.AdEn = 1;  //ȡ����ͣ����
		
        WriteRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, RegVal.cmd);
    }

	static DWORD ExparaEnOld = 0;
	GLB_EXPARAM_PROP ExRegVal;
	ReadRegister(CardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_EXPARAM_REG, (unsigned int*)&ExRegVal.cmd);
	if (bStatus)
	{		
		ExparaEnOld = ExRegVal.spec.ExparamEn;
		ExRegVal.spec.ExparamEn = 0;
	}
	else
		ExRegVal.spec.ExparamEn = ExparaEnOld;
	WriteRegister(CardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_EXPARAM_REG , ExRegVal.cmd);

	return TRUE;

}

BOOL CWAEDrive_USB30_16Bit::SetCardSelectLight(unsigned short CardNo, WORD bSelect)
{
	return FALSE;
}

/*--------------------
Set Sameple length

Format for register : AE_SAMPLE_LENGTH_FREQ0
reg[31:8]   --> sample Length, unit byte
reg[7:0]    --> sample freq factor
             Actually sample Freq = 40M /(2 *(reg[7:0] + 1))
---------------------------*/
BOOL CWAEDrive_USB30_16Bit::SetCardSampleLength(unsigned short  cardNo, DWORD value)
{
	typedef union   //�����������ԼĴ�����ƫ�Ƶ�ַ0x6��
	{
		U32 cmd;
		struct _PropChSampLenSpec
		{
			U32 SampLen : 18;           //��������
			U32 reserved : 14;
		} spec;
	} CH_SAMPLEN_PROP;

	if(cardNo >= MAX_CARDNUM )
		return FALSE;

	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];
	if( pHardware == NULL ) return FALSE;
	
	pHardware->SetSampleLength(value);
	if( pHardware->m_pChannels[0].m_bIsStreaming)
		value = 252;

    CH_SAMPLEN_PROP RegVal;
    RegVal.cmd = 0;
    RegVal.spec.SampLen = value;

	if(cardNo >= MAX_CARDNUM )
		return FALSE;


    for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
    {
        WriteRegister(cardNo, g_ChRegBaseAddrs[i] + PROP_CH_SAMP_LEN_REG, RegVal.cmd);
    }

	return TRUE;
}

BOOL CWAEDrive_USB30_16Bit::GetCardSampleFreq(unsigned short CardNo, WORD *value)
{
    CH_SAMPRATE_PROP RegVal;
    RegVal.cmd = 0;
     
    if(CardNo >= MAX_CARDNUM )
        return FALSE;


    for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
    {
		
        RegVal.cmd = 0;
        ReadRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_SAMP_RATE_REG, (UINT*)&RegVal.cmd);
        
        if (RegVal.spec.SampRate == 0)
        {
            return FALSE;
        }
    }
    
    *value = RegVal.spec.SampRate;

    return TRUE;

}

/*--------------------
Set Sameple Freq

Format for register : AE_SAMPLE_LENGTH_FREQ0
reg[31:8]   --> sample Length, unit byte
reg[7:0]    --> sample freq factor
             Actually sample Freq = 40M /(2 *(reg[7:0] + 1))
---------------------------*/
BOOL CWAEDrive_USB30_16Bit::SetCardSampleFreq(unsigned short  CardNo, WORD value)
{


	if(CardNo >= MAX_CARDNUM )
		return FALSE;
	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[CardNo];
	if( pHardware == NULL ) return FALSE;	

	for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		pHardware->m_pChannels[i].m_dwSampleFreq = value;
	}
	CH_SAMPRATE_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.SampRate = (short)(250000/value);

	for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		WriteRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_SAMP_RATE_REG, RegVal.cmd);
	}

	return TRUE;
}



BOOL CWAEDrive_USB30_16Bit::SetCardParamEventInterval(unsigned short  CardNo, DWORD value)
{
	typedef union		//�����¼�������ԼĴ�����ƫ�Ƶ�ַ0xa��
	{
		U32 cmd;
		struct _PropChEveInterCfgSpec
		{
			U32 hdt : 32;
		}spec;
	}CH_EVEINTER_CFG_PROP;

	if(CardNo >= MAX_CARDNUM )
		return FALSE;

	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[CardNo];
	if( pHardware == NULL ) return FALSE;	

	for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		pHardware->m_pChannels[i].m_lParamInterval = value;
	}

	value = value * pHardware->m_pChannels[0].m_dwSampleFreq /1000;

	CH_EVEINTER_CFG_PROP RegVal;
	
	for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		RegVal.spec.hdt = value;
		WriteRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_EVENT_INTERVAL_REG, RegVal.cmd);
	}
	return TRUE;
}

BOOL CWAEDrive_USB30_16Bit::SetCardParamEventLockOut(unsigned short  CardNo, DWORD value)
{
	typedef union		//��������ʱ�����ԼĴ�����ƫ�Ƶ�ַ0xb��
	{
		U32 cmd;
		struct _PropChLockoutCfgSpec
		{
			U32 hlt : 32;
		}spec;
	}CH_LOCKOUT_CFG_PROP;

	if(CardNo >= MAX_CARDNUM )
		return FALSE;
	
	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[CardNo];
	if( pHardware == NULL ) return FALSE;	

	for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		pHardware->m_pChannels[i].m_lParamLockOut = value;
	}

	value = value * pHardware->m_pChannels[0].m_dwSampleFreq /1000;

	CH_LOCKOUT_CFG_PROP RegVal;
	int i;
	for (i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		RegVal.spec.hlt = value;
		WriteRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_LOCKOUT_CFG_REG, RegVal.cmd);
	}
	return TRUE;
}

BOOL CWAEDrive_USB30_16Bit::SetCardParamEventPdt(unsigned short CardNo, DWORD value)
{	
	if(CardNo >= MAX_CARDNUM )
	{
		return FALSE;
	}
	
	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[CardNo];
	if( pHardware == NULL ) return FALSE;	

	for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		pHardware->m_pChannels[i].m_dwParamPDT = value;
	}

	value = value * pHardware->m_pChannels[0].m_dwSampleFreq /1000;

	CH_PDT_CFG_PROP RegVal;
	int i;
	
	for (i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		RegVal.spec.pdt = value;
		WriteRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_PDT_REG, RegVal.cmd);
		
		RegVal.cmd = 0;
		ReadRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_PDT_REG, (unsigned int *)&RegVal.cmd);
	}
	
	return TRUE;
}

BOOL CWAEDrive_USB30_16Bit::SetCardGain(unsigned short chanNo, DWORD gain)
{
	short	cardNo;

	cardNo = chanNo/CHANNEL_COUNT_PERCARD;
	chanNo = chanNo%CHANNEL_COUNT_PERCARD;
	if(cardNo >= MAX_CARDNUM )
		return FALSE;

	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];
	if( pHardware == NULL ) return FALSE;
	pHardware->m_pChannels[chanNo].m_nGain = gain;
	return TRUE;
}

BOOL CWAEDrive_USB30_16Bit::SetIncrementDB(unsigned short cardNo, unsigned short value)
{

	if(cardNo >= MAX_CARDNUM )
		return FALSE;

	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];
	if( pHardware == NULL ) return FALSE;
	for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		pHardware->m_pChannels[i].m_iIncrementDB = value;
	}
	
	return TRUE;
}

BOOL CWAEDrive_USB30_16Bit::SetFrontPower(unsigned short chanNo, unsigned short value)
{
	short	cardNo;

	cardNo = chanNo/CHANNEL_COUNT_PERCARD;
	chanNo = chanNo%CHANNEL_COUNT_PERCARD;
	if(cardNo >= MAX_CARDNUM )
		return FALSE;

	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];
	if( pHardware == NULL ) return FALSE;
	pHardware->m_pChannels[chanNo].m_nFrontPower = value;

	//ǰ�ŵ�Դ
	WriteRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_FRONT_POWER, 1<< value);

	return TRUE;
}

BOOL CWAEDrive_USB30_16Bit::SetCardParamThreshold(unsigned short chanNo, DWORD value)
{
	typedef union   //ͨ�������������ԼĴ�����ƫ�Ƶ�ַ0x7��
	{
		U32 cmd;
		struct _PropChHitThresholdSpec
		{
			U32 threshold : 18;         //��������
			U32 reserved : 14;
		} spec;
	} CH_HIT_THRESHOLD_PROP;

	short	cardNo;
	cardNo = chanNo/CHANNEL_COUNT_PERCARD;
	chanNo = chanNo%CHANNEL_COUNT_PERCARD;
	if(cardNo >= MAX_CARDNUM )
		return FALSE;
	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];
	if( pHardware == NULL ) return FALSE;
	pHardware->m_pChannels[chanNo].m_iParamThreashold = value;

	double dTemp;
	DWORD dwValue;
	int nThreadSholdPlus = 0;	
	int j = chanNo;
	switch(pHardware->m_pChannels[j].m_nGain)
	{
	case 0:
		nThreadSholdPlus = 0;
		break;
	case 1:
		nThreadSholdPlus = 6;
		break;
	case 2:
		nThreadSholdPlus = 14;
		break;
	case 3:
		nThreadSholdPlus = 20;
		break;
	case 4:
		nThreadSholdPlus = 40;
		break;
	default:
		nThreadSholdPlus = 0;
		break;
	}
	dTemp = pHardware->m_pChannels[j].m_iParamThreashold + nThreadSholdPlus;
	dwValue = (DWORD) (pow((double)10.0,(double)(dTemp +
		pHardware->m_pChannels[j].m_iIncrementDB-120.0)/(double)20)*max_adc_val/10.0);//DB_10VTO2V;
	//����
	if(dwValue < 1)
		dTemp = 0;
	else
		dTemp = 20 * log10(dwValue * 10.0 / max_adc_val) - pHardware->m_pChannels[j].m_iIncrementDB + 120.0;

	if (dTemp < pHardware->m_pChannels[j].m_iParamThreashold + nThreadSholdPlus)
	{
		dwValue++;
	}
	if(dwValue > max_adc_val)
		dwValue = (DWORD)max_adc_val;

	//SetCardParamThreshold(short(pHardware->m_dwCardNo * pHardware->m_iChanCount + j), dwValue);


    CH_HIT_THRESHOLD_PROP RegVal;
    RegVal.cmd = 0;
    RegVal.spec.threshold = (dwValue<<2);//�˴�FPGA����ֲ��18λ���ʼ򻯲���������16λת��18λ������ȥ

    WriteRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_HIT_THRESHOLD_REG, RegVal.cmd);

	return TRUE;
}

BOOL CWAEDrive_USB30_16Bit::SetCardSampleThreshold(unsigned short chanNo, DWORD value)
{
	typedef union   //ͨ�������������ԼĴ�����ƫ�Ƶ�ַ0x8��
	{
		U32 cmd;
		struct _PropChWaveThresholdSpec
		{
			U32 threshold : 18;         //��������
			U32 reserved : 14;
		} spec;
	} CH_WAVE_THRESHOLD_PROP;

	short	cardNo;
	cardNo = chanNo/CHANNEL_COUNT_PERCARD;
	chanNo = chanNo%CHANNEL_COUNT_PERCARD;
	if(cardNo >= MAX_CARDNUM )
		return FALSE;
	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];
	if( pHardware == NULL ) return FALSE;
	pHardware->m_pChannels[chanNo].m_iSampleThreshold = value;

	double dTemp;
	DWORD dwValue;
	int nThreadSholdPlus = 0;	
	int j = chanNo;
	switch(pHardware->m_pChannels[j].m_nGain)
	{
	case 0:
		nThreadSholdPlus = 0;
		break;
	case 1:
		nThreadSholdPlus = 6;
		break;
	case 2:
		nThreadSholdPlus = 14;
		break;
	case 3:
		nThreadSholdPlus = 20;
		break;
	case 4:
		nThreadSholdPlus = 40;
		break;
	default:
		nThreadSholdPlus = 0;
		break;
	}
	dTemp = pHardware->m_pChannels[j].m_iSampleThreshold + nThreadSholdPlus;
	dwValue = (DWORD) (pow((double)10.0,(double)(dTemp +
		pHardware->m_pChannels[j].m_iIncrementDB-120.0)/(double)20)*max_adc_val/10.0);//DB_10VTO2V;
	//����
	if(dwValue < 1)
		dTemp = 0;
	else
		dTemp = 20 * log10(dwValue * 10.0 / max_adc_val) - pHardware->m_pChannels[j].m_iIncrementDB + 120.0;

	if (dTemp < pHardware->m_pChannels[j].m_iSampleThreshold + nThreadSholdPlus)
	{
		dwValue++;
	}
	if(dwValue > max_adc_val)
		dwValue = (DWORD)max_adc_val;

    CH_WAVE_THRESHOLD_PROP RegVal;
    RegVal.cmd = 0;
    RegVal.spec.threshold = (dwValue<<2);//�˴�FPGA����ֲ��18λ���ʼ򻯲���������16λת��18λ������ȥ

    WriteRegister(cardNo, g_ChRegBaseAddrs[chanNo % CHANNEL_COUNT_PERCARD] + PROP_CH_WAVE_THRESHOLD_REG, RegVal.cmd);

 
	return TRUE;
}

DWORD CWAEDrive_USB30_16Bit::GetFirFilterOrder()
{
	return FIR_ORDER;
}
/*++
����:
	����FIR�˲���������FIRϵ����������FIR���ԼĴ��� �� FIR�˲�������ϵ���Ĵ���
	�������ã������øÿ�������ͨ��
����:
	__in  CardNo - ����
	__in  pPara  - FIR�˲���ϵ������ָ��
	__in  order  - FIR�˲�������
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int CWAEDrive_USB30_16Bit::SetFirFilter(short CardNo,  short type, short low, short high)
{
	typedef union   //FIR���ԼĴ�����ƫ�Ƶ�ַ0xe��
	{
		U32 cmd;
		struct _PropChFirCfgSpec
		{
			U32 reserved : 28;
			U32 CoefWrCmd : 1;          //FIR�˲���ϵ��д���0'1��д��һ��ϵ����
			U32 CoefCfgCmd : 1;         //FIR�˲����������0'1���������ã�
			U32 RstCmd : 1;             //FIR��λ��0��������λ��1��������
			U32 FilterEn : 1;           //ʹ��ͨ��FIR�˲�����1��ʹ�ܣ�
		} spec;
	} CH_FIR_CFG_PROP;

	typedef union   //FIR�˲�������ϵ���Ĵ�����ƫ�Ƶ�ַ0x0f��
	{
		U32 cmd;
		struct _PropChFirCoefDataSpec
		{
			U32 coef : 16;              //ϵ��
			U32 reserved : 16;
		} spec;
	} CH_FIR_COEF_PROP;


	int i, j;
	CH_FIR_CFG_PROP RegVal;
	CH_FIR_COEF_PROP CoefVal;

	CH_FUNC_PROP FuncVal;

	
	if(CardNo >= MAX_CARDNUM )
	{
		return -1;
	}

	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[CardNo];
	if( pHardware == NULL ) return FALSE;

	for (i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{	
		pHardware->m_pChannels[i].m_nDigFilterType = type;
		pHardware->m_pChannels[i].m_dwDigFilterHigh = high;
		pHardware->m_pChannels[i].m_dwDigFilterLow = low;
	}
	//
	//���������˲���ϵ��	
	firls_Initialize(FIR_ORDER, type);
	int err;
	double *pFirCoef = NULL;
	if (type == enDigFilterLowPass)
	{
		pFirCoef = firls_Calculate(FIR_ORDER,
			type,
			high * 1000,
			high * 1000,
			0,
			0,
			pHardware->m_pChannels[0].m_dwSampleFreq*1000,
			err);
	}
	else if (type == enDigFilterHighPass)
	{
		pFirCoef = firls_Calculate(FIR_ORDER,
			type,
			low * 1000,
			low * 1000,
			0,
			0,
			pHardware->m_pChannels[0].m_dwSampleFreq*1000,
			err);
	}
	else if ((type == enDigFilterBandPass) || (type == enDigFilterBandStop))
	{
		pFirCoef = firls_Calculate(FIR_ORDER,
			type,
			low * 1000,
			low * 1000,
			high * 1000,
			high * 1000,
			pHardware->m_pChannels[0].m_dwSampleFreq*1000,
			err);
	}

	//���������˲���
	if ( type == enDigFilterNone)
	{
		DisableFirFilter(CardNo);
		//����FIR�˲���ϵ��
		firls_Terminated();
		return -1;
	}
	

	short order = FIR_ORDER;
	
	short *filter_coef = new short[FIR_ORDER / 2 + 1];

	if (filter_coef == NULL)
	{
		return -1;
	}

    for (i = 0; i < FIR_ORDER / 2 + 1; i++)
    {
        filter_coef[i] = (short)(pFirCoef[i] * 32767);
    }
    


	//�������˲���ϵ��������˳��
#if (FIR_ORDER == 159)
	//159���˲���ϵ������˳��
	unsigned coef_seq_80 [FIR_ORDER / 2 + 1] = {79, 9, 19, 29, 39, 49, 59, 69, 78, 8, 18, 28, 38, 48, 58, 68, 77, 7, 17, 27, 37, 47,
		57, 67, 76, 6, 16, 26, 36, 46, 56, 66, 75, 5, 15, 25, 35, 45, 55, 65, 74, 4, 14, 24,
		34, 44, 54, 64, 73, 3, 13, 23, 33, 43, 53, 63, 72, 2, 12, 22, 32, 42, 52, 62, 71, 1,
        11, 21, 31, 41, 51, 61, 70, 0, 10, 20, 30, 40, 50, 60};
#elif (FIR_ORDER == 63)
	//63���˲���ϵ������˳��
 	unsigned coef_seq_32 [FIR_ORDER / 2 + 1] = {31, 3, 7, 11, 15, 19, 23, 27, 30, 2, 6, 10, 14, 18, 22, 26, 29, 1, 5,
 		9, 13, 17, 21, 25, 28, 0, 4, 8, 12, 16, 20, 24};
//	unsigned coef_seq_32 [FIR_ORDER / 2 + 1] = {31, 7, 15, 23, 30, 6, 14, 22, 29, 5, 13, 21, 28, 4, 12, 20, 27, 3, 11,
//		19, 26, 2, 10, 18, 25, 1, 9, 17, 24, 0, 8, 16};
#elif (FIR_ORDER == 59)
	//59���˲���ϵ������˳��
	unsigned coef_seq_32 [FIR_ORDER / 2 + 3] = {29, 1, 5, 9, 13, 17, 21, 25, 28, 0, 4, 8, 12, 16, 20,
		24, 27, 0, 3, 7, 11, 15, 19, 23, 26, 0, 2, 6, 10, 14, 18, 22};
#endif
	RegVal.cmd = 0;
	RegVal.spec.RstCmd = 0;		//��λ�˲���ģ��
	WriteRegister(CardNo, g_ChRegBaseAddrs[0] + PROP_CH_FIR_CFG_REG, RegVal.cmd);
	
	RegVal.spec.FilterEn = 1;
	RegVal.spec.RstCmd = 1;
	Sleep(1);

	//��ϵ��д��ϵ����������
	for (j = 0; j < CHANNEL_COUNT_PERCARD; j++)
	{
#if (FIR_ORDER == 159)
		unsigned *coef_seq = coef_seq_80;
		for (i = 0; i < FIR_ORDER / 2 + 1; i++)
#elif (FIR_ORDER == 63)
		unsigned *coef_seq = coef_seq_32;
		for (i = 0; i < FIR_ORDER / 2 + 1; i++)
#elif (FIR_ORDER == 59)
		unsigned *coef_seq = coef_seq_32;
		for (i = 0; i < FIR_ORDER / 2 + 3; i++)
#endif
		/*++
		����ΪFIR�˲���ϵ��д�����RegVal.spec.CoefWrCmd ��0-1֮�䣬д��һ��ϵ����FIR�˲�������ϵ���Ĵ���
		--*/
		{

			CoefVal.cmd = 0;
			CoefVal.spec.coef = filter_coef[coef_seq[i]];
			WriteRegister(CardNo, g_ChRegBaseAddrs[j] + PROP_CH_FIR_COEF_DATA_REG, CoefVal.cmd);     //д��һ��ϵ��
			RegVal.spec.CoefWrCmd = 0;
			WriteRegister(CardNo, g_ChRegBaseAddrs[j] + PROP_CH_FIR_CFG_REG, RegVal.cmd);
			RegVal.spec.CoefWrCmd = 1;
			WriteRegister(CardNo, g_ChRegBaseAddrs[j] + PROP_CH_FIR_CFG_REG , RegVal.cmd);
		}
		Sleep(1);
		RegVal.spec.CoefCfgCmd = 0;                     //����FIR���ã�����ϵ���������е�����д���˲�����  
		WriteRegister(CardNo, g_ChRegBaseAddrs[j] + PROP_CH_FIR_CFG_REG, RegVal.cmd); 
		RegVal.spec.CoefCfgCmd = 1;                     //����FIR���ã�����ϵ���������е�����д���˲�����  
		WriteRegister(CardNo, g_ChRegBaseAddrs[j] + PROP_CH_FIR_CFG_REG, RegVal.cmd); 
		

		ReadRegister(CardNo, g_ChRegBaseAddrs[j] + PROP_CH_FUNCTION_REG, (unsigned int*)&FuncVal.cmd);
		FuncVal.spec.FirEn = 1;
		WriteRegister(CardNo, g_ChRegBaseAddrs[j] + PROP_CH_FUNCTION_REG, FuncVal.cmd);
	}	
	delete []filter_coef;
	//����FIR�˲���ϵ��
	firls_Terminated();
	return 0;
}

/*++
����:
	��λFIR�˲�����������FIR���ԼĴ����ĸ�λλ
	�������ã������øÿ�������ͨ��
����:
	__in  CardNo - ����
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int CWAEDrive_USB30_16Bit::DisableFirFilter(short CardNo)
{
	typedef union   //FIR���ԼĴ�����ƫ�Ƶ�ַ0xe��
	{
		U32 cmd;
		struct _PropChFirCfgSpec
		{
			U32 reserved : 28;
			U32 CoefWrCmd : 1;          //FIR�˲���ϵ��д���0'1��д��һ��ϵ����
			U32 CoefCfgCmd : 1;         //FIR�˲����������0'1���������ã�
			U32 RstCmd : 1;             //FIR��λ��0��������λ��1��������
			U32 FilterEn : 1;           //ʹ��ͨ��FIR�˲�����1��ʹ�ܣ�
		} spec;
	} CH_FIR_CFG_PROP;


	CH_FIR_CFG_PROP RegVal;
	if(CardNo >= MAX_CARDNUM )
	{
		return -1;
	}
	RegVal.cmd = 0;
	RegVal.spec.RstCmd = 0;
	CH_FUNC_PROP FuncVal;
	for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		WriteRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_FIR_CFG_REG, RegVal.cmd);
		ReadRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, (unsigned int*)&FuncVal.cmd);
		FuncVal.spec.FirEn = 0;
		WriteRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, FuncVal.cmd);
	}
	

	return 0;
}

/*++
����:
	����FFT����ģʽ��������FFT���ԼĴ���,����FFT��ʹ�ܵ�����£����ò�������2
	�������ã������øÿ�������ͨ��
����:
	__in  CardNo - ����
	__in  mode   - ��ֵ����16λ�忨ʱ��ֵ�����ڴ�����λ����
		����λ��0  - ͨ��FFTʹ��λ;    
				1  - ͨ����������λ;   
				2  - ͨ�����ɴ���λ;   
				3  - ͨ��0 ������ʹ��λ;  9  - ͨ��1 ������ʹ��λ;//��18λ��δ�õ�
				10 - ͨ��0 �Ƿ���δ�;    11 - ͨ��1 ֪����δ�;
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int CWAEDrive_USB30_16Bit::SetFFTWorkMode(short CardNo, DWORD mode)
{

	typedef union   //FFT���ԼĴ�����ƫ�Ƶ�ַ0x10��
	{
		U32 cmd;
		struct _PropChFftCfgSpec
		{
			U32 FtfEn : 1;              //ʹ��ͨ����FFT
			U32 HitTrigEn : 1;          //��������FFTʹ��
			U32 FreeRun : 1;            //����ͨ����FFTΪ��������ģʽ
			U32 reserved1 : 1;
			U32 RectWinEn : 1;          //�Ƿ�����FFT������Ϊ���δ���1�����δ���
			U32 reserved2 : 27;
		} spec;
	} CH_FFT_CFG_PROP;

	if(CardNo >= MAX_CARDNUM )
	{
		return -1;
	}
	CH_FUNC_PROP RegVal;
	CH_FFT_CFG_PROP ConfValue_CH0;
	CH_FFT_CFG_PROP ConfValue_CH1;
	ConfValue_CH0.cmd = mode;
	for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		if (ConfValue_CH0.spec.FtfEn)
		{
			ReadRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
			RegVal.spec.FftEn = 1;
			WriteRegister(CardNo,g_ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, RegVal.cmd);
			ConfValue_CH0.spec.HitTrigEn = mode>> 2;
			ConfValue_CH0.spec.FreeRun = mode>> 4;
			ConfValue_CH0.spec.RectWinEn = mode>> 10;
			WriteRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_FFT_CFG_REG, ConfValue_CH0.cmd);
		}
		else
		{
			ReadRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
			RegVal.spec.FftEn = 0;
			WriteRegister(CardNo,g_ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, RegVal.cmd);
			WriteRegister(CardNo, g_ChRegBaseAddrs[i] + PROP_CH_FFT_CFG_REG, ConfValue_CH0.cmd);	
		}
	}

	return 0;
}


/*++
����:
	����FFT�������ޣ�������FFT�������޼Ĵ���
	�������ã������øÿ�������ͨ��
����:
	__in  CardNo           - ����
	__in  fftWaveThreshold - FFT���δ�������ֵ
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int CWAEDrive_USB30_16Bit::SetFFTWaveTrigPara(DWORD CardNo, DWORD fftWaveThreshold)
{
	typedef union   //fft �������޼Ĵ��� ��ƫ�Ƶ�ַ 0x19��
	{
		U32 cmd;
		struct _PropChFftThresholdCfgSpec
		{
			U32 threshold : 18;         //fft��������, Ҫ�����ʾ������ֵΪ����
			U32 reserved : 14;
		} spec;
	} CH_FFT_THRESHOLD_CFG_PROP;

	if(CardNo >= MAX_CARDNUM )
	{
		return -1;
	}
	CH_FFT_THRESHOLD_CFG_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.threshold = fftWaveThreshold << 2; //�˴�FPGA����ֲ��18λ���ʼ򻯲���������16λת��18λ������ȥ

	WriteRegister((short)CardNo, g_ChRegBaseAddrs[0] + PROP_CH_FFT_THRESHOLD_REG, RegVal.cmd);
	WriteRegister((short)CardNo, g_ChRegBaseAddrs[1] + PROP_CH_FFT_THRESHOLD_REG, RegVal.cmd);

	return 0;
}

/*++
����:
	����FFT����ϵ����������FFT�������ԼĴ���
	��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_COUNT_PERCARD - 1)
����:
	__in  ChanNo - ����ͨ����
	__in  scale  - FFT����ϵ��
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int CWAEDrive_USB30_16Bit::SetChFFTResultScale(unsigned short ChanNo, double scale)
{
	typedef union   //FFT�������ԼĴ�����ƫ�Ƶ�ַ0x12��
	{
		U32 cmd;
		struct _PropChFftScaleCfgSpec
		{
			U32 scale : 18;             //FFT��������űȣ�����ʹ��FFT����������ɵĹ�����ʧ���������ڹ��ʲ�����
			U32 reserved : 14;
		} spec;
	} CH_FFT_SCALE_CFG_PROP;

	unsigned short CardNo;
	unsigned int uScale = 0;

	CardNo = ChanNo / CHANNEL_COUNT_PERCARD;
	ChanNo = ChanNo % CHANNEL_COUNT_PERCARD;

	if(CardNo >= MAX_CARDNUM )
	{
		return -1;
	}
	CH_FFT_SCALE_CFG_PROP RegVal;
	RegVal.cmd = 0;
	//Scale����ת��
	RegVal.spec.scale = (UINT)scale * 32768;
	WriteRegister(CardNo, g_ChRegBaseAddrs[0] + PROP_CH_FFT_SCALE_CFG_REG, RegVal.cmd);
	WriteRegister(CardNo, g_ChRegBaseAddrs[1] + PROP_CH_FFT_SCALE_CFG_REG, RegVal.cmd);

	return 0;
}

//ȡ����ֵx��������1�ĸ���
//##ModelId=4C22CB3B01A5
unsigned long CWAEDrive_USB30_16Bit::GetOneCount(unsigned long x)
{
	x = (x & 0x55555555UL) + ((x >> 1) & 0x55555555UL);
	x = (x & 0x33333333UL) + ((x >> 2) & 0x33333333UL);
	x = (x & 0x0f0f0f0fUL) + ((x >> 4) & 0x0f0f0f0fUL);
	x = (x & 0x00ff00ffUL) + ((x >> 8) & 0x00ff00ffUL);
	x = (x & 0x0000ffffUL) + ((x >> 16) & 0x0000ffffUL);
	return x;
}

/*++
����:
	����ͨ��FFT��������������FFT�����ԼĴ���
	��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_COUNT_PERCARD - 1)
����:
	__in  ChanNo        - ����ͨ����
	__in  bEnableWindow - ������ʹ���źţ�TUREΪʹ��
	__in  pWinFunCoef   - ������ϵ�������ָ��
	__in  len           - ������ϵ������
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int CWAEDrive_USB30_16Bit::SetChFFTWindowFunction(unsigned short chanNo, BOOL bEnableWindow, int iFftWinType, int len)
{
	typedef union   //FFT�����ԼĴ�����ƫ�Ƶ�ַ0x11��
	{
		U32 cmd;
		struct _PropChFftWinCfgSpec
		{
			U32 CoefAddr : 10;          //����FFT���ں�����ϵ����ַ
			U32 coef : 18;              //����FFT���ں�����ϵ��
			U32 CoefWrCmd : 1;          //����FFT���ں������ݵ�д���0'1��д��һ��FFT����ϵ����
			U32 reserved : 3;
		} spec;
	} CH_FFT_WIN_CFG_PROP;

	int i;

	unsigned short cardNo;
	
	cardNo = chanNo / CHANNEL_COUNT_PERCARD;
	chanNo = chanNo % CHANNEL_COUNT_PERCARD;
	
	if(cardNo >= MAX_CARDNUM )
	{
		return -1;
	}
	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];
	if( pHardware == NULL ) return FALSE;
	pHardware->m_iFftWinType = iFftWinType;
	pHardware->m_bFFTEnable = bEnableWindow;
	double dFFTWinCoef[FFT_CALC_LEN];
	double dFFTGain;
	WindowFunction(dFFTWinCoef, pHardware->m_iFftWinType, len, &dFFTGain);

	CH_FFT_WIN_CFG_PROP RegVal;
	if (bEnableWindow)
	{
		if (len > 1024)
		{
			return -1;
		}

		//������ϵ��ת��
		int *pTmpCoef = new int[len];
		int tmpCoef  = (1L << (GetOneCount(0xFFFFC00) - 1)) - 1;
		for (i = 0; i < len; i++)
		{
			pTmpCoef[i] = (int)(dFFTWinCoef[i] * tmpCoef);
		}
		
		//��λ������
		RegVal.cmd = 0;
		WriteRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_FFT_WIN_CFG_REG, RegVal.cmd);

		//дϵ��
		for (i = 0; i < len; i++)
		{
			RegVal.spec.CoefAddr = i;
			RegVal.spec.coef= pTmpCoef[i];
			RegVal.spec.CoefWrCmd = 0;
			WriteRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_FFT_WIN_CFG_REG, RegVal.cmd);
			RegVal.spec.CoefWrCmd = 1;
			WriteRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_FFT_WIN_CFG_REG, RegVal.cmd);
		}

		//ʹ�ܴ�����
		delete []pTmpCoef;
	}
	else
	{
		WriteRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_FFT_WIN_CFG_REG, 0);
	}
	SetChFFTResultScale(cardNo *CHANNEL_COUNT_PERCARD +  chanNo, dFFTGain);
	return 0;
}

/*++
����:
	����ͨ��FFT���������泤�ȣ�������FFT�������������ԼĴ���
	��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_COUNT_PERCARD - 1)
����:
	__in  ChanNo - ����ͨ����
	__in  len    - FFT����������
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int CWAEDrive_USB30_16Bit::SetChFFTSaveLen(unsigned short ChanNo, int len)
{
	unsigned short CardNo;
	unsigned char addr;

	CardNo = ChanNo / CHANNEL_COUNT_PERCARD;
	ChanNo = ChanNo % CHANNEL_COUNT_PERCARD;
	
	if(CardNo >= MAX_CARDNUM )
	{
		return -1;
	}
	
	addr = AE_HIT_CFG_BASEADDR_CH0;
	addr <<= ChanNo;

	WriteRegister(CardNo, addr + AE_HIT_CFG_FFT_SAVELEN_REG, len & AE_HIT_CFG_FFT_SAVELEN_MASK);

	return 0;
}

/*++
����:
	����ͨ��FFT�źų�ȡ�ʣ�������FFT��Ƶϵ���Ĵ���
	��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_COUNT_PERCARD - 1)
����:
	__in  ChanNo - ����ͨ����
	__in  val    - FFT�źų�ȡ�ʣ����Ϊ65535����СΪ1��ע����Ҫͬ�˲������õ����
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int CWAEDrive_USB30_16Bit::SetChFFTDecimateRate(unsigned short chanNo, int val)
{
	typedef union   //FFT��Ƶϵ���Ĵ�����ƫ�Ƶ�ַ0x13��
	{
		U32 cmd;
		struct _PropChFftDecimateCfgSpec 
		{
			U32 DecimateRate : 16;      //FFT���ݳ�����Ƶϵ��
			U32 reserved : 16;
		} spec;
	} CH_FFT_DECIMATE_CFG_PROP;

	unsigned short cardNo;
	
	cardNo = chanNo / CHANNEL_COUNT_PERCARD;
	chanNo = chanNo % CHANNEL_COUNT_PERCARD;
	
	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];
	if( pHardware == NULL ) return FALSE;
	pHardware->m_dwFftDecimateRate = val;	

	if(cardNo >= MAX_CARDNUM )
	{
		return -1;
	}
	CH_FFT_DECIMATE_CFG_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.DecimateRate = val & AE_HIT_CFG_FFT_DECIMATE_RATE_MASK;
	WriteRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_FFT_DECIMATE_RATE_REG, RegVal.cmd);
	
	return 0;
}

/*++
����:
	����ͨ��FFT�źų�ȡ�ʣ�������FFT�ֲ����������üĴ���
	��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_COUNT_PERCARD - 1)
����:
	__in  ChanNo   - ����ͨ����
	__in  id       - �����, 0 - (MAX_FFT_PARTIAL_POW_SEGMENTS - 1)
	__in  StartBin - ��ʼBIN���	
	__in  EndBin   - �յ�BIN���
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int CWAEDrive_USB30_16Bit::SetChFFTPartialPowerSegment(unsigned short ChanNo, unsigned int id, int StartBin, int EndBin)
{
	typedef union   //FFT��0�ζ���Ĵ�����ƫ�Ƶ�ַ0x14��
	{
		U32 cmd;
		struct _PropChFftPpCfgSpec
		{
			U32 MaxBin : 9;             //�ֲ������׵��յ�
			U32 reserved1 : 7;
			U32 MinBin : 9;             //�ֲ������׵����
			U32 reserved2 : 7;
		} spec;
	} CH_FFT_PP_CFG_PROP;


	unsigned short CardNo;
	unsigned char index_addr;
	
	CardNo = ChanNo / CHANNEL_COUNT_PERCARD;
	ChanNo = ChanNo % CHANNEL_COUNT_PERCARD;
	
	if(CardNo >= MAX_CARDNUM )
	{
		return -1;
	}

	if (id >= 5)
	{
		return -1;
	}
	CH_FFT_PP_CFG_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.MaxBin = EndBin;
	RegVal.spec.MinBin = StartBin;

	index_addr = PROP_CH_FFT_PP0_REG;
	index_addr += id;

	WriteRegister(CardNo,g_ChRegBaseAddrs[ChanNo] + index_addr, RegVal.cmd);
    return 0;
}

/*++
����:
	����ͨ�������ɼ�ģʽ���������������δ���ģʽ�Ĵ�����������ͨ���������ԼĴ���Ϊ�����ɼ�
	��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_COUNT_PERCARD - 1)
����:
	__in  chanNo   - ����ͨ����
	__in  bEnabled - �����ɼ�ʹ��
	__in  TrigMode - ����ģʽ	
����ֵ:
	��ȷ���� TRUE
	���󷵻� FALSE
--*/
BOOL CWAEDrive_USB30_16Bit::SetChStreamingMode(unsigned short chanNo, BOOL bEnabled, int TrigMode)
{
	typedef union   //�������δ���ģʽ�Ĵ�����ƫ�Ƶ�ַ0xc��
	{
		U32 cmd;
		struct _PropChStreamCfgSpec
		{
			U32 ThresholdTrig : 1;      //���޴���,���޴�����ʽ������ֵΪ��������
			U32 ExternalTrig : 1;       //�ⲿ����
			U32 InternalTrig : 1;       //�ڲ�����
			U32 GiveupEn : 1;			//�����ɼ�ʧ��ʱ�Ƿ����������ɼ�
			U32 reserved : 28;
		} spec;
	} CH_STREAM_CFG_PROP;


    unsigned short cardNo;
    cardNo = chanNo /CHANNEL_COUNT_PERCARD;
    chanNo = chanNo % CHANNEL_COUNT_PERCARD;
    if(cardNo >= MAX_CARDNUM  )
        return FALSE;

	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];
	if( pHardware == NULL ) return FALSE;
	pHardware->m_pChannels[chanNo].m_bIsStreaming = bEnabled;

    CH_FUNC_PROP RegVal;
    

    if (bEnabled)
    {
        ReadRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
        RegVal.spec.StreamWaveEn = 1;
		RegVal.spec.FftEn = 0;
		RegVal.spec.ThresholdWaveEn = 0;
		RegVal.spec.StateFrmEn = 1;
        WriteRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_FUNCTION_REG, RegVal.cmd);

        CH_STREAM_CFG_PROP TrigVal;
        TrigVal.cmd = 0;
        switch (TrigMode)
        {
        case enStreamTrigSrcInternal: //�ڲ�����
            TrigVal.spec.InternalTrig = 1;
            break;
        case enStreamTrigSrcExternal: //�ⲿ����
            TrigVal.spec.ExternalTrig = 1;
            break;
        case enStreamTrigSrcThreshold: //���޴���
            TrigVal.spec.ThresholdTrig = 1;
            break;
        default:
            TrigVal.spec.InternalTrig = 1;
            break;
        }
		TrigVal.spec.GiveupEn = 1;
        WriteRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_STREAM_CFG_REG, TrigVal.cmd);


    }
    else
    {
        ReadRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
        RegVal.spec.StreamWaveEn = 0;
        WriteRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_FUNCTION_REG, RegVal.cmd);
		RegVal.spec.MasterChannel = 0;
		RegVal.spec.IndependentChannel = 1;
		WriteRegister(cardNo, g_ChRegBaseAddrs[chanNo] + PROP_CH_FUNCTION_REG, RegVal.cmd);
    }
    
    return TRUE;
}


/*++
����:
	����ͨ�������ɼ��ڲ���������д����ȫ���������βɼ����ƼĴ���
	��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_COUNT_PERCARD - 1)
����:
	__in  ChanNo - ����ͨ����
����ֵ:
	��ȷ���� TRUE
	���󷵻� FALSE
--*/
BOOL CWAEDrive_USB30_16Bit::StartChStreamingInternalTrig(unsigned short chanNo)
{
    unsigned short CardNo;
    CardNo = chanNo /CHANNEL_COUNT_PERCARD;
    chanNo = chanNo % CHANNEL_COUNT_PERCARD;
    if(CardNo >= MAX_CARDNUM  )
        return FALSE;
    
    GLB_STREAM_CTRL_CMD StrmVal;
    StrmVal.cmd = 0;
    

    
    StrmVal.spec.InterTrig = 1;
    
    WriteRegister(CardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_STREAM_CTRL_REG, StrmVal.cmd);

    return TRUE;
}

//���ñ���ʧЧʱ��
//DWORD CardNo  -- ����
//DWORD ms      -- ����ʱ�䣬��λms
int CWAEDrive_USB30_16Bit::SetCardAlarmTimeout(DWORD CardNo, DWORD ms)
{  
	typedef union  //ȫ�ֱ���ʧЧʱ�����ԼĴ���cfg_glb_timeout_alarm��0xc��
	{
		U32 cmd;
		struct _PropGlbAlarmTimeoutSpec
		{
			U32 timeout : 32;           //��λms��Ĭ��ֵ1s
		} spec;
	}GLB_ALARM_TIMEOUT_PROP;


	if(CardNo >= MAX_CARDNUM )
	{
		return -1;
	}

	GLB_ALARM_TIMEOUT_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.timeout = ms;

	WriteRegister((SHORT)CardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_ALARM_TIMEOUT_REG, RegVal.cmd);

	return 0;
}

BOOL CWAEDrive_USB30_16Bit::SetAdg1439(DWORD CardNo, unsigned long dat_l, unsigned long dat_h)
{
    return FALSE;
}

/*--------------------
Issue Pluse , namely AST function
Description:
chan:    Pluse Channel NO
TrigPara[7:0] --   Pluse Number
TrigPara[15:8] --  PluseWidth ,Unit 1us;
TrigPara[23:16] -- PluseInter, Unit 50ms;
TrigPara[31:24] -- Not used
---------------------------*/
BOOL CWAEDrive_USB30_16Bit::PluseTrig(int chanNo,int Trigvalue)
{
	typedef union   //�Զ��������������ԼĴ���cfg_glb_ast��0x06��
	{
		U32 cmd;
		struct _PropGlbAstSpec
		{
			U32 ch : 4;                 //ͨ����
			U32 PulseNo : 8;            //�������
			U32 PulseWid : 8;           //������ȣ���λ:1us��
			U32 PulseInt : 8;           //����������λ:50ms��
			U32 reserved : 4;
		} spec;
	} GLB_AST_PROP;
	typedef union   //ȫ��ast ״̬�Ĵ���stu_glb_ast (0x05)
	{
		U32 cmd;
		struct _StatGlbAstSpec
		{
			U32 completed : 1;
			U32 reserved : 31;
		} spec;
	} GLB_AST_STAT;

	short	cardNo;
	cardNo = chanNo/CHANNEL_COUNT_PERCARD;
	chanNo = chanNo%CHANNEL_COUNT_PERCARD;
	if(cardNo >= MAX_CARDNUM || chanNo < 0)
		return FALSE;

	if(cardNo >= MAX_CARDNUM )
	{
		return false;
	}
	CHardWare_USB30_16Bit* pHardware = (CHardWare_USB30_16Bit*)m_HardWareArray[cardNo];
	if( pHardware == NULL )
		return false;
	if( pHardware->m_dwDevStatus != USB_DEV_OPEN )
		return false;


	//AST����
	GLB_AST_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.ch = (0x1 << chanNo);
	RegVal.spec.PulseNo = Trigvalue & 0xFF;
	RegVal.spec.PulseWid = (Trigvalue >> 8) & 0xFF;
	RegVal.spec.PulseInt = (Trigvalue >> 16) & 0xFF;
	WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_AST_REG, RegVal.cmd);

	//����AST
	
	GLB_START_CMD RegCmd;
	ReadRegister(cardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_START_REG, (unsigned int*)&RegCmd.cmd);
	//RegCmd.cmd = 0;
	RegCmd.spec.StartAst = 0;
	WriteRegister(cardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_START_REG, RegCmd.cmd);
	RegCmd.spec.StartAst = 1;
	WriteRegister(cardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_START_REG, RegCmd.cmd);
	//�ȴ�AST����
	GLB_AST_STAT AstStat;
	AstStat.cmd = 0;
	AstStat.spec.completed = COMPLETED;
	do 
	{
		ReadRegister(cardNo, STAT_GLB_REG_BASEADDR + STAT_GLB_AST_REG, (unsigned int *)&AstStat.cmd);
	} while (COMPLETED != AstStat.spec.completed);

	return TRUE;
}

void CWAEDrive_USB30_16Bit::OnReceiveData(DWORD dwCardNo, char* buff, int count)
{

}
CWAE_HardWare* CWAEDrive_USB30_16Bit::AddHardWare(CWAE_HardWare* pHardWare, DWORD dwCardNo)
{
	if( pHardWare == NULL )
		pHardWare = new CHardWare_USB30_16Bit(CHANNEL_COUNT_PERCARD);

	pHardWare->SetWAEDrive(this);
	pHardWare->m_dwCardNo = dwCardNo;
	for (int i = 0; i < CHANNEL_COUNT_PERCARD; i++)
	{
		pHardWare->m_pChannels[i].m_nChannelId = i;
	}
	//pHardWare->m_pChannels[0].m_nChannelId = 0;
	//pHardWare->m_pChannels[1].m_nChannelId = 1;
	//TRACE("AddHardWare Lock\n");
	::EnterCriticalSection(&m_csHardwareMapLock);
	m_HardWareArray[dwCardNo] = pHardWare;
	::LeaveCriticalSection(&m_csHardwareMapLock);
	//TRACE("AddHardWare unLock\n");

	return pHardWare;
}

CWAE_HardWare* CWAEDrive_USB30_16Bit::GetHardWare( DWORD dwCardNo )
{
	return m_HardWareArray[dwCardNo];
}

BOOL CWAEDrive_USB30_16Bit::StartThread( DWORD dwType )
{
	switch(dwType)
	{
	case THREAD_DATA:
		{
			if( m_pDataReadThread )
			{
				m_pDataReadThread->KillThread(FALSE);
				delete m_pDataReadThread;
			}
			m_pDataReadThread = new CUSB30_16Bit_Data_Thread;
			m_pDataReadThread->SetWAEDrive(this);
			if(!m_pDataReadThread->StartListon())//��������
			{
				return FALSE;
			}

		}
		break;
	case THREAD_COMMAND:
		break;
	case THREAD_PARAM:
		{
			//if( m_pSaveParamThread )
			//{
			//	m_pSaveParamThread->KillThread(FALSE);
			//	delete m_pSaveParamThread;
			//}
			//m_pSaveParamThread = new CWAEDriveSaveParamThread;
			//m_pSaveParamThread->SetWAEDrive(this);
			//if(!m_pSaveParamThread->StartListon())//��������
			//{
			//	return FALSE;
			//}
		}
		break;
	case THREAD_WAVE:
		{
			//if( m_pSaveWaveThread )
			//{
			//	m_pSaveWaveThread->KillThread(FALSE);
			//	delete m_pSaveWaveThread;
			//}
			//m_pSaveWaveThread = new CWAEDriveSaveWaveThread;
			//m_pSaveWaveThread->SetWAEDrive(this);
			//if(!m_pSaveWaveThread->StartListon())//��������
			//{
			//	return FALSE;
			//}
		}
		break;
	case THREAD_FFT:
		break;
	default:
		break;
	}

	return TRUE;
}
BOOL CWAEDrive_USB30_16Bit::StopThread( DWORD dwType )
{
	switch(dwType)
	{
	case THREAD_DATA:
		{
			if( m_pDataReadThread)
			{	
				m_pDataReadThread->KillThread(FALSE);
				m_pDataReadThread->StopListon();
				delete m_pDataReadThread;
				m_pDataReadThread = NULL;
			}
		}
		break;
	case THREAD_COMMAND:
		break;
	case THREAD_PARAM:
		{
			//if( m_pSaveParamThread)
			//{	
			//	m_pSaveParamThread->KillThread(FALSE);
			//	m_pSaveParamThread->StopListon();
			//	delete m_pSaveParamThread;
			//	m_pSaveParamThread = NULL;
			//}
		}
		break;
	case THREAD_WAVE:
		{
			//if( m_pSaveWaveThread)
			//{	
			//	m_pSaveWaveThread->KillThread(FALSE);
			//	m_pSaveWaveThread->StopListon();
			//	delete m_pSaveWaveThread;
			//	m_pSaveWaveThread = NULL;
			//}
		}
		break;
	case THREAD_FFT:
		break;
	default:
		break;
	}

	return TRUE;
}

