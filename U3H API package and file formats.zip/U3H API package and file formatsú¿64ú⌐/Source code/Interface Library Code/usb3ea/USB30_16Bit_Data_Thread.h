#pragma once

#include "My_WorkThread.h"


class U3016_DataOVLap
{
public:
	U3016_DataOVLap()
	{
		m_nCardNo = 0;
		m_nCurIndex = 0;
		m_nGroupCount = 0;
		m_nRecBuffCount = 4*1024*1024;
		for (int i = 0; i < 8; i++)
		{
			m_hEvents[i] = NULL;
			memset(&m_ovReadDatas[i],0,sizeof(OVERLAPPED));
			m_pXmitBufs[i] = NULL;
			m_recvbuffers[i] = NULL;
		}
	}
	~U3016_DataOVLap()
	{
		for (int i = 0; i < m_nGroupCount; i++)
		{
			if( m_hEvents[i] != NULL)
			{
				CloseHandle(m_hEvents[i]);
				m_hEvents[i] = NULL;
			}		
			//if(m_pXmitBufs[i])
			//{
			//	delete[]  m_pXmitBufs[i];
			//	m_pXmitBufs[i] = NULL;
			//}
		    if( m_recvbuffers[i])
	       {
				delete[]  m_recvbuffers[i];
				m_recvbuffers[i] = NULL;
		   }
		}
	}
	HANDLE      m_hEvents[8];
	OVERLAPPED m_ovReadDatas[8];
	PUCHAR  m_recvbuffers[8];
	PUCHAR  m_pXmitBufs[8];
	int m_nCurIndex;
	int m_nCardNo;
	int m_nRecBuffCount;
	void SetGroupCount(int nCount);
	int GetGroupCount(){ return m_nGroupCount;}
	HANDLE GetCurEvent(){ return m_hEvents[m_nCurIndex];}
    OVERLAPPED* GetCurOvLap(){ return &m_ovReadDatas[m_nCurIndex];}
    void ReadAllDataAsy(int nIndex = 0);
	void ReadNextDataAsy();
    LONG FinishAsyReadData();
    PUCHAR GetCurBuff(){ return m_recvbuffers[m_nCurIndex]; }
    void StopReadData();
	void Abort();
private:
	int m_nGroupCount;

};

// CUSB30_16Bit_Data_Thread
class CWAEDrive_USB30_16Bit;
class CUSB30_16Bit_Data_Thread : public CMy_WorkThread
{


public:
	CUSB30_16Bit_Data_Thread(CWAEDrive_USB30_16Bit* pDirve );           // protected constructor used by dynamic creation
	virtual ~CUSB30_16Bit_Data_Thread();
	CUSB30_16Bit_Data_Thread();           // protected constructor used by dynamic creation
public:
	virtual BOOL InitInstance();
	virtual int  ExitInstance();
	virtual void DoWork();

			BOOL StartListon();
			BOOL StopListon();




protected:
	void ClearBuffer();

public:
	void SetWAEDrive(CWAEDrive_USB30_16Bit* pDrive){ m_pDrive = pDrive; };
	CWAEDrive_USB30_16Bit* GetWAEDrive(){ return m_pDrive; };
protected:
	CWAEDrive_USB30_16Bit* m_pDrive;
	U3016_DataOVLap* m_dataOvLaps;
private:

	HANDLE*      m_hEventArray;// ��������ȡ�¼�event
	OVERLAPPED** m_ppOvReads;
	int*       m_pCardNos;
	int          m_nOpenedDevNum;
	int          m_offsetEvent;


	

};


