
#if !defined(__USB_AE_HARDWARE_16BIT_NEW_H__)
#define __USB_AE_HARDWARE_16BIT_NEW_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

//#include "../include/usb/usbae.h"
//#include "Usb7kC.h"
//#include "usbAEhardware.h"
#include "WAEParamFIFO.h"
#include "DataType.h"
#include "Usb7kCioctl.h"
//#include "../include/sys/UAE_CHANNEL_SET.h"
//#include "../include/sys/WaveToHit.h"

class UsbaeHardware16BitNew
{
public:
    UINT fpgaVersion;
    
    BOOL      bQueryCardStatus;
    HANDLE husb;
	int	   usbChNum;
	int    usbGain;

	UINT   singlePackageSum;
    UINT   restPackageCard[MAX_CARDNUM];
    UCHAR *restPackageData[MAX_CARDNUM];
    
	short m_exParamaterFreq;
    BOOL bExParamCheck;
	BOOL bOpenCardStatus;
    //ULONGLONG sysCurTime;

	BOOL ThreadFlag;
	int  ThreadStatus;
	DWORD SampleLen;
	BOOL  bDeviceStaus[MAX_CARDNUM];  // device is exsit
	BOOL  bDeviceOpenFlag[MAX_CARDNUM]; // device exist and open
    BOOL *bChEnabled;

	HANDLE		paraMutex;
	HANDLE		rawMutex;
    HANDLE fftMutex;
	HANDLE dataMutex[3];
	int EventIndexTOCardIndex[MAX_CARDNUM];
	UINT openCardNum;
	UINT perCardParabufLength;
	UINT curCardParaLength[MAX_CARDNUM+1];
	UINT leftParabufLength;
	PARAM *tempParaBuf[MAX_CARDNUM+1];
	
	HANDLE	ThreadHandle;
	HANDLE  hEventArray[MAX_CARDNUM*2];// ��������ȡ�¼�event
    OVERLAPPED ovRead[MAX_CARDNUM];
	
	unsigned __int64 preSysTime;
	unsigned __int64 curSysTime;
	unsigned __int64 m_ullLastSystime;
	__int64  m_llParamTimeAdjust;
	
	CWAEParamFIFO chParamFIFO[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD+2];
	
    PARAM *paraBuf;
	
	UCHAR  *recvbuffer;
	char  *rawBuf;//[MAX_RAWDATA_BUF_LENGTH];
	DWORD maxRawBufLength;
    DWORD singleChannelBufLen;  //�ϴ���Ӧ�ò�ĵ�ͨ�����γ���
    DWORD singleChannelRawDataLen;  //���յ���ԭʼ���ݵ�ͨ�����γ���
	DWORD curRawBufLength;
	//DWORD curParaBufLength;
	
    char   *fftBuf;
    DWORD  maxFftBufLength;
    DWORD  singleFftBufLen;
    DWORD  curFftBufLength;
    UINT   singleFftPackageSum;
    UINT   restFftPackageCard[MAX_CARDNUM];
    UCHAR  *restFftPackageData[MAX_CARDNUM];
	
	DWORD FirFilterOrder;
	
	UINT mb_ver[MAX_CHASSIS];
	UINT card_ver[MAX_CARDNUM];
	
    //��18λ���ݶ���
    BOOL bFrmDecodeCompleted[MAX_CARDNUM];       //֡�������
    UINT PackVer[MAX_CARDNUM];                   //���汾
    UINT FrmVer[MAX_CARDNUM];                    //֡�汾
    UINT FrmEncodeType[MAX_CARDNUM];             //֡���뷽ʽ
    UINT FrmDpcmBits[MAX_CARDNUM];               //DPCM����λ��
    U32 PackId[MAX_CARDNUM];                     //����ţ�32bit��
    U16 PackOfFrm[MAX_CARDNUM];                  //��֡����ţ�16bit��
    U16 PackInFrm[MAX_CARDNUM];                  //ͬ֡������16bit��
    BOOL *bStartStreamingInternalTrig;
	UINT ParamType;								 //�������뷽ʽ��Ŀǰ�б����㷨0�ͱ����㷨2��
	short exParamBuf[12];						 //���֡buffer
	BOOL exParamEn;								 //��ι���ʹ��
	BOOL fftEn;									 //FFT����ʹ��
	unsigned short ChStreamingState[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD]; //�����ɼ�ͨ��״̬ 
	
    U32 *WaveThreshold;//[MAX_CARDNUM * CHANNEL_NUMBER_PERCARD];

    //PWAVETOHIT_STRUCT WthMdl;
    BOOL bHardParam;                            //Ӳ����������
    BOOL bParamEn[MAX_CARDNUM * CHANNEL_NUMBER_PERCARD];   //��ȡײ������
    HANDLE hWaveToHitSemaph;                               //����ת����ͬ��
public:
	UsbaeHardware16BitNew();
    ~UsbaeHardware16BitNew();
	
	void ConfigDDR(short nIndex);
	void AnalysisPacket(short nIndex,UCHAR *recvbuffer, UINT recvcount);
	static void ReadRegister(short CardId,UCHAR addr, UINT *value);
	void WriteRegister(short CardId,UCHAR addr, UINT value);
    int FindAllSinglePointCard(BOOL *bDeviceFlag);
    BOOL GetTransmitStatisticData(unsigned short CardNo, unsigned __int64 val[4]);
    BOOL ClearTransmitStatisticData(unsigned short CardNo);
    void GetOutputInfo(UINT input[10], PCHAR pStrBuf, int bufSize);
    char * GetOutputInfo(UINT input[10]);
    void ConfigureBeforeStart();
    void ConfigureAfterStart();
	BOOL GetMbFwVersion(short ChassisId, UINT *val);
	BOOL GetAECardFwVersion(short CardId, UINT *val);
	
	BOOL OnPluseTrig(int chanNo,int TrigPara);
	BOOL OnPluseTrigStop(int chanNo);
	void OpenCard(BOOL *bDeviceFlag, DWORD SampleLength, BOOL reset);
	DWORD GetCardStatus(BOOL *bDeviceFlag = NULL, BOOL reset = TRUE);
	BOOL StartSample();
	void StopSample();
	void CloseCard();
	DWORD GetParamFromBuf(PARAM *pBuf);
	__int64 GetSysTickCount64();
	DWORD GetRawDataFromBuf(char *rBuf);
    DWORD GetFftDataFromBuf(char *rBuf);
	BOOL SetCardParamEventInterval(unsigned short  CardNo, DWORD value);
	BOOL SetCardParamEventLockOut(unsigned short  CardNo, DWORD value);
	BOOL SetCardParamEventPdt(unsigned short CardNo, DWORD value);
	BOOL SetCardSampleLength(unsigned short  CardNo, DWORD value);
    BOOL GetCardSampleFreq(unsigned short CardNo, WORD *value);
	BOOL SetCardSampleFreq(unsigned short  CardNo, WORD value);

	BOOL SetCardParamThreshold(unsigned short  chanNo, DWORD value);
	BOOL SetCardSampleThreshold(unsigned short chanNo, DWORD value);
	
	BOOL SetCardEnableWaveformParam(unsigned short CardNo, WORD EnableWavefrom, WORD EnableParam);
	BOOL SetCardSelectLight(unsigned short CardNo, WORD bSelect);
	
// 	BOOL SetCardschControl(unsigned short CardNo, WORD schControl);

    BOOL SetFilterGain(unsigned short chanNo, unsigned short filter, unsigned short gain);
    BOOL SetCardFilterGain(unsigned short CardNo, unsigned short ch0_filter, unsigned short ch0_gain,
        unsigned short ch1_filter, unsigned short ch1_gain);
	BOOL SetExnTrig(unsigned short CardNo, BOOL bStatus);
	BOOL SetCardSample(unsigned short CardNo, BOOL bStatus);
	BOOL SetCardPause(unsigned short CardNo, BOOL bStatus);
	BOOL SetSampleMode(unsigned short chanNo, int mode, int SampleSum );
    BOOL SetExparamAttri(unsigned short cardNo, DWORD dwExparamAttri);
	BOOL SetExparamFixed(unsigned short chanNo, DWORD outInterval);
    BOOL EnableSysTimer(unsigned short cardNo, DWORD sysTimer);
    BOOL GetCardDriverVersion(unsigned short cardNo, PEZUSB_DRIVER_VERSION pDriverVersion);
    UINT GetVersionConf(unsigned short cardNo);

	DWORD GetFirFilterOrder();
	int SetFirFilter(short CardNo, double* pPara, int order);
	int DisableFirFilter(short CardNo);
	int SetFFTWorkMode(short CardNo, DWORD mode);
	int SetFFTWaveTrigPara(DWORD CardNo, DWORD fftWaveThreshold);
	int SetChFFTResultScale(unsigned short ChanNo, double scale);
	int SetChFFTWindowFunction(unsigned short ChanNo, BOOL bEnableWindow, double *pWinFunCoef, int len);
	int SetChFFTSaveLen(unsigned short ChanNo, int len);
	int SetChFFTDecimateRate(unsigned short ChanNo, int val);
	int SetChFFTPartialPowerSegment(unsigned short ChanNo, unsigned int id, int StartBin, int EndBin);
    BOOL SetChStreamingMode(unsigned short chanNo, BOOL bEnabled, int TrigMode);
    BOOL StartChStreamingInternalTrig(unsigned short chanNo);

    BOOL SetAdg1439(DWORD CardNo, unsigned long dat_l, unsigned long dat_h);
    void DpcmWaveConvert(char* des, char* src, DWORD frm_num);
    void Pcm16bitWaveConvert(char* des, char* src, DWORD frm_num);
    void SetEncoding(unsigned short CardNo, DWORD PackingVer, DWORD FramingVer, DWORD encoding, DWORD bits);
    BOOL GetCardStreamingState(DWORD CardNo, unsigned long *states);
    int OutputChAlarm(DWORD ChNo, DWORD mode);
    int SetCardAlarmTimeout(DWORD CardNo, DWORD ms);
    int StopChAlarm(DWORD ChNo);
    //PWAVETOHIT_STRUCT GetWaveToHitEntry();

};
#endif

