// devintf.h - include file for classes CDeviceInterfaceClass and CDeviceInterface
//=============================================================================
//
// Compuware Corporation
// NuMega Lab
// 9 Townsend West
// Nashua, NH 03060  USA
//
// Copyright (c) 1998 Compuware Corporation. All Rights Reserved.
// Unpublished - rights reserved under the Copyright laws of the
// United States.
//
// U.S. GOVERNMENT RIGHTS-Use, duplication, or disclosure by the
// U.S. Government is subject to restrictions as set forth in 
// Compuware Corporation license agreement and as provided in 
// DFARS 227.7202-1(a) and 227.7202-3(a) (1995), 
// DFARS 252.227-7013(c)(1)(ii)(OCT 1988), FAR 12.212(a) (1995), 
// FAR 52.227-19, or FAR 52.227-14 (ALT III), as applicable.  
// Compuware Corporation.
// 
// This product contains confidential information and trade secrets 
// of Compuware Corporation. Use, disclosure, or reproduction is 
// prohibited without the prior express written permission of Compuware 
// Corporation.
//
//=============================================================================

// This file is for APPLICATIONS, not drivers. It implements two classes:

//
// CDeviceInterfaceClass - this class wraps the call to SetupDiGetClassDevs
// CDeviceInterface - this class wraps the calls to SetupDiEnumDeviceInterfaces and
//                    SetupDiGetInterfaceDeviceDetail
//

// Here is an example:
/*
	static GUID TestGuid = 
	{ 0x4747be20, 0x62ce, 0x11cf, { 0xd6, 0xa5, 0x28, 0xdb, 0x04, 0xc1, 0x00, 0x00 } };

	HANDLE OpenByInterface(GUID* pClassGuid, DWORD instance, PDWORD pError)
	{
		CDeviceInterfaceClass DevClass(pClassGuid, pError);
	
		if (*pError != ERROR_SUCCESS)
			return INVALID_HANDLE_VALUE;
	
		CDeviceInterface DevInterface(&DevClass, instance, pError);
	
		if (*pError != ERROR_SUCCESS)
			return INVALID_HANDLE_VALUE;
	
		cout << "The device path is " << DevInterface.DevicePath() << endl;
	
		HANDLE hDev;
		
		hDev = CreateFile(
			DevInterface.DevicePath(),
			GENERIC_READ | GENERIC_WRITE,
			FILE_SHARE_READ | FILE_SHARE_WRITE,
			NULL,
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,
			NULL
			);
	
		if (hDev == INVALID_HANDLE_VALUE)
			*pError = GetLastError();
	
		return hDev;
	}
*/


#include <setupapi.h>
#include <tchar.h>	// Note UNICODE may not work for Win98??

#define DEVINTF_INLINE inline

//////////////////////////////////////////////////////////////////////////////
// class CDeviceInterfaceClass
//
//##ModelId=4C22CB3C0177
class CDeviceInterfaceClass
{
public:
	//##ModelId=4C22CB3C0178
	CDeviceInterfaceClass(GUID* pClassGuid, PDWORD status);
	//##ModelId=4C22CB3C0188
	~CDeviceInterfaceClass(void);
	//##ModelId=4C22CB3C018A
	GUID* GetGuid(void)      { return &m_Guid; }
	//##ModelId=4C22CB3C01A5
	HDEVINFO GetHandle(void) { return m_hInfo; }

protected:
	//##ModelId=4C22CB3C01A8
	HDEVINFO		m_hInfo;
	//##ModelId=4C22CB3C01B6
	GUID			m_Guid;
};

//////////////////////////////////////////////////////////////////////////////
// class CDeviceInterface
//
//##ModelId=4C22CB3C01BA
class CDeviceInterface
{
public:
	//##ModelId=4C22CB3C01C5
	DEVINTF_INLINE CDeviceInterface( CDeviceInterfaceClass* pClassObject, DWORD Index, PDWORD Error );
	//##ModelId=4C22CB3C01C9
	DEVINTF_INLINE ~CDeviceInterface(void);
	//##ModelId=4C22CB3C01D5
	DEVINTF_INLINE TCHAR* DevicePath(void);

protected:
	//##ModelId=4C22CB3C01D8
	CDeviceInterfaceClass*				m_Class;
	//##ModelId=4C22CB3C01E5
	SP_DEVICE_INTERFACE_DATA			m_Data;
	//##ModelId=4C22CB3C01F5
	PSP_INTERFACE_DEVICE_DETAIL_DATA	m_Detail;
};


//////////////////////////////////////////////////////////////////////////////
// CDeviceInterfaceClass constructor
//
//##ModelId=4C22CB3C0178
DEVINTF_INLINE CDeviceInterfaceClass::CDeviceInterfaceClass(
	GUID* pClassGuid, 
	PDWORD status
	) 
{
	DWORD flags = DIGCF_DEVICEINTERFACE | DIGCF_PRESENT ;
	m_hInfo = INVALID_HANDLE_VALUE;
	ZeroMemory(&m_Guid,sizeof(GUID));

	try
	{
		*status = ERROR_INVALID_PARAMETER;
		m_Guid = *pClassGuid;
		m_hInfo = SetupDiGetClassDevs(pClassGuid, NULL, NULL, flags);

		if ( m_hInfo == INVALID_HANDLE_VALUE )
			*status = GetLastError();
		else
			*status = ERROR_SUCCESS;

	}
	catch (...)
	{
		m_hInfo = INVALID_HANDLE_VALUE;
	}
}

//////////////////////////////////////////////////////////////////////////////
// CDeviceInterfaceClass destructor
//
//##ModelId=4C22CB3C0188
DEVINTF_INLINE CDeviceInterfaceClass::~CDeviceInterfaceClass(void)
{
	if ( m_hInfo != INVALID_HANDLE_VALUE )
		SetupDiDestroyDeviceInfoList(m_hInfo);

	m_hInfo = INVALID_HANDLE_VALUE;
}

//////////////////////////////////////////////////////////////////////////////
// CDeviceInterface constructor
//
//##ModelId=4C22CB3C01C5
DEVINTF_INLINE CDeviceInterface::CDeviceInterface(
	CDeviceInterfaceClass* pClassObject, 
	DWORD Index,
	PDWORD Error
	)
{
	m_Class = pClassObject;

	BOOL status;
	DWORD ReqLen;
	
	m_Detail = NULL;
	m_Data.cbSize = sizeof SP_DEVICE_INTERFACE_DATA;

	try
	{
		*Error = ERROR_INVALID_PARAMETER;

		status = SetupDiEnumDeviceInterfaces(
			m_Class->GetHandle(), 
			NULL, 
			m_Class->GetGuid(), 
			Index, 
			&m_Data
			);

		if ( !status )
		{
			*Error = GetLastError();
			return;
		}					  

		SetupDiGetInterfaceDeviceDetail (
			m_Class->GetHandle(),
			&m_Data,
			NULL,
			0,
			&ReqLen,
			NULL 
			);

		*Error = GetLastError();

		if ( *Error != ERROR_INSUFFICIENT_BUFFER )
			return;

		m_Detail = PSP_INTERFACE_DEVICE_DETAIL_DATA(new char[ReqLen]);

		if ( !m_Detail )
		{
			*Error = ERROR_NOT_ENOUGH_MEMORY;
			return;
		}

		m_Detail->cbSize = sizeof SP_INTERFACE_DEVICE_DETAIL_DATA;

		status = SetupDiGetInterfaceDeviceDetail (
			m_Class->GetHandle(),
			&m_Data,
			m_Detail,
			ReqLen,
			&ReqLen,
			NULL 
			);

		if ( !status )
		{
			*Error = GetLastError();
			delete m_Detail;
			m_Detail = NULL;
			return;
		}
	
		*Error = ERROR_SUCCESS;
	}
	catch (...)
	{
	}
}

//////////////////////////////////////////////////////////////////////////////
// CDeviceInterface destructor
//
//##ModelId=4C22CB3C01C9
DEVINTF_INLINE CDeviceInterface::~CDeviceInterface(void)
{
	if (m_Detail)
	{
		delete m_Detail;
		m_Detail = NULL;
	}
}

//////////////////////////////////////////////////////////////////////////////
// CDeviceInterface::DevicePath
//
//##ModelId=4C22CB3C01D5
DEVINTF_INLINE TCHAR* CDeviceInterface::DevicePath(void)
{
	try
	{
		if ( m_Detail)
			return m_Detail->DevicePath;
		else
			return NULL;
	}
	catch (...)
	{
		return NULL;
	}

}

