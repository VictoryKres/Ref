#include <stdio.h>
#include "UsbaeHardware16BitNew.h"



#ifdef _DEBUG
__declspec(dllexport) void _stdcall WriteMainboardRegister(short ChassisId,UCHAR addr, UINT value);
__declspec(dllexport) void _stdcall ReadMainboardRegister(short ChassisId, UCHAR addr, UINT *value);
#else
extern void WriteMainboardRegister(short ChassisId,UCHAR addr, UINT value);
extern void ReadMainboardRegister(short ChassisId, UCHAR addr, UINT *value);
#endif // _DEBUG



extern DWORD  WINAPI InterruptAttachThreadLocalInt( LPVOID pParam );
extern BOOL SetCardNumberNo(unsigned short index, UCHAR CardNO);

const U32 ChRegBaseAddrs[] = {PROP_CH0_REG_BASEADDR, PROP_CH1_REG_BASEADDR, PROP_CH2_REG_BASEADDR
, PROP_CH3_REG_BASEADDR, PROP_CH4_REG_BASEADDR, PROP_CH5_REG_BASEADDR};

#ifndef enStreamingTrigSrc
//���������ɼ�����Դ
enum enStreamingTrigSrc
{
    enStreamTrigSrcInternal,    //�ڲ�����
    enStreamTrigSrcExternal,    //�ⲿ����
    enStreamTrigSrcThreshold,   //���޴���
};
#endif

//ȡ����ֵx��������1�ĸ���
extern unsigned long GetOneCount(unsigned long x);

#define SOUNDWEL_VID         0x01037085
#define USB_HUB_16BIT_NEW_PID    0x0107


static __inline void TRACE(char *fmt, ...)
{
	va_list args;
	char buf[1024];
	va_start(args, fmt);
	vsprintf(buf, fmt, args);
	OutputDebugString(buf);
	// FILE *fp = fopen("d:\\test.txt","a");
	// fwrite(buf,strlen(buf),1,fp);
	// fclose(fp);
}


UsbaeHardware16BitNew::UsbaeHardware16BitNew()
{
    int i, j;

	rawBuf = new char[MAX_RAWDATA_BUF_LENGTH];
    recvbuffer = new UCHAR[BLOCK_BUFFER_SUM_SIZE];
	paraBuf = new PARAM[MAX_PARAM_BUF_LENGTH];
    fftBuf = new char[MAX_FFTDATA_BUF_LENGTH];

	memset(&hEventArray, 0, sizeof(hEventArray));
	SampleLen = 1024;
	paraMutex = CreateMutex(NULL, FALSE, NULL);
	rawMutex = CreateMutex(NULL, FALSE, NULL);
    fftMutex = CreateMutex(NULL, FALSE, NULL);
	bOpenCardStatus = FALSE;
    bQueryCardStatus = FALSE;
	exParamEn = FALSE;
	fftEn = FALSE;
	usbGain = 0;
	usbChNum = 4; 

	FirFilterOrder = FIR_ORDER;

	memset(mb_ver, 0, sizeof(mb_ver));
	memset(card_ver, 0, sizeof(card_ver));

    WaveThreshold = new U32[MAX_CARDNUM * CHANNEL_NUMBER_PERCARD];

    for (i = 0; i < MAX_CARDNUM; i++)
    {
        bFrmDecodeCompleted[i] = TRUE;
        PackVer[i] = 0;
        FrmVer[i] = 0;
        FrmEncodeType[i] = enDpcm;
        FrmDpcmBits[i] = 0x0d;
        PackId[i] = 0;
        PackOfFrm[i] = 0;
        PackInFrm[i] = 0;
        for (j = 0; j < CHANNEL_NUMBER_PERCARD; j++)
        {
            WaveThreshold[i * CHANNEL_NUMBER_PERCARD + j] = 0;
            //HitThreshold[i * MAX_CARDNUM + j] = 0;
        }
    }

    bStartStreamingInternalTrig = new BOOL[MAX_CARDNUM * CHANNEL_NUMBER_PERCARD];
    memset(bStartStreamingInternalTrig, 0, MAX_CARDNUM * CHANNEL_NUMBER_PERCARD * sizeof(BOOL));

	bChEnabled = new BOOL[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 2];
    memset( bChEnabled, 0, sizeof(BOOL) * (MAX_CARDNUM*CHANNEL_NUMBER_PERCARD+2) );

    WthMdl = WaveToHitCreate();
    bHardParam = TRUE;
    memset(bParamEn, 0, sizeof(bParamEn));
    if (!bHardParam)
    {
        hWaveToHitSemaph = CreateSemaphore(NULL, 1, 1, NULL);
    }
    else
    {
        hWaveToHitSemaph = NULL;
    }
}

UsbaeHardware16BitNew::~UsbaeHardware16BitNew()
{
	bQueryCardStatus = FALSE;
	int i;
	if(paraMutex)
    {
		CloseHandle(paraMutex);
        paraMutex = NULL;
    }
	if(rawMutex)
    {
		CloseHandle(rawMutex);	
        rawMutex = NULL;
    }
	if (fftMutex)
	{
		CloseHandle(fftMutex);	
		fftMutex = NULL;
	}
	
	for (i=0;i<MAX_CARDNUM*2;i++)
	{
		if (hEventArray[i])
		{
			CloseHandle(hEventArray[i]);
			hEventArray[i]=NULL;
		}
	}

	for (i=0;i<MAX_CARDNUM*CHANNEL_NUMBER_PERCARD+2;i++)
	{
		chParamFIFO[i].ReleaseBuf();
	}

	if(rawBuf)
		delete []rawBuf;
	if(recvbuffer)
		delete []recvbuffer;
    if (fftBuf)
    {
        delete []fftBuf;
    }
	if (paraBuf)
	{
		delete []paraBuf;
	}

    if (bStartStreamingInternalTrig)
    {
        delete []bStartStreamingInternalTrig;
    }

    if (WaveThreshold)
    {
        delete []WaveThreshold;
    }
	if (ThreadHandle)
	{
		CloseHandle(ThreadHandle);
		ThreadHandle = NULL;
	}

	if (bChEnabled)
    {
        delete []bChEnabled;
        bChEnabled = NULL;
    }

    WaveToHitCleanup(WthMdl);
    WthMdl = NULL;

    if ((!bHardParam) && hWaveToHitSemaph)
    {
        CloseHandle(hWaveToHitSemaph);
        hWaveToHitSemaph = NULL;
    }
}

BOOL UsbaeHardware16BitNew::SetExnTrig(unsigned short CardNo, BOOL bStatus)
{

	return FALSE;
}

UINT UsbaeHardware16BitNew::GetVersionConf(unsigned short cardNo)
{
	UINT regvalue;
	if(cardNo >= MAX_CARDNUM)
		return FALSE;
    ReadRegister(cardNo, FW_VER_REG, &regvalue);
	return regvalue;
}

/*++
����:
	���ð忨ʱ��֡����ʱ������Ӳ����ÿ���̶�ʱ�䣬����һ��ʱ��֡
����:
	__in  CardNo   - ����
	__in  sysTimer - ʱ��֡�������(��λ��100ns)
����ֵ:
	��ȷ���� TRUE
	���󷵻� FALSE		
--*/
BOOL UsbaeHardware16BitNew::EnableSysTimer(unsigned short cardNo, DWORD sysTimer)
{
	if(cardNo >= MAX_CARDNUM)
		return FALSE;

    //sysTimer = 0;

    GLB_TIMESCALE_PROP RegVal;

    if (sysTimer > 0)
    {
        RegVal.spec.timeout = sysTimer;
        RegVal.spec.EnTimebaseFrm = 1;
    }
    else
    {
        RegVal.spec.EnTimebaseFrm = 0;
    }

    WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_TIMESCALE_REG, RegVal.cmd);

	return TRUE;
}

BOOL UsbaeHardware16BitNew::GetCardDriverVersion(unsigned short cardNo, PEZUSB_DRIVER_VERSION pDriverVersion)
{
    return FALSE;
}

/*++
����:
	������Σ�������ȫ��������üĴ���
	��������
	FPGA�������Ƶ�ʹ�ʽΪ��80M/128/
����:
	__in  CardNo		   - ����
	__in  dwExparamAttri   - ��ֵ����16λ�忨ʱ��ֵ�����ڴ�����λ����
		����λ��0  - 3  ��Ƶϵ��;
				4  - 7  �������;
				9       ��ι���ʹ��λ��δ�ã�
				16 - 27 ���ͨ��ʹ�ܱ�־����12�����ͨ�����ڴ�ÿ�ſ���4�����ͨ��������3�ſ���;
����ֵ:
	��ȷ���� TRUE
	���󷵻� FALSE
--*/
BOOL UsbaeHardware16BitNew::SetExparamAttri(unsigned short cardNo, DWORD dwExparamAttri)
{
	if(cardNo >= MAX_CARDNUM)
		return FALSE;
	GLB_EXPARAM_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.ExparamADC = 80 *( dwExparamAttri & 0x0000000F);
	RegVal.spec.ExparamEn = dwExparamAttri >> (16 + 4*cardNo);
	RegVal.spec.ExparamGain = dwExparamAttri >> 4;
	if (RegVal.spec.ExparamEn != 0)
	{
		exParamEn = TRUE;
	}
	switch(RegVal.spec.ExparamGain)
	{
	case 0:
		RegVal.spec.ExparamGain = 4;
		break;
	case 1 :
		RegVal.spec.ExparamGain = 2;
		break;
	case 2:
		RegVal.spec.ExparamGain = 8;
		break;
	case  3:
		RegVal.spec.ExparamGain = 1;
		break;
	default:
		break;
	}
	WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_EXPARAM_REG , RegVal.cmd);
	return TRUE;
}

/*++
����:
	������γ�ʱ���ԼĴ���
����:
	__in  chanNo      - ͨ����
	__in  outInterval - ��γ�ʱʱ��
����ֵ:
	��ȷ���� TRUE
	���󷵻� FALSE		
--*/
BOOL UsbaeHardware16BitNew::SetExparamFixed(unsigned short chanNo, DWORD outInterval)
{
    unsigned short	cardNo;

	cardNo = chanNo/CHANNEL_NUMBER_PERCARD;
	chanNo = chanNo%CHANNEL_NUMBER_PERCARD;
	if(cardNo >= MAX_CARDNUM || bDeviceOpenFlag[cardNo] == FALSE)
		return FALSE;

    //WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_EPFIXEDTIME_REG, (DWORD)(outInterval*1000000/12.5));
    WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_EPFIXEDTIME_REG, (DWORD)(outInterval*80000));

	return TRUE;
}

/*++
����:
	����ͨ������ģʽ
����:
	__in  chanNo    - ͨ����
	__in  mode      - ����ģʽ
					  SAMPLE_MODE_NORMAL    0
					  SAMPLE_MODE_PRE       1
					  SAMPLE_MODE_POST      2
	__in  SampleSum - ������ʱ����
����ֵ:
	��ȷ���� TRUE
	���󷵻� FALSE		
--*/
BOOL UsbaeHardware16BitNew::SetSampleMode(unsigned short chanNo, int mode, int SampleSum )
{
    short	cardNo;
	UINT regValue;

	cardNo = chanNo/CHANNEL_NUMBER_PERCARD;
	chanNo = chanNo%CHANNEL_NUMBER_PERCARD;
	if(cardNo >= MAX_CARDNUM || bDeviceOpenFlag[cardNo] == FALSE)
		return FALSE;
	
    CH_SAMP_MODE_PROP RegVal;

    ReadRegister(cardNo, ChRegBaseAddrs[chanNo] + PROP_CH_SAMP_MODE_REG, (unsigned int*)&RegVal.cmd);
    switch (mode)
    {
    case 1:
        RegVal.spec.PreCaptureEn = 1;
        RegVal.spec.PostCaptureEn = 0;
        RegVal.spec.TrigDelay = SampleSum;
        break;
    case 2:
        RegVal.spec.PreCaptureEn = 0;
        RegVal.spec.PostCaptureEn = 1;
        RegVal.spec.TrigDelay = SampleSum;
        break;
    default:
        RegVal.spec.PreCaptureEn = 0;
        RegVal.spec.PostCaptureEn = 0;
        break;
    }

    WriteRegister(cardNo, ChRegBaseAddrs[chanNo] + PROP_CH_SAMP_MODE_REG, RegVal.cmd);
	return TRUE;
}

BOOL UsbaeHardware16BitNew::SetFilterGain(unsigned short chanNo, unsigned short filter, unsigned short gain)
{
	short	cardNo;
	
	cardNo = chanNo/CHANNEL_NUMBER_PERCARD;
	chanNo = chanNo%CHANNEL_NUMBER_PERCARD;
	if(cardNo >= MAX_CARDNUM || bDeviceOpenFlag[cardNo] == FALSE)
		return FALSE;

	UCHAR	bufOutput[33];
    UCHAR  m_ch_l,m_ch_h;

	bufOutput[0] = 1 ;
    
	if(filter < 4) {
		m_ch_l = (UCHAR)filter;
		m_ch_h = 0;
	}else if(filter < 7){
		m_ch_l = filter - 3;
		m_ch_h = 1;	
	}else if(filter < 9){
		m_ch_l = filter - 5;
		m_ch_h = 2;	
	}
	else {
		m_ch_l = 3;
		m_ch_h = 3;		
	}
	   
	bufOutput[1] = m_ch_l +1 ;
	bufOutput[2] = m_ch_h +1 ;
	bufOutput[3] = gain+1 ;

	memcpy(&bufOutput[4], &bufOutput[1], 3);
	bufOutput[7] = chanNo ;							

	USBWriteEP(cardNo,0,8,bufOutput);		
	
    GLB_START_CMD CfgCmd;
    CfgCmd.cmd = 0;
    CfgCmd.spec.StartAnalog = 1;
	
    WriteRegister(cardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_START_REG, CfgCmd.cmd);
	
	return TRUE;
}

BOOL UsbaeHardware16BitNew::SetCardFilterGain(unsigned short CardNo, unsigned short ch0_filter, unsigned short ch0_gain,
											  unsigned short ch1_filter, unsigned short ch1_gain)
{
	UCHAR	bufOutput[33];
	short	cardNo = CardNo;
	UCHAR  m_ch_l,m_ch_h;
	
    unsigned short filter;
	unsigned short gain;
	
    if(CardNo >= MAX_CARDNUM)
        return FALSE;
	
	bufOutput[0] = 1 ;
    
    UINT val = 0;

	//step1���ȼ���ֱ��ƫ��
	//ͨ��2
    filter = ch1_filter;
    gain = 3;	//GND
	
    if(filter < 4) {
        m_ch_l = (UCHAR)filter;
        m_ch_h = 0;
    }else if(filter < 7){
        m_ch_l = filter - 3;
        m_ch_h = 1;	
    }else if(filter < 9){
        m_ch_l = filter - 5;
        m_ch_h = 2;	
    }
    else {
        m_ch_l = 3;
        m_ch_h = 3;		
    }
	
    bufOutput[4] = m_ch_l +1 ;
    bufOutput[5] = m_ch_h +1 ;
    bufOutput[6] = gain+1 ;
	
	
    //ͨ��1
    filter = ch0_filter;
    gain = 3;	//GND
	
    if(filter < 4) {
        m_ch_l = (UCHAR)filter;
        m_ch_h = 0;
    }else if(filter < 7){
        m_ch_l = filter - 3;
        m_ch_h = 1;	
    }else if(filter < 9){
        m_ch_l = filter - 5;
        m_ch_h = 2;	
    }
    else {
        m_ch_l = 3;
        m_ch_h = 3;		
    }
	
    bufOutput[1] = m_ch_l +1 ;
    bufOutput[2] = m_ch_h +1 ;
    bufOutput[3] = gain+1 ;
	
	if (-1 == USBWriteEP(cardNo,0,8,bufOutput))
	{
		return FALSE;
	}
	
	GLB_START_CMD CfgCmd;
    CfgCmd.cmd = 0;
    CfgCmd.spec.StartAnalog = 1;
	
    WriteRegister(cardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_START_REG, CfgCmd.cmd);

	//�ȴ�ֱ��ƫ���������
    GLB_AD_STAT AdStat;
	AdStat.cmd = 0;
	ReadRegister(cardNo, STAT_GLB_REG_BASEADDR + STAT_GLB_AD_REG, (unsigned int*)&AdStat.cmd);

	WriteRegister(cardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_START_REG, CfgCmd.cmd);
	ReadRegister(cardNo, STAT_GLB_REG_BASEADDR + STAT_GLB_AD_REG, (unsigned int*)&AdStat.cmd);

	WriteRegister(cardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_START_REG, CfgCmd.cmd);
	ReadRegister(cardNo, STAT_GLB_REG_BASEADDR + STAT_GLB_AD_REG, (unsigned int*)&AdStat.cmd);


//     while (1)
//     {
//         ReadRegister(cardNo, STAT_GLB_REG_BASEADDR + STAT_GLB_AD_REG, (unsigned int*)&AdStat.cmd);
//         if (AdStat.spec.DcOffsetRdy)
//         {
//             break;
//         }
//     }

	//step2������ģ������
    //ͨ��2
    filter = ch1_filter;
    gain = ch1_gain;
	
    if(filter < 4) {
        m_ch_l = (UCHAR)filter;
        m_ch_h = 0;
    }else if(filter < 7){
        m_ch_l = filter - 3;
        m_ch_h = 1;	
    }else if(filter < 9){
        m_ch_l = filter - 5;
        m_ch_h = 2;	
    }
    else {
        m_ch_l = 3;
        m_ch_h = 3;		
    }
	
    bufOutput[4] = m_ch_l +1 ;
    bufOutput[5] = m_ch_h +1 ;
    bufOutput[6] = gain+1 ;

	
    //ͨ��1
    filter = ch0_filter;
    gain = ch0_gain;
	
    if(filter < 4) {
        m_ch_l = (UCHAR)filter;
        m_ch_h = 0;
    }else if(filter < 7){
        m_ch_l = filter - 3;
        m_ch_h = 1;	
    }else if(filter < 9){
        m_ch_l = filter - 5;
        m_ch_h = 2;	
    }
    else {
        m_ch_l = 3;
        m_ch_h = 3;		
    }
	
    bufOutput[1] = m_ch_l +1 ;
    bufOutput[2] = m_ch_h +1 ;
    bufOutput[3] = gain+1 ;

	USBWriteEP(cardNo,0,8,bufOutput);

    CfgCmd.cmd = 0;
    CfgCmd.spec.StartAnalog = 1;
	
    WriteRegister(cardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_START_REG, CfgCmd.cmd);

	//�ȴ�ģ���������
	AdStat.cmd = 0;
	ReadRegister(cardNo, STAT_GLB_REG_BASEADDR + STAT_GLB_AD_REG, (unsigned int*)&AdStat.cmd);

	WriteRegister(cardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_START_REG, CfgCmd.cmd);
	ReadRegister(cardNo, STAT_GLB_REG_BASEADDR + STAT_GLB_AD_REG, (unsigned int*)&AdStat.cmd);

	WriteRegister(cardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_START_REG, CfgCmd.cmd);
	ReadRegister(cardNo, STAT_GLB_REG_BASEADDR + STAT_GLB_AD_REG, (unsigned int*)&AdStat.cmd);
//     while (1)
//     {
//         ReadRegister(cardNo, STAT_GLB_REG_BASEADDR + STAT_GLB_AD_REG, (unsigned int*)&AdStat.cmd);
//         if (AdStat.spec.AnalogRdy)
//         {
//             break;
//         }
//     }

	return TRUE;
}

BOOL UsbaeHardware16BitNew::SetCardSample(unsigned short CardNo, BOOL bStatus)
{    
    UINT regvalue,value;
	if(CardNo >= MAX_CARDNUM)
		return FALSE;

    CH_AD_PROP RegVal;

    int i;

    for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
    {
        ReadRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_AD_REG, (unsigned int*)&RegVal.cmd);
        
        if(bStatus)
            RegVal.spec.run = 1;
        else
            RegVal.spec.run = 0;
        
        WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_AD_REG, RegVal.cmd);
    }
	
	return TRUE;
}

BOOL UsbaeHardware16BitNew::SetCardPause(unsigned short CardNo, BOOL bStatus)
{
	if(CardNo >= MAX_CARDNUM)
		return FALSE;
	
	CH_FUNC_PROP RegVal;
	for (int i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
    {
        ReadRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
        if(bStatus)
            RegVal.spec.AdEn = 0;  //������ͣ����    
        else
            RegVal.spec.AdEn = 1;  //ȡ����ͣ����
		
        WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, RegVal.cmd);
    }

	static DWORD ExparaEnOld = 0;
	GLB_EXPARAM_PROP ExRegVal;
	ReadRegister(CardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_EXPARAM_REG, (unsigned int*)&ExRegVal.cmd);
	if (bStatus)
	{		
		ExparaEnOld = ExRegVal.spec.ExparamEn;
		ExRegVal.spec.ExparamEn = 0;
	}
	else
		ExRegVal.spec.ExparamEn = ExparaEnOld;
	WriteRegister(CardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_EXPARAM_REG , ExRegVal.cmd);

	return TRUE;
    /*CH_AD_PROP RegVal;
    int i;

    for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
    {
        ReadRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_AD_REG, (unsigned int*)&RegVal.cmd);
        if(bStatus)
            RegVal.spec.run = 0;  //������ͣ����    
        else
            RegVal.spec.run = 1;  //ȡ����ͣ����

        WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_AD_REG, RegVal.cmd);
    }*/
}

BOOL UsbaeHardware16BitNew::SetCardSelectLight(unsigned short CardNo, WORD bSelect)
{
	return FALSE;
}

BOOL UsbaeHardware16BitNew::SetCardEnableWaveformParam(unsigned short CardNo, WORD EnableWavefrom, WORD EnableParam)
{
	UINT regvalue,value;

	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
		return FALSE;

    CH_FUNC_PROP RegVal;
    int i;

    for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
    {
        ReadRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);

        if (EnableWavefrom & (1 << i))
        {
            RegVal.spec.ThresholdWaveEn = 1;
        }
        else
        {
            RegVal.spec.ThresholdWaveEn = 0;
        }

        if (EnableParam & (1 << i))
        {
            if (bHardParam)
            {
                RegVal.spec.ThresholdHitEn = 1;
                bParamEn[CardNo * CHANNEL_NUMBER_PERCARD + i] = FALSE;
            }
            else
            {
                RegVal.spec.ThresholdHitEn = 0;
                bParamEn[CardNo * CHANNEL_NUMBER_PERCARD + i] = TRUE;
            }
        }
        else
        {
            RegVal.spec.ThresholdHitEn = 0;
            bParamEn[CardNo * CHANNEL_NUMBER_PERCARD + i] = FALSE;
        }

        RegVal.spec.AdEn = 1;

        WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_FUNCTION_REG, RegVal.cmd);
    }

    return TRUE;
}

/*--------------------
Set Sameple length

Format for register : AE_SAMPLE_LENGTH_FREQ0
reg[31:8]   --> sample Length, unit byte
reg[7:0]    --> sample freq factor
             Actually sample Freq = 40M /(2 *(reg[7:0] + 1))
---------------------------*/
BOOL UsbaeHardware16BitNew::SetCardSampleLength(unsigned short  CardNo, DWORD value)
{
    CH_SAMPLEN_PROP RegVal;
    RegVal.cmd = 0;
    RegVal.spec.SampLen = value;
#ifdef STREAMING_DEBUG
    SampleLength = value;
#endif

	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
		return FALSE;

    int i;
    for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
    {
        WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_SAMP_LEN_REG, RegVal.cmd);
    }

	return TRUE;
}

BOOL UsbaeHardware16BitNew::GetCardSampleFreq(unsigned short CardNo, WORD *value)
{
    CH_SAMPRATE_PROP RegVal;
    RegVal.cmd = 0;
    //RegVal.spec.SampRate = value;
    
    
    if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
        return FALSE;
    
    int i;
    for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
    {
        RegVal.cmd = 0;
        ReadRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_SAMP_RATE_REG, (UINT*)&RegVal.cmd);
        
        if (RegVal.spec.SampRate == 0)
        {
            return FALSE;
        }
    }
    
    *value = RegVal.spec.SampRate;

#ifdef STREAMING_DEBUG
    SampleCycle = 25 * (*value);//ns
#endif    
    return TRUE;

}

/*--------------------
Set Sameple Freq

Format for register : AE_SAMPLE_LENGTH_FREQ0
reg[31:8]   --> sample Length, unit byte
reg[7:0]    --> sample freq factor
             Actually sample Freq = 40M /(2 *(reg[7:0] + 1))
---------------------------*/
BOOL UsbaeHardware16BitNew::SetCardSampleFreq(unsigned short  CardNo, WORD value)
{
    CH_SAMPRATE_PROP RegVal;
    RegVal.cmd = 0;
    RegVal.spec.SampRate = value;
#ifdef STREAMING_DEBUG
    SampleCycle = 25 * value;//ns
#endif

	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
		return FALSE;

    int i;
    for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
    {
        WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_SAMP_RATE_REG, RegVal.cmd);
    }

	return TRUE;
}

BOOL UsbaeHardware16BitNew::SetCardParamEventInterval(unsigned short  CardNo, DWORD value)
{
	UINT regvalue;
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
		return FALSE;
	CH_EVEINTER_CFG_PROP RegVal;
	int i;
	for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
	{
		RegVal.spec.hdt = value;
		WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_EVENT_INTERVAL_REG, RegVal.cmd);
	}
	return TRUE;
}

BOOL UsbaeHardware16BitNew::SetCardParamEventLockOut(unsigned short  CardNo, DWORD value)
{
  	UINT regvalue;
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
		return FALSE;
	
	CH_LOCKOUT_CFG_PROP RegVal;
	int i;
	for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
	{
		RegVal.spec.hlt = value;
		WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_LOCKOUT_CFG_REG, RegVal.cmd);
	}
	return TRUE;
}

BOOL UsbaeHardware16BitNew::SetCardParamEventPdt(unsigned short CardNo, DWORD value)
{
	UINT regvalue;
	
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return FALSE;
	}
	
	CH_PDT_CFG_PROP RegVal;
	int i;
	
	for (i = 0; i < CHANNEL_NUMBER_PERCARD; i++)
	{
		RegVal.spec.pdt = value;
		WriteRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_PDT_REG, RegVal.cmd);
		
		RegVal.cmd = 0;
		ReadRegister(CardNo, ChRegBaseAddrs[i] + PROP_CH_PDT_REG, (unsigned int *)&RegVal.cmd);
	}
	
	return TRUE;
}

BOOL UsbaeHardware16BitNew::SetCardParamThreshold(unsigned short chanNo, DWORD value)
{
	unsigned short CardNo;
	CardNo = chanNo /CHANNEL_NUMBER_PERCARD;
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
		return FALSE;

    CH_HIT_THRESHOLD_PROP RegVal;
    RegVal.cmd = 0;
    RegVal.spec.threshold = (value<<2);//�˴�FPGA����ֲ��18λ���ʼ򻯲���������16λת��18λ������ȥ

    WriteRegister(CardNo, ChRegBaseAddrs[chanNo % CHANNEL_NUMBER_PERCARD] + PROP_CH_HIT_THRESHOLD_REG, RegVal.cmd);

	return TRUE;
}

BOOL UsbaeHardware16BitNew::SetCardSampleThreshold(unsigned short chanNo, DWORD value)
{
	UINT regvalue;

	unsigned short CardNo;
	CardNo = chanNo /CHANNEL_NUMBER_PERCARD;
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE )
		return FALSE;

    CH_WAVE_THRESHOLD_PROP RegVal;
    RegVal.cmd = 0;
    RegVal.spec.threshold = (value<<2);//�˴�FPGA����ֲ��18λ���ʼ򻯲���������16λת��18λ������ȥ

    WriteRegister(CardNo, ChRegBaseAddrs[chanNo % CHANNEL_NUMBER_PERCARD] + PROP_CH_WAVE_THRESHOLD_REG, RegVal.cmd);

    WaveThreshold[chanNo] = value;
 
	return TRUE;
}

/*--------------------
Issue Pluse , namely AST function
Description:
chan:    Pluse Channel NO
TrigPara[7:0] --   Pluse Number
TrigPara[15:8] --  PluseWidth ,Unit 1us;
TrigPara[23:16] -- PluseInter, Unit 50ms;
TrigPara[31:24] -- Not used
---------------------------*/
BOOL UsbaeHardware16BitNew::OnPluseTrig(int chanNo,int TrigPara)
{
	short	cardNo;
	UINT	Trigvalue;
	UINT    regValue;

	cardNo = chanNo/CHANNEL_NUMBER_PERCARD;
	chanNo = chanNo%CHANNEL_NUMBER_PERCARD;
	if(cardNo >= MAX_CARDNUM || chanNo < 0)
		return FALSE;

	if(cardNo >= MAX_CARDNUM || bDeviceOpenFlag[cardNo] == FALSE)
	{
		return -1;
	}

    //AST����
    GLB_AST_PROP RegVal;
    RegVal.cmd = 0;
    RegVal.spec.ch = (0x1 << chanNo);
    RegVal.spec.PulseNo = TrigPara & 0xFF;
    RegVal.spec.PulseWid = (TrigPara >> 8) & 0xFF;
    RegVal.spec.PulseInt = (TrigPara >> 16) & 0xFF;
    WriteRegister(cardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_AST_REG, RegVal.cmd);

    //����AST
    GLB_START_CMD RegCmd;
    RegCmd.cmd = 0;
    RegCmd.spec.StartAst = 1;
    WriteRegister(cardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_START_REG, RegCmd.cmd);

    //�ȴ�AST����
    GLB_AST_STAT AstStat;
    AstStat.cmd = 0;
    AstStat.spec.completed = COMPLETED;
    do 
    {
        ReadRegister(cardNo, STAT_GLB_REG_BASEADDR + STAT_GLB_AST_REG, (unsigned int *)&AstStat.cmd);
    } while (COMPLETED != AstStat.spec.completed);
	return TRUE;
}


BOOL UsbaeHardware16BitNew::OnPluseTrigStop(int chanNo)
{
	short	cardNo;
	UINT    regValue,regValueOld;

	cardNo = chanNo/CHANNEL_NUMBER_PERCARD;
	chanNo = chanNo%CHANNEL_NUMBER_PERCARD;
	if(cardNo >= MAX_CARDNUM || chanNo < 0)
		return FALSE;
	return TRUE;
}

DWORD UsbaeHardware16BitNew::GetCardStatus(BOOL *bDeviceFlag, BOOL reset)
{
    int OpenCardNum = 0;

	if(bDeviceFlag)
		memset(bDeviceFlag,0,MAX_CARDNUM*sizeof(BOOL));
	memset(&bDeviceStaus,0,MAX_CARDNUM*sizeof(BOOL));

	memset(card_ver, 0, sizeof(card_ver));

	int i;
	ZT_PCIBOARD zt;
    for(i =0; i < MAX_CARDNUM; i++){
		zt.lIndex = i;
		if(OpenUSB7kC(&zt) == 0){
            //ʶ��PID&VID
            UINT vid;
            PID_STAT pid;

            ReadRegister(zt.nChNo, VID_REG, &vid);
            ReadRegister(zt.nChNo, PID_REG, (unsigned int *)&pid.cmd);
            if ((vid == SOUNDWEL_VID) && (pid.spec.pid == USB_HUB_16BIT_NEW_PID))
            {
                if(bDeviceFlag)
                    bDeviceFlag[zt.nChNo] = TRUE;
                bDeviceStaus[zt.nChNo] = TRUE;
                OpenCardNum++;

				if (reset)
				{
					UCHAR bufOutput[32];
					memset(bufOutput, 0, sizeof(bufOutput));
					bufOutput[0] = 11 ;				//RST_FPGA
					USBWriteEP(zt.nChNo,0,8,bufOutput);
					bufOutput[0] = 12 ;
					USBWriteEP(zt.nChNo,0,8,bufOutput);
					//reset fifo
					bufOutput[0] = 3 ;
					USBWriteEP(zt.nChNo,0,8,bufOutput);

				}

                CARD_FEATURE_STAT ftrst;
                ftrst.cmd = 0;

                ReadRegister(zt.nChNo, STAT_FEATURE_REG, (unsigned int*)&ftrst.cmd);

//                 CARD_FEATURE_PROP ftrprp;
//                 ftrprp.cmd = 0;
//                 ftrprp.spec.ParamFeature = 0;
//                 WriteRegister(zt.nChNo, PROP_FEATURE_REG, ftrprp.cmd);
// 
//                 ftrst.cmd = 0;
//                 ReadRegister(zt.nChNo, STAT_FEATURE_REG, (unsigned int*)&ftrst.cmd);

                if (ftrst.sepc.ParamFeature)
                {
                    bHardParam = True;
                }
                else
                {
                    bHardParam = False;
                }
				//bHardParam = True;

				ReadRegister(zt.nChNo, FW_VER_REG, &card_ver[zt.nChNo]);
            }

			CloseUSB7kC(zt.nChNo);
		}
	}

    if ((!bHardParam) && (!hWaveToHitSemaph))
    {
        hWaveToHitSemaph = CreateSemaphore(NULL, 1, 1, NULL);
    }

    bQueryCardStatus = TRUE;
	//return 0;
	return OpenCardNum;
}

void UsbaeHardware16BitNew::ConfigDDR(short nIndex)
{

}

void UsbaeHardware16BitNew::OpenCard(BOOL *bDeviceFlag, DWORD SampleLength, BOOL reset)
{
    UCHAR bufOutput[32];
    DWORD dwOpenSum = 0;
	UINT regvalue=0;
	int i;

 
	if(bOpenCardStatus)
		return;
	bOpenCardStatus = TRUE;

    if(bQueryCardStatus == FALSE) {
	   GetCardStatus(NULL, FALSE);
	   bQueryCardStatus = TRUE;
	}


	for(i =0; i < MAX_CARDNUM; i++){
		// device is exist and to be opened
		if(bDeviceStaus[i] && bDeviceFlag[i] && OpenUSB7kC_ByCardNo(i) == 0)
		{
			if (reset)
			{
			bufOutput[0] = 11 ;				//RST_FPGA
			USBWriteEP(i,0,8,bufOutput);
			bufOutput[0] = 12 ;
			USBWriteEP(i,0,8,bufOutput);
            //reset fifo
            bufOutput[0] = 3 ;
			USBWriteEP(i,0,8,bufOutput);
			}
			dwOpenSum ++;
			bDeviceOpenFlag[i] = TRUE;
			//	ConfigDDR(i);


            //����ȫ�ֳɰ����ԼĴ���
            GLB_PKG_PROP PkgCfg;
            PkgCfg.cmd = 0;
            PkgCfg.spec.ver = PackVer[i];
            WriteRegister(i, PROP_GLB_REG_BASEADDR + PROP_GLB_PKG_REG, PkgCfg.cmd);

            //����ȫ�ֳ�֡���ԼĴ���
			ParamType = 0;
            GLB_FRM_PORP FrmCfg;
            FrmCfg.cmd = 0;
			FrmCfg.spec.TimeFrmEncode = ParamType;
            FrmCfg.spec.HitFrmEncode = ParamType;
            FrmCfg.spec.WaveFrmEncode = FrmEncodeType[i];
            FrmCfg.spec.ver = FrmVer[i];
            WriteRegister(i, PROP_GLB_REG_BASEADDR + PROP_GLB_FRM_REG, FrmCfg.cmd);
            //����ȫ��DPCM�������ԼĴ���
            GLB_DPCM_PROP RegVal;
            RegVal.cmd = 0;
            RegVal.spec.bits = FrmDpcmBits[i];
            WriteRegister(i, PROP_GLB_REG_BASEADDR + PROP_GLB_DPCM_REG, RegVal.cmd);
		}
		else 
			bDeviceOpenFlag[i] = FALSE;
	}
	openCardNum = dwOpenSum;
	SampleLen = SampleLength;
	curRawBufLength = 0;
	//curParaBufLength = 0;
	
	//Ϊͨ��chParamFIFO����ռ�
	//mengliang 2015-5-13 edit for ��¼ÿ��ͨ������buff�Ĵ�С
	if(dwOpenSum > 0)
		perCardParabufLength = HIT_PARAM_BUF_LENGTH/(dwOpenSum*CHANNEL_NUMBER_PERCARD);
	if (dwOpenSum != 0)
	{
		for (i=0;i<MAX_CARDNUM*CHANNEL_NUMBER_PERCARD;i++)
		{
			chParamFIFO[i].ReleaseBuf();
			if (bDeviceOpenFlag[i/CHANNEL_NUMBER_PERCARD])		
			{
				chParamFIFO[i].AllocateBuf(perCardParabufLength);
				bChEnabled[i] = TRUE;
			}
			else
            {
                bChEnabled[i] = FALSE;
            }
		}
		chParamFIFO[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD    ].ReleaseBuf();
		chParamFIFO[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1].ReleaseBuf();
		chParamFIFO[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1   ].AllocateBuf(SYSTIME_PARAM_BUF_LENGTH);
		chParamFIFO[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD ].AllocateBuf(EXP_PARAM_BUF_LENG);
		bChEnabled[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD    ] = TRUE;
		bChEnabled[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1] = TRUE;
	}

    switch (FrmVer[0])
    {
    case 1:
        switch (FrmEncodeType[0])
        {
        case en16BitsPcm:
            singleChannelRawDataLen = 0;
            break;
        case en18BitsPcm:
            singleChannelRawDataLen = 0;
            break;
        case en18BitsMixed:
            singleChannelRawDataLen = 0;
            break;
        case enDpcm:
            singleChannelRawDataLen = 0;
            break;
        case enOneBitDpcm:
            singleChannelRawDataLen = 0;
            break;
        default:
            singleChannelRawDataLen = 0;
        }
        singleChannelBufLen = 0;
        break;
    case 0:
    default:
        switch (FrmEncodeType[0])
        {
        case en16BitsPcm:
            singleChannelRawDataLen = (SampleLen << 1 ) + 8;
            break;
        case en18BitsPcm:
			singleChannelRawDataLen = (SampleLen << 1 ) + 8;
 //           singleChannelRawDataLen = (SampleLen * 18 + 7) / 8 + 8;
            break;
        case en18BitsMixed:
            singleChannelRawDataLen = 0;
            break;
        case enDpcm:
            singleChannelRawDataLen = (SampleLen * (FrmDpcmBits[0] + 1) + 7) / 8 + 8;
            break;
        case enOneBitDpcm:
            singleChannelRawDataLen = (SampleLen + 7) / 8 + 8;
            break;
        default:
            singleChannelRawDataLen = (SampleLen << 1 ) + 8;
        }
        singleChannelBufLen = (SampleLen << 2 ) + 8;
        break;
    }
	
	if (FrmDpcmBits[0] < 8)
	{
		maxRawBufLength = MAX_RAWDATA_BUF_LENGTH/MAX_SAMPLE_LENGTH;
	}
	else
	{
		maxRawBufLength = MAX_RAWDATA_BUF_LENGTH/singleChannelRawDataLen;
	}
	
    //maxRawBufLength = MAX_RAWDATA_BUF_LENGTH/singleChannelBufLen;
	singlePackageSum = singleChannelRawDataLen % BLOCK_SIZE ?  singleChannelRawDataLen/BLOCK_SIZE + 1: singleChannelRawDataLen/BLOCK_SIZE;

	restPackageData[0] = (UCHAR *)new UCHAR[singleChannelRawDataLen * MAX_CARDNUM];
    for(i =0; i < MAX_CARDNUM; i++){
	   restPackageCard[i] = singlePackageSum;
	   restPackageData[i] = restPackageData[0] + i* singleChannelRawDataLen;
	}

    curFftBufLength = 0;
    singleFftBufLen = (MAX_FFTDATA_LENGTH << 1) + 8;
    maxFftBufLength = MAX_FFTDATA_BUF_LENGTH / singleFftBufLen;
    singleFftPackageSum = singleFftBufLen % BLOCK_SIZE ?  singleFftBufLen/BLOCK_SIZE + 1: singleFftBufLen/BLOCK_SIZE;
    restFftPackageData[0] = (UCHAR *)new UCHAR[singleFftBufLen * MAX_CARDNUM];
    for(i =0; i < MAX_CARDNUM; i++)
    {
        restFftPackageCard[i] = singleFftPackageSum;
        restFftPackageData[i] = restFftPackageData[0] + i* singleFftBufLen;
	}

    if (reset)
    {
        memset(bStartStreamingInternalTrig, 0, MAX_CARDNUM * CHANNEL_NUMBER_PERCARD * sizeof(BOOL));
    }
	memset(exParamBuf, 0, 12 * sizeof(short));
	memset(ChStreamingState, 0, sizeof(short) * MAX_CARDNUM * CHANNEL_NUMBER_PERCARD);
    if (reset)
    {
        //bHardParam = FALSE;
        memset(bParamEn, 0, sizeof(bParamEn));
    }
//	return dwOpenSum;
}

/*++
����:
	��ʼ����������AD���ԼĴ��������������ɼ��߳�
����:
	��
����ֵ:
	��ȷ���� TRUE
	���󷵻� ...
--*/
BOOL UsbaeHardware16BitNew::StartSample()
{
    UINT     regvalue;
    DWORD    pThreadId;
    int      i;

    UCHAR bufOutput;

	memset(ovRead,0,sizeof(ovRead));

    //sysCurTime = 0;

    CH_AD_PROP RegVal;
    RegVal.cmd = 0;
    RegVal.spec.DcOffsetEn = 1;
    RegVal.spec.run = 1;
    int j;

	char tempStr[12];
	int k = 0;
	for(i = 0; i < MAX_CARDNUM; i++)
	{
		if(bDeviceOpenFlag[i])
		{
			//reset fifo
			bufOutput = 3 ;
			USBWriteEP(i, 0, 1, &bufOutput);

			sprintf(tempStr, "CardEvent%u", i);
			hEventArray[k] = CreateEvent(NULL, TRUE, FALSE, tempStr);
			ovRead[i].hEvent = hEventArray[k];
			EventIndexTOCardIndex[k] = i;
			k++;

            for (j = 0; j < CHANNEL_NUMBER_PERCARD; j++)
            {
                //���� cfg_ad_ch0   (�������� ֱ��ƫ��)
                WriteRegister(i, ChRegBaseAddrs[j] + PROP_CH_AD_REG, RegVal.cmd);
            }
			/************************************************************************/

#ifdef REGISTER_DEBUG
// 			char* pFileName = "regfile.txt";
// 			UINT u32Tmp;
// 			
// 			FILE* fp = fopen(pFileName, "ab+");
// 			
// 			fseek(fp, 0, SEEK_END);   char str[200];
// 			sprintf(str, "Card %d\r\n", i);
// 			fwrite(str, strlen(str), 1, fp);
// 			sprintf(str, "Register Address \t Register Value\r\n");
// 			fwrite(str, strlen(str), 1, fp);
// 			
// 			for (int j = 0; j < 0x30; j++)
// 			{
// 				ReadRegister(i, j, &u32Tmp);
// 				sprintf(str, "0x%x \t\t\t 0x%x\r\n", j, u32Tmp);
// 				fwrite(str, strlen(str), 1, fp);
// 			}
// 			fclose(fp);
// 			//    WriteRegister(i, AE_COMMAND, 0xc300003);
#endif
			/************************************************************************/
		}
	}
	for (i = 0; i < openCardNum; i++)
	{
		sprintf(tempStr, "CardEvent%u", EventIndexTOCardIndex[i]);
		hEventArray[i + k] = OpenEvent(EVENT_ALL_ACCESS, NULL, tempStr);
	}
	for (i = openCardNum * 2; i < MAX_CARDNUM * 2; i++)
	{
		hEventArray[i] = NULL;
	}

    /**********************����ת��������buffer��ʼ��************************/
    if (openCardNum > 0)
    {
        U32 buf_sz;
//         if (compact_mode)
//         {
//             buf_sz = 10000;
//         }
//         else

//         {
//             buf_sz = 200000;
//         }
// 
//         paraBuf = new PARAM[buf_sz];
//         memset(paraBuf, 0, buf_sz * sizeof(PARAM));
    }
    WaveToHitStart(WthMdl, exParamBuf);
    /************************************************************************/

   ThreadFlag = TRUE;
   ThreadStatus = 0;

   preSysTime = 0;
   curSysTime = 0;
   m_llParamTimeAdjust = 0;
   m_ullLastSystime = 0;

   ThreadHandle = CreateThread(
            NULL,                         
            0,                             
            InterruptAttachThreadLocalInt, 
            (LPVOID)this,               
            0,                             
            &pThreadId                     
            );

   //�ȴ�������ɣ�αusb3.0��Ҫ
   Sleep(300);

   //start AD
   bufOutput = 0x05;
   USBWriteEP(0, 0, 1, &bufOutput);
   bufOutput = 0x04;
   USBWriteEP(0, 0, 1, &bufOutput);

//#ifdef _DEBUG
#ifdef REGISTER_DEBUG
   /************************************************************************/
   char* pFileName = "regfile.txt";
   UINT u32Tmp;
   
   FILE* fp = fopen(pFileName, "ab+");
   
   fseek(fp, 0, SEEK_END);   char str[200];
   sprintf(str, "Register Address \t Register Value\r\n");
   fwrite(str, strlen(str), 1, fp);
   
   for (i = 0; i < 0xff; i++)
   {
       ReadRegister(0, i, &u32Tmp);
       sprintf(str, "0x%x \t\t\t 0x%x\r\n", i, u32Tmp);
       fwrite(str, strlen(str), 1, fp);
   }
   fclose(fp);
   /************************************************************************/
#endif
//    ReadRegister(0, AE_STREAM_MODE_REG, &streaming);

//    char* pFileName = "datafile.dat";
//    
//    FILE* fp = fopen(pFileName, "ab+");
//    
//    fseek(fp, 0, SEEK_END);
//    
//    fwrite(&aeCmd, sizeof(UINT), 1, fp);
//    fwrite(&eventLockout, sizeof(UINT), 1, fp);
//    fwrite(&paramThresSamp0, sizeof(UINT), 1, fp);
//    fwrite(&paramThresSamp1, sizeof(UINT), 1, fp);
//    fwrite(&lenFreq, sizeof(UINT), 1, fp);
//    fwrite(&outerTrig, sizeof(UINT), 1, fp);
//    fwrite(&outStat, sizeof(UINT), 1, fp);
//    fwrite(&sysTime, sizeof(UINT), 1, fp);
//    fwrite(&exParamAttr, sizeof(UINT), 1, fp);
//    fwrite(&exParamFixed, sizeof(UINT), 1, fp);
//    fwrite(&mode, sizeof(UINT), 1, fp);
//    fwrite(&version, sizeof(UINT), 1, fp);
//    fwrite(&streaming, sizeof(UINT), 1, fp);
//   
// 	fclose(fp);

//#endif

   for (i = 0; i < MAX_CARDNUM * CHANNEL_NUMBER_PERCARD; i++)
   {
       if (bStartStreamingInternalTrig[i])
       {
           StartChStreamingInternalTrig(i);
       }
   }

	return TRUE;
}

/*++
����:
	ֹͣ����
����:
	��
����ֵ:
	void
--*/
void UsbaeHardware16BitNew::StopSample()
{
 	int i, j;

	ThreadFlag = FALSE;
	while (ThreadStatus != 2)
		Sleep(1);
	
	for(i = 0; i < MAX_CARDNUM; i++){	
		if( bDeviceOpenFlag[i])
			SetCardSample(i, FALSE);
	}

	for(i = 0; i < MAX_CARDNUM; i++){	
		if( bDeviceOpenFlag[i]){
			CloseHandle(hEventArray[i]);
			hEventArray[i]	=	NULL;
		}
	} 

    /*****************************����ת����ֹͣ*****************************/
    WaveToHitStop(WthMdl);
    /************************************************************************/

}

/*++
����:
	�رղɼ���
����:
	��
����ֵ:
	void
--*/
void UsbaeHardware16BitNew::CloseCard()
{
 	int i;
	if(bOpenCardStatus == FALSE)
		return;
	for( i=0; i < MAX_CARDNUM; i++){
		if(bDeviceOpenFlag[i])
            CloseUSB7kC(i);

        bDeviceOpenFlag[i] = FALSE;
	}
	if(restPackageData[0])
		delete restPackageData[0];
    if (restFftPackageData[0])
    {
        delete restFftPackageData[0];
		restFftPackageData[0] = NULL;
    }
	bOpenCardStatus = FALSE;
}

/*++
����:
	WAE��dll��ȡ�������ݣ��ڲ�������ǰ�Ƚ�������
	�����飺
			1.��ͨ���Ĳ����Ѵ洢����Ӧ��ParamFIFO�У���ͨ��FIFO�еĲ���������ã�������ʱ�䣩
			2.ͨ�����ȡ�鲢���򣬼��Ƚϸ�ͨ������pop���Ĳ����ĵ���ʱ�䣬��С��pop��
			3.pop��ʱ�䲻�����������߳̽���ʱ������100��������ݣ��߳�ֹͣʱ��ȫ��pop�������pop
			4.Ϊ��߲���ͨ���ʣ���һ���ӳٻ��ƣ���ǰ����С��10Wʱ�������в�������ʹ��ݣ�
			  ����ʱ����Ʊ�֤������������������������ʱ��ÿ200������������ʹ���һ�β�����
����:
	__out  pBuf - Ŀ�껺������ַ
����ֵ:
	���ض�ȡ�Ĳ�������
--*/
DWORD UsbaeHardware16BitNew::GetParamFromBuf(PARAM *pBuf)
{
	DWORD retnlength =0;
	if(WAIT_OBJECT_0 != WaitForSingleObject(paraMutex, 1000))
		return 0;
    DWORD curParaBufLength = 0;
	int i;
	int iChMaxCount = 0;
	int iTemp = 0;
	for (i = 0; i < MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1 ; i++)
	{
		iTemp = chParamFIFO[i].GetDataLength();
		if( iTemp > iChMaxCount )
			iChMaxCount = iTemp;
		curParaBufLength += iTemp;
	}
	if(  curParaBufLength < 1)
	{
		ReleaseMutex(paraMutex);
		return retnlength;
	}
	
    curSysTime = PARAM_TIME_MASK;
    for (i = 0; i < MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1; i++)
    {
        if (chParamFIFO[i].ArriveTime < curSysTime)
            curSysTime = chParamFIFO[i].ArriveTime;
    }

	if(curSysTime >= PARAM_TIME_MASK ) return 0;
	if( preSysTime == 0 /* && curSysTime < 10000*/ || GetTickCount() < 300)
	{
		preSysTime = (unsigned __int64)GetTickCount() * 10000; 
		m_llParamTimeAdjust = (unsigned __int64)preSysTime - curSysTime;	
		//TRACE("curSysTime: %I64d\n", curSysTime );
		//TRACE("COUNT: %d\n", curParaBufLength);

		ReleaseMutex(paraMutex);
		return retnlength;
	}


	preSysTime = (unsigned __int64)GetTickCount() * 10000 ; 
// 	TRACE("curSysTime: %d\n", curSysTime );
// 	TRACE("ParamTime++: %d\n", curSysTime + m_llParamTimeAdjust);
	//TRACE("TickCount-------:%d\n", dwTickCount);
 	//TRACE("SysTime-------:%I64d\n", preSysTime);
// 	TRACE("\n\n\n");
	
	if( iChMaxCount  > perCardParabufLength/2 || (curSysTime + 2000000 + m_llParamTimeAdjust < preSysTime ))
	{
	
		unsigned __int64 tempTime = 0;
		if (ThreadFlag)
		{
			do
			{
				tempTime = PARAM_TIME_MASK;
				int temp = -1;
				for (int i=0; i< MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1; i++)
				{
					if (chParamFIFO[i].ArriveTime < tempTime)
					{
						temp = i;
						tempTime = chParamFIFO[i].ArriveTime;
					}
				}
				if (temp != -1)
				{				
					chParamFIFO[temp].popsingle(pBuf+retnlength);
					retnlength++;
				}
		
			}while ((tempTime + PARAM_OUTPUT_DELAY + m_llParamTimeAdjust) < preSysTime);
		
		}
		else
		{
			while (tempTime < preSysTime)
			{
				tempTime = PARAM_TIME_MASK;
				int temp = -1;
				for (int i = 0; i < MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1; i++)
				{
					if (chParamFIFO[i].ArriveTime < tempTime)
					{
						temp = i;
						tempTime = chParamFIFO[i].ArriveTime;
					}
				}
				if (temp != -1)
				{
					chParamFIFO[temp].popsingle(pBuf+retnlength);
					// Edited by mengl 2014-1-2;
					// purpose:���������������������⣬ֹͣ�ɼ������ϴ�����
					//retnlength++;
				}			
			}
		}
		//TRACE("retnlength: %d\n", retnlength );
	}
	while(chParamFIFO[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1].GetDataLength()>0 )
	{
		chParamFIFO[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1].popsingle(pBuf+retnlength);	
	}
	//curParaBufLength = 0;
	ReleaseMutex(paraMutex);
	return retnlength;
}

__int64 UsbaeHardware16BitNew::GetSysTickCount64()
{
	static LARGE_INTEGER TicksPerSecond = {0};
	LARGE_INTEGER Tick;
	if(!TicksPerSecond.QuadPart)
	{
		QueryPerformanceFrequency(&TicksPerSecond);
	}
	QueryPerformanceCounter(&Tick);
	__int64 Seconds = Tick.QuadPart/TicksPerSecond.QuadPart;
	__int64 LeftPart = Tick.QuadPart - (TicksPerSecond.QuadPart*Seconds);
	__int64 MillSeconds = LeftPart*1000/TicksPerSecond.QuadPart;
	__int64 Ret = Seconds*1000+MillSeconds;
	//    __ASSERT(Ret>0);
	return Ret;
};

/*++
����:
	WAE��dll��ȡʵʱ�������ݣ�����ǰ���ݲ��α��뷽ʽ���н���
����:
	__out  rBuf - Ŀ�껺������ַ
����ֵ:
	���ض�ȡ�Ĳ���֡����
--*/
DWORD UsbaeHardware16BitNew::GetRawDataFromBuf(char *rBuf)
{
	DWORD retnlength =0;
	if(!curRawBufLength)
		return retnlength;
	if(WAIT_OBJECT_0 != WaitForSingleObject(rawMutex, 1000))
		return 0;
	if(curRawBufLength)
    {
        if (FrmVer[0] == 0)
        {
            switch (FrmEncodeType[0])
            {
            case enDpcm:
                DpcmWaveConvert(rBuf, rawBuf, curRawBufLength);
                break;
			case en18BitsPcm:
            case en16BitsPcm:
                Pcm16bitWaveConvert(rBuf, rawBuf, curRawBufLength);
                break;
            }
        }

        /****************************����ת����**********************************/
        if (!bHardParam)
        {
            int j, k;

            for (j = 0; j < curRawBufLength; j++)
            {
                U32 *tmpbuf = (U32 *)&rBuf[j * singleChannelBufLen];
                FRAME_FLAG *pFrmFlag = (FRAME_FLAG *)tmpbuf;
                WORD chno = pFrmFlag->spec.card * CHANNEL_NUMBER_PERCARD + pFrmFlag->spec.ChOfCard;
                
                if ((chno < 0) || (chno >= MAX_CARDNUM * CHANNEL_NUMBER_PERCARD))
                {
                    continue;
                }
                U64 tm = (((U64)tmpbuf[1]) << 16) | (tmpbuf[0] >> 16);

                if (bParamEn[chno])
                {
                    WaitForSingleObject(hWaveToHitSemaph, INFINITE);
                    I32 prm_num = WaveToHitProc(WthMdl, chno, tm * 100, (I32*)&tmpbuf[2], False);
                    if (prm_num > 0)
                    {
                        prm_num = WaveToHitGetParam(WthMdl, prm_num, (I8*)paraBuf);
                        for (k = 0; k < prm_num; k++)
                        {
                            chParamFIFO[chno].pushsingle(&paraBuf[k]);
                        }
                    }
                    ReleaseSemaphore(hWaveToHitSemaph, 1, NULL);
                }
            }
        }
        /************************************************************************/

#ifdef STREAMING_DEBUG
        int i;
        WORD chno;
        unsigned __int64 tm, tend;
        FRAME_FLAG *pFrmFlag = NULL;
        PDWORD buf;
        FILE *fp;

        fp = fopen("streaming_time.txt", "ab+");

        for (i = 0; i < curRawBufLength; i++)
        {
            buf = (PDWORD)&rBuf[i * singleChannelRawDataLen];
            pFrmFlag = (FRAME_FLAG *)buf;
            chno = pFrmFlag->spec.card * CHANNEL_NUMBER_PERCARD + pFrmFlag->spec.ChOfCard;
            tm = ((((unsigned __int64)buf[1]) << 16) | (buf[0] >> 16)) * 100;
            tend = tm + SampleCycle * SampleLength;
            fprintf(fp, "CH%u %04x%08x-%04x%08x\r\n", chno, tm >> 32, tm & 0xFFFFFFFF, tend >> 32, tend & 0xFFFFFFFF);
        }
        fclose(fp);
#endif
		retnlength = curRawBufLength;
		curRawBufLength = 0;
	}
	ReleaseMutex(rawMutex);
	return retnlength;
}

/*++
����:
	WAE��dll��ȡFFT��������
����:
	__out  rBuf - Ŀ�껺������ַ
����ֵ:
	���ض�ȡ��FFT���γ���
--*/
DWORD UsbaeHardware16BitNew::GetFftDataFromBuf(char *rBuf)
{
    DWORD retnlength =0;
    if(WAIT_OBJECT_0 != WaitForSingleObject(fftMutex, 1000))
        return 0;

	int *pDesData;
    short *pSrcData;

	DWORD DesFFTDataLen = MAX_FFTDATA_LENGTH * 4 + 8;
	DWORD SrcFFTDataLen = MAX_FFTDATA_LENGTH * 2 + 8;
    if(curFftBufLength)
	{
//        memcpy(rBuf, fftBuf, curFftBufLength * singleFftBufLen);
		for (int i = 0; i < curFftBufLength; i++)
		{
			memcpy(&rBuf[i * DesFFTDataLen], &fftBuf[i * SrcFFTDataLen], 8);

			pDesData = (int*)&rBuf[i * DesFFTDataLen + 8];
			pSrcData = (short*)&fftBuf[i * SrcFFTDataLen + 8];
			for (int k = 0; k < MAX_FFTDATA_LENGTH; k++)
			{
				pDesData[k] = (int)pSrcData[k];
			}
		}
        retnlength = curFftBufLength;
        curFftBufLength = 0;
    }
    ReleaseMutex(fftMutex);
    return retnlength;
}

/*++
����:
	���FIR�˲�������
����:
	��
����ֵ:
	FIR�˲�������
--*/
DWORD UsbaeHardware16BitNew::GetFirFilterOrder()
{
	return FirFilterOrder;
}

/*++
����:
	����FIR�˲���������FIRϵ����������FIR���ԼĴ��� �� FIR�˲�������ϵ���Ĵ���
	�������ã������øÿ�������ͨ��
����:
	__in  CardNo - ����
	__in  pPara  - FIR�˲���ϵ������ָ��
	__in  order  - FIR�˲�������
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int UsbaeHardware16BitNew::SetFirFilter(short CardNo, double* pPara, int order)
{
	int i, j;
	CH_FIR_CFG_PROP RegVal;
	CH_FIR_COEF_PROP CoefVal;

	CH_FUNC_PROP FuncVal;

	
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}

	if (order != FIR_ORDER)
	{
		return -1;
	}
	
	short *filter_coef = new short[FIR_ORDER / 2 + 1];

	if (filter_coef == NULL)
	{
		return -1;
	}

    for (i = 0; i < FIR_ORDER / 2 + 1; i++)
    {
        filter_coef[i] = (short)(pPara[i] * 32767);
    }
    
    /**********************�޸����ֵΪ32767*********************************/
//     double coeff_max = pPara[0];
//     for (i = 0; i < FIR_ORDER / 2 + 1; i++)
//     {
//         if (coeff_max < pPara[i])
//         {
//             coeff_max = pPara[i];
//         }
// 	}
//     for (i = 0; i < FIR_ORDER / 2 + 1; i++)
//     {
//         filter_coef[i] = (short)(pPara[i] * 32767 / coeff_max);
//     }
    /************************************************************************/

    /************************************************************************/
//     char* pFileName;
//     FILE *fp;
//     double sum = 0;
//     pFileName = "fir_coeff.txt";
//     
//     fp = fopen(pFileName, "ab+");
//     
//     fseek(fp, 0, SEEK_END);
//     
//     char info[40];
//     for (i = 0; i < FIR_ORDER / 2 + 1; i++)
//     {
//         fprintf(fp, "%f\r\n", pPara[i]);
// //         fprintf(fp, "%d\r\n", filter_coef[i]);
// 
//         sum += pPara[i] * 2;
//     }
//     sum -= pPara[i - 1];
//     for (; i < FIR_ORDER; i++)
//     {
//         fprintf(fp, "%f\r\n", pPara[FIR_ORDER  - i - 1]);
// //         fprintf(fp, "%d\r\n", filter_coef[FIR_ORDER  - i - 1]);
//     }
//     fprintf(fp, "sum = %f\r\n\r\n", sum);
//     
//     fclose(fp);
    /************************************************************************/

	//�������˲���ϵ��������˳��
#if (FIR_ORDER == 159)
	//159���˲���ϵ������˳��
	unsigned coef_seq_80 [FIR_ORDER / 2 + 1] = {79, 9, 19, 29, 39, 49, 59, 69, 78, 8, 18, 28, 38, 48, 58, 68, 77, 7, 17, 27, 37, 47,
		57, 67, 76, 6, 16, 26, 36, 46, 56, 66, 75, 5, 15, 25, 35, 45, 55, 65, 74, 4, 14, 24,
		34, 44, 54, 64, 73, 3, 13, 23, 33, 43, 53, 63, 72, 2, 12, 22, 32, 42, 52, 62, 71, 1,
        11, 21, 31, 41, 51, 61, 70, 0, 10, 20, 30, 40, 50, 60};
#elif (FIR_ORDER == 63)
	//63���˲���ϵ������˳��
 	unsigned coef_seq_32 [FIR_ORDER / 2 + 1] = {31, 3, 7, 11, 15, 19, 23, 27, 30, 2, 6, 10, 14, 18, 22, 26, 29, 1, 5,
 		9, 13, 17, 21, 25, 28, 0, 4, 8, 12, 16, 20, 24};
//	unsigned coef_seq_32 [FIR_ORDER / 2 + 1] = {31, 7, 15, 23, 30, 6, 14, 22, 29, 5, 13, 21, 28, 4, 12, 20, 27, 3, 11,
//		19, 26, 2, 10, 18, 25, 1, 9, 17, 24, 0, 8, 16};
#elif (FIR_ORDER == 59)
	//59���˲���ϵ������˳��
	unsigned coef_seq_32 [FIR_ORDER / 2 + 3] = {29, 1, 5, 9, 13, 17, 21, 25, 28, 0, 4, 8, 12, 16, 20,
		24, 27, 0, 3, 7, 11, 15, 19, 23, 26, 0, 2, 6, 10, 14, 18, 22};
#endif
	RegVal.cmd = 0;
	RegVal.spec.RstCmd = 0;		//��λ�˲���ģ��
	WriteRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FIR_CFG_REG, RegVal.cmd);
	
	RegVal.spec.FilterEn = 1;
	RegVal.spec.RstCmd = 1;
	Sleep(1);

	//��ϵ��д��ϵ����������
	for (j = 0; j < CHANNEL_NUMBER_PERCARD; j++)
	{
#if (FIR_ORDER == 159)
		unsigned *coef_seq = coef_seq_80;
		for (i = 0; i < FIR_ORDER / 2 + 1; i++)
#elif (FIR_ORDER == 63)
		unsigned *coef_seq = coef_seq_32;
		for (i = 0; i < FIR_ORDER / 2 + 1; i++)
#elif (FIR_ORDER == 59)
		unsigned *coef_seq = coef_seq_32;
		for (i = 0; i < FIR_ORDER / 2 + 3; i++)
#endif
		/*++
		����ΪFIR�˲���ϵ��д�����RegVal.spec.CoefWrCmd ��0-1֮�䣬д��һ��ϵ����FIR�˲�������ϵ���Ĵ���
		--*/
		{
			RegVal.spec.CoefWrCmd = 0;
			WriteRegister(CardNo, ChRegBaseAddrs[j] + PROP_CH_FIR_CFG_REG, RegVal.cmd);
			CoefVal.cmd = 0;
			CoefVal.spec.coef = filter_coef[coef_seq[i]];
			WriteRegister(CardNo, ChRegBaseAddrs[j] + PROP_CH_FIR_COEF_DATA_REG, CoefVal.cmd);     //д��һ��ϵ��
			RegVal.spec.CoefWrCmd = 1;
			WriteRegister(CardNo, ChRegBaseAddrs[j] + PROP_CH_FIR_CFG_REG , RegVal.cmd);
		}
		RegVal.spec.CoefCfgCmd = 1;                     //����FIR���ã�����ϵ���������е�����д���˲�����  
		WriteRegister(CardNo, ChRegBaseAddrs[j] + PROP_CH_FIR_CFG_REG, RegVal.cmd); 
		Sleep(1);

		ReadRegister(CardNo, ChRegBaseAddrs[j] + PROP_CH_FUNCTION_REG, (unsigned int*)&FuncVal.cmd);
		FuncVal.spec.FirEn = 1;
		WriteRegister(CardNo, ChRegBaseAddrs[j] + PROP_CH_FUNCTION_REG, FuncVal.cmd);
	}	
	delete []filter_coef;

	return 0;
}

/*++
����:
	��λFIR�˲�����������FIR���ԼĴ����ĸ�λλ
	�������ã������øÿ�������ͨ��
����:
	__in  CardNo - ����
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int UsbaeHardware16BitNew::DisableFirFilter(short CardNo)
{
	CH_FIR_CFG_PROP RegVal;
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}
	RegVal.cmd = 0;
	RegVal.spec.RstCmd = 0;

	WriteRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FIR_CFG_REG, RegVal.cmd);
	WriteRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FIR_CFG_REG, RegVal.cmd);

	return 0;
}

/*++
����:
	����FFT����ģʽ��������FFT���ԼĴ���,����FFT��ʹ�ܵ�����£����ò�������2
	�������ã������øÿ�������ͨ��
����:
	__in  CardNo - ����
	__in  mode   - ��ֵ����16λ�忨ʱ��ֵ�����ڴ�����λ����
		����λ��0  - ͨ��0 FFTʹ��λ;     1  - ͨ��1 FFTʹ��λ;
				2  - ͨ��0 ��������λ;    3  - ͨ��1 ��������λ;
				4  - ͨ��0 ���ɴ���λ;    5  - ͨ��1 ���ɴ���λ;
				8  - ͨ��0 ������ʹ��λ;  9  - ͨ��1 ������ʹ��λ;//��18λ��δ�õ�
				10 - ͨ��0 �Ƿ���δ�;    11 - ͨ��1 ֪����δ�;
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int UsbaeHardware16BitNew::SetFFTWorkMode(short CardNo, DWORD mode)
{
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}
	CH_FUNC_PROP RegVal;
	CH_FFT_CFG_PROP ConfValue_CH0;
	CH_FFT_CFG_PROP ConfValue_CH1;
	ConfValue_CH0.cmd = 0;
	ConfValue_CH1.cmd = 0;
	ConfValue_CH0.spec.FtfEn = mode;
	fftEn = ConfValue_CH0.spec.FtfEn;
	if (ConfValue_CH0.spec.FtfEn)
	{
		ReadRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
		RegVal.spec.FftEn = 1;
		WriteRegister(CardNo,ChRegBaseAddrs[0] + PROP_CH_FUNCTION_REG, RegVal.cmd);

		ReadRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
		RegVal.spec.FftEn = 1;
		WriteRegister(CardNo,ChRegBaseAddrs[1] + PROP_CH_FUNCTION_REG, RegVal.cmd);

		ConfValue_CH0.spec.HitTrigEn = mode>> 2;
		ConfValue_CH0.spec.FreeRun = mode>> 4;
		ConfValue_CH0.spec.RectWinEn = mode>> 10;

		ConfValue_CH1.spec.FtfEn = mode>>1;
		ConfValue_CH1.spec.HitTrigEn = mode>> 3;
		ConfValue_CH1.spec.FreeRun = mode>> 5;
		ConfValue_CH1.spec.RectWinEn = mode>> 11;

		WriteRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FFT_CFG_REG, ConfValue_CH0.cmd);
		WriteRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FFT_CFG_REG, ConfValue_CH1.cmd);


		CH_FUNC_PROP FuncVal;
		
		ReadRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FUNCTION_REG, (unsigned int*)&FuncVal.cmd);
		//������Ӳ����ǰ״̬��һ��
		if (((mode & AE_FFT_CFG_DATA_SAVE_EN0) && (FuncVal.spec.FftWaveEn == 0))
			|| ((mode & AE_FFT_CFG_DATA_SAVE_EN0 == 0) && (FuncVal.spec.FftWaveEn == 1)))
		{
			FuncVal.spec.FftWaveEn = ~FuncVal.spec.FftWaveEn;
			WriteRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FUNCTION_REG, FuncVal.cmd);
		}
		
		ReadRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FUNCTION_REG, (unsigned int*)&FuncVal.cmd);
		//������Ӳ����ǰ״̬��һ��
		if (((mode & AE_FFT_CFG_DATA_SAVE_EN1) && (FuncVal.spec.FftWaveEn == 0))
			|| ((mode & AE_FFT_CFG_DATA_SAVE_EN1 == 0) && (FuncVal.spec.FftWaveEn == 1)))
		{
			FuncVal.spec.FftWaveEn = ~FuncVal.spec.FftWaveEn;
			WriteRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FUNCTION_REG, FuncVal.cmd);
		}
	}
	else
	{
		ReadRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
		RegVal.spec.FftEn = 0;
		WriteRegister(CardNo,ChRegBaseAddrs[0] + PROP_CH_FUNCTION_REG, RegVal.cmd);

		ReadRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
		RegVal.spec.FftEn = 0;
		WriteRegister(CardNo,ChRegBaseAddrs[1] + PROP_CH_FUNCTION_REG, RegVal.cmd);

		WriteRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FFT_CFG_REG, ConfValue_CH0.cmd);
		WriteRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FFT_CFG_REG, ConfValue_CH1.cmd);
	}
	return 0;
}


/*++
����:
	����FFT�������ޣ�������FFT�������޼Ĵ���
	�������ã������øÿ�������ͨ��
����:
	__in  CardNo           - ����
	__in  fftWaveThreshold - FFT���δ�������ֵ
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int UsbaeHardware16BitNew::SetFFTWaveTrigPara(DWORD CardNo, DWORD fftWaveThreshold)
{
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}
	CH_FFT_THRESHOLD_CFG_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.threshold = fftWaveThreshold << 2; //�˴�FPGA����ֲ��18λ���ʼ򻯲���������16λת��18λ������ȥ

	WriteRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FFT_THRESHOLD_REG, RegVal.cmd);
	WriteRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FFT_THRESHOLD_REG, RegVal.cmd);

	return 0;
}

/*++
����:
	����FFT����ϵ����������FFT�������ԼĴ���
	��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
����:
	__in  ChanNo - ����ͨ����
	__in  scale  - FFT����ϵ��
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int UsbaeHardware16BitNew::SetChFFTResultScale(unsigned short ChanNo, double scale)
{
	unsigned short CardNo;
	unsigned char addr;
	unsigned int uScale = 0;

	CardNo = ChanNo / CHANNEL_NUMBER_PERCARD;
	ChanNo = ChanNo % CHANNEL_NUMBER_PERCARD;

	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}
	CH_FFT_SCALE_CFG_PROP RegVal;
	RegVal.cmd = 0;
	//Scale����ת��
	RegVal.spec.scale = scale * 32768;
	WriteRegister(CardNo, ChRegBaseAddrs[0] + PROP_CH_FFT_SCALE_CFG_REG, RegVal.cmd);
	WriteRegister(CardNo, ChRegBaseAddrs[1] + PROP_CH_FFT_SCALE_CFG_REG, RegVal.cmd);

	return 0;
}


/*++
����:
	����ͨ��FFT��������������FFT�����ԼĴ���
	��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
����:
	__in  ChanNo        - ����ͨ����
	__in  bEnableWindow - ������ʹ���źţ�TUREΪʹ��
	__in  pWinFunCoef   - ������ϵ�������ָ��
	__in  len           - ������ϵ������
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int UsbaeHardware16BitNew::SetChFFTWindowFunction(unsigned short ChanNo, BOOL bEnableWindow, double *pWinFunCoef, int len)
{
	int i;

	unsigned short CardNo;
	unsigned char addr;
	
	CardNo = ChanNo / CHANNEL_NUMBER_PERCARD;
	ChanNo = ChanNo % CHANNEL_NUMBER_PERCARD;
	
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}
	CH_FFT_WIN_CFG_PROP RegVal;
	if (bEnableWindow)
	{
		if (len > WIN_FUNC_COEF_SIZE)
		{
			return -1;
		}

		//������ϵ��ת��
		int *pTmpCoef = new int[len];
		int tmpCoef  = (1L << (GetOneCount(AE_HIT_CFG_WIN_COEF_DATA_MASK) - 1)) - 1;
		for (i = 0; i < len; i++)
		{
			pTmpCoef[i] = (int)(pWinFunCoef[i] * tmpCoef);
		}
		
		//��λ������
		RegVal.cmd = 0;
		WriteRegister(CardNo, ChRegBaseAddrs[ChanNo] + PROP_CH_FFT_WIN_CFG_REG, RegVal.cmd);

		//дϵ��
		for (i = 0; i < len; i++)
		{
			RegVal.spec.CoefAddr = i;
			RegVal.spec.coef= pTmpCoef[i];
			RegVal.spec.CoefWrCmd = 0;
			WriteRegister(CardNo, ChRegBaseAddrs[ChanNo] + PROP_CH_FFT_WIN_CFG_REG, RegVal.cmd);
			RegVal.spec.CoefWrCmd = 1;
			WriteRegister(CardNo, ChRegBaseAddrs[ChanNo] + PROP_CH_FFT_WIN_CFG_REG, RegVal.cmd);
		}

		//ʹ�ܴ�����
		//WriteRegister(CardNo, addr + AE_HIT_CFG_WINFUNC_REG, AE_HIT_CFG_WIN_EN);
		delete []pTmpCoef;
	}
	else
	{
		WriteRegister(CardNo, ChRegBaseAddrs[ChanNo] + PROP_CH_FFT_WIN_CFG_REG, 0);
	}
	
	return 0;
}

/*++
����:
	����ͨ��FFT���������泤�ȣ�������FFT�������������ԼĴ���
	��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
����:
	__in  ChanNo - ����ͨ����
	__in  len    - FFT����������
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int UsbaeHardware16BitNew::SetChFFTSaveLen(unsigned short ChanNo, int len)
{
	unsigned short CardNo;
	unsigned char addr;

	CardNo = ChanNo / CHANNEL_NUMBER_PERCARD;
	ChanNo = ChanNo % CHANNEL_NUMBER_PERCARD;
	
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}
	
	addr = AE_HIT_CFG_BASEADDR_CH0;
	addr <<= ChanNo;

	WriteRegister(CardNo, addr + AE_HIT_CFG_FFT_SAVELEN_REG, len & AE_HIT_CFG_FFT_SAVELEN_MASK);

	return 0;
}

/*++
����:
	����ͨ��FFT�źų�ȡ�ʣ�������FFT��Ƶϵ���Ĵ���
	��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
����:
	__in  ChanNo - ����ͨ����
	__in  val    - FFT�źų�ȡ�ʣ����Ϊ65535����СΪ1��ע����Ҫͬ�˲������õ����
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int UsbaeHardware16BitNew::SetChFFTDecimateRate(unsigned short ChanNo, int val)
{
	unsigned short CardNo;
	unsigned char addr;
	
	CardNo = ChanNo / CHANNEL_NUMBER_PERCARD;
	ChanNo = ChanNo % CHANNEL_NUMBER_PERCARD;
	
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}
	CH_FFT_DECIMATE_CFG_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.DecimateRate = val & AE_HIT_CFG_FFT_DECIMATE_RATE_MASK;
	WriteRegister(CardNo, ChRegBaseAddrs[ChanNo] + PROP_CH_FFT_DECIMATE_RATE_REG, RegVal.cmd);
	
	return 0;
}

/*++
����:
	����ͨ��FFT�źų�ȡ�ʣ�������FFT�ֲ����������üĴ���
	��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
����:
	__in  ChanNo   - ����ͨ����
	__in  id       - �����, 0 - (MAX_FFT_PARTIAL_POW_SEGMENTS - 1)
	__in  StartBin - ��ʼBIN���	
	__in  EndBin   - �յ�BIN���
����ֵ:
	��ȷ���� 0
	���󷵻� -1
--*/
int UsbaeHardware16BitNew::SetChFFTPartialPowerSegment(unsigned short ChanNo, unsigned int id, int StartBin, int EndBin)
{
	unsigned short CardNo;
	unsigned char index_addr;
	
	CardNo = ChanNo / CHANNEL_NUMBER_PERCARD;
	ChanNo = ChanNo % CHANNEL_NUMBER_PERCARD;
	
	if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
	{
		return -1;
	}

	if (id >= MAX_FFT_PARTIAL_POW_SEGMENTS)
	{
		return -1;
	}
	CH_FFT_PP_CFG_PROP RegVal;
	RegVal.cmd = 0;
	RegVal.spec.MaxBin = EndBin;
	RegVal.spec.MinBin = StartBin;

	index_addr = PROP_CH_FFT_PP0_REG;
	index_addr += id;

	WriteRegister(CardNo,ChRegBaseAddrs[ChanNo] + index_addr, RegVal.cmd);
    return 0;
}

/*++
����:
	����ͨ�������ɼ�ģʽ���������������δ���ģʽ�Ĵ�����������ͨ���������ԼĴ���Ϊ�����ɼ�
	��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
����:
	__in  chanNo   - ����ͨ����
	__in  bEnabled - �����ɼ�ʹ��
	__in  TrigMode - ����ģʽ	
����ֵ:
	��ȷ���� TRUE
	���󷵻� FALSE
--*/
BOOL UsbaeHardware16BitNew::SetChStreamingMode(unsigned short chanNo, BOOL bEnabled, int TrigMode)
{
    UINT regvalue;
    
    unsigned short CardNo;
    CardNo = chanNo /CHANNEL_NUMBER_PERCARD;
    chanNo = chanNo % CHANNEL_NUMBER_PERCARD;
    if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE )
        return FALSE;

    CH_FUNC_PROP RegVal;
    

    if (bEnabled)
    {
        ReadRegister(CardNo, ChRegBaseAddrs[chanNo] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
        RegVal.spec.StreamWaveEn = 1;
		RegVal.spec.FftEn = 0;
		RegVal.spec.ThresholdWaveEn = 0;
		RegVal.spec.StateFrmEn = 1;
        WriteRegister(CardNo, ChRegBaseAddrs[chanNo] + PROP_CH_FUNCTION_REG, RegVal.cmd);

        CH_STREAM_CFG_PROP TrigVal;
        TrigVal.cmd = 0;
        switch (TrigMode)
        {
        case enStreamTrigSrcInternal: //�ڲ�����
            TrigVal.spec.InternalTrig = 1;
            break;
        case enStreamTrigSrcExternal: //�ⲿ����
            TrigVal.spec.ExternalTrig = 1;
            break;
        case enStreamTrigSrcThreshold: //���޴���
            TrigVal.spec.ThresholdTrig = 1;
            break;
        default:
            TrigVal.spec.InternalTrig = 1;
            break;
        }
		TrigVal.spec.GiveupEn = 1;
        WriteRegister(CardNo, ChRegBaseAddrs[chanNo] + PROP_CH_STREAM_CFG_REG, TrigVal.cmd);

        if (TrigMode == enStreamTrigSrcInternal)
        {
            bStartStreamingInternalTrig[CardNo * CHANNEL_NUMBER_PERCARD + chanNo] = TRUE;
        }
    }
    else
    {
        ReadRegister(CardNo, ChRegBaseAddrs[chanNo] + PROP_CH_FUNCTION_REG, (unsigned int*)&RegVal.cmd);
        RegVal.spec.StreamWaveEn = 0;
        WriteRegister(CardNo, ChRegBaseAddrs[chanNo] + PROP_CH_FUNCTION_REG, RegVal.cmd);
    }
    
    return TRUE;
}


/*++
����:
	����ͨ�������ɼ��ڲ���������д����ȫ���������βɼ����ƼĴ���
	��ͨ�����ã�ͨ����Ϊ����ͨ���ţ��� 0 �� (MAX_CARDNUM * CHANNEL_NUMBER_PERCARD - 1)
����:
	__in  ChanNo - ����ͨ����
����ֵ:
	��ȷ���� TRUE
	���󷵻� FALSE
--*/
BOOL UsbaeHardware16BitNew::StartChStreamingInternalTrig(unsigned short chanNo)
{
    UINT regvalue;
    
    unsigned short CardNo;
    CardNo = chanNo /CHANNEL_NUMBER_PERCARD;
    chanNo = chanNo % CHANNEL_NUMBER_PERCARD;
    if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE )
        return FALSE;
    
    GLB_STREAM_CTRL_CMD StrmVal;
    StrmVal.cmd = 0;
    
//     WriteRegister(CardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_STREAM_CTRL_REG, StrmVal.cmd);
    
    StrmVal.spec.InterTrig = 1;
    
    WriteRegister(CardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_STREAM_CTRL_REG, StrmVal.cmd);

    return TRUE;
}

BOOL UsbaeHardware16BitNew::SetAdg1439(DWORD CardNo, unsigned long dat_l, unsigned long dat_h)
{
    return FALSE;
}

/*++
����:
	���ģ�飬����һ�δ�68013�ж������������н������raw���ݣ�fft���ݣ�para���ݷֿ�����Ӧ������
����:
	__in  nIndex     - ����
	__in  recvbuffer - ָ�����������ݻ�������ָ��
	__in  recvcount  - ���������ݻ������ĳ���
����ֵ:
	VOID
--*/
void UsbaeHardware16BitNew::AnalysisPacket(short nIndex,UCHAR *recvbuffer, UINT recvcount)
{
    UINT allPackageSum = recvcount / BLOCK_SIZE;
    
	UINT restPackageSum;// = restPackageCard[nIndex];
    //PUINT pRestPackageSum = NULL;

	int j;

    
#ifdef DEBUG_FILE
    //���屣��FFT���ݵ��ļ�·��
    char* pFileName;
	switch (nIndex)
	{
	case 0:
		pFileName = "datafile_0.dat";
		break;
	case 1:
		pFileName = "datafile_1.dat";
		break;
	case 2:
		pFileName = "datafile_2.dat";
		break;
	case 3:
		pFileName = "datafile_3.dat";
		break;
	default:
		pFileName = "datafile.dat";
		break;
	}
    
    FILE* fp = fopen(pFileName, "ab+");
    
    fseek(fp, 0, SEEK_END);
    
	fwrite(recvbuffer, recvcount, 1, fp);
	
	fclose(fp);
#endif
	//////////////////////////////////////////////////////////////////////////

    PACK_HEAD *pPackHead;
    char *pDataBuf;
    UINT DataLen;

	for(UINT i = 0; i < allPackageSum; )
    {
        if (bFrmDecodeCompleted[nIndex])
        {
            bFrmDecodeCompleted[nIndex] = FALSE;
        }

        pPackHead = (PACK_HEAD*)&recvbuffer[i*BLOCK_SIZE];
        
        //PackVer[nIndex] = pPackHead->spec.ver;

        switch (PackVer[nIndex])
        {
        case 1:
            if ((pPackHead->spec.SyncHead != PackSyncHead) || (pPackHead->spec.ver != 1))
            {
                continue;   //ͬ��ͷ��汾�ų���
            }
            //PackVer = pPackHead->spec.ver;
            pDataBuf = (char*)&recvbuffer[i*BLOCK_SIZE] + 12;
            DataLen = (BLOCK_SIZE - 12 - 8);
            /************************************************************************/
            /*                                                                      */
            /************************************************************************/
            if ((restPackageCard[nIndex] < singlePackageSum)
                || ((restFftPackageCard[nIndex] >= 4)
                && (((*(unsigned short *)&recvbuffer[i*BLOCK_SIZE]) & 0xC000) == 0x8000)))   //Realtime Wave
            {
                //pRestPackageSum = &restPackageCard[nIndex];
                restPackageSum = restPackageCard[nIndex];
            
                while(curRawBufLength >= maxRawBufLength)
                {
                    if (!ThreadFlag)
                    {
                        return;
                    }
                }
                if(WAIT_OBJECT_0 != WaitForSingleObject(rawMutex, 1000))
                    continue;
                if(i + restPackageSum <= allPackageSum) {  // copy all singlerawbuf
                    if(restPackageSum == singlePackageSum)
                    {
                        memcpy(&rawBuf[curRawBufLength * singleChannelRawDataLen], &recvbuffer[i*BLOCK_SIZE],singleChannelRawDataLen);
                    }
                    else {
                        memcpy(&rawBuf[curRawBufLength * singleChannelRawDataLen], restPackageData[nIndex], (singlePackageSum - restPackageSum) * BLOCK_SIZE );
                        memcpy(&rawBuf[curRawBufLength * singleChannelRawDataLen + (singlePackageSum - restPackageSum)* BLOCK_SIZE], &recvbuffer[i*BLOCK_SIZE],singleChannelRawDataLen - (singlePackageSum - restPackageSum) * BLOCK_SIZE );				
                    }
                    curRawBufLength ++;
                    i +=  restPackageSum;
                    restPackageSum = singlePackageSum;
                }
                else {  // not enough a singleraw buf
                    memcpy(restPackageData[nIndex] + (singlePackageSum - restPackageSum)* BLOCK_SIZE, &recvbuffer[i*BLOCK_SIZE], (allPackageSum -i) * BLOCK_SIZE );
                    restPackageSum -= (allPackageSum -i);
                    i = allPackageSum;
                }
                restPackageCard[nIndex] = restPackageSum;
                ReleaseMutex(rawMutex);
            }
            else if ((restFftPackageCard[nIndex] < singleFftPackageSum)
                || ((restPackageCard[nIndex] >= singlePackageSum)
			    && (((*(unsigned short *)&recvbuffer[i*BLOCK_SIZE]) & 0xC000) == 0xC000)))   //FFT Wave
            {
                UINT tmp1 = restFftPackageCard[nIndex];
			    //pRestPackageSum = &restFftPackageCard[nIndex];
			    restPackageSum = restFftPackageCard[nIndex];
			    
                while(curFftBufLength >= maxFftBufLength)
                {
                    if (!ThreadFlag)
                    {
                        return;
                    }
                }
                if(WAIT_OBJECT_0 != WaitForSingleObject(fftMutex, 1000))
                    continue;
                if(i + restPackageSum <= allPackageSum) {  // copy all singlerawbuf
                    if(restPackageSum == singleFftPackageSum)
                        memcpy(&fftBuf[curFftBufLength * singleFftBufLen], &recvbuffer[i*BLOCK_SIZE],singleFftBufLen);
                    else {
                        memcpy(&fftBuf[curFftBufLength * singleFftBufLen], restFftPackageData[nIndex], (singleFftPackageSum - restPackageSum) * BLOCK_SIZE );
                        memcpy(&fftBuf[curFftBufLength * singleFftBufLen + (singleFftPackageSum - restPackageSum)* BLOCK_SIZE], &recvbuffer[i*BLOCK_SIZE],singleFftBufLen - (singleFftPackageSum - restPackageSum) * BLOCK_SIZE );				
                    }
                    curFftBufLength ++;
                    i +=  restPackageSum;
                    restPackageSum = singleFftPackageSum;
                }
                else {  // not enough a singleraw buf
                    memcpy(restFftPackageData[nIndex] + (singleFftPackageSum - restPackageSum)* BLOCK_SIZE, &recvbuffer[i*BLOCK_SIZE], (allPackageSum -i) * BLOCK_SIZE );
                    restPackageSum -= (allPackageSum -i);
                    i = allPackageSum;
                }
			    restFftPackageCard[nIndex] = restPackageSum;
                ReleaseMutex(fftMutex);			
            }
            else// if (((*(unsigned short *)&recvbuffer[i*BLOCK_SIZE]) & 0xC000) == 0x4000)   //Hit Data
            {
			    if(WAIT_OBJECT_0 !=WaitForSingleObject(paraMutex, 1000))
					continue;

			    PARAM *curParam =(PARAM*)&recvbuffer[i*BLOCK_SIZE];

			    i++;

			    ReleaseMutex(paraMutex);
		    }
            break;
        case 0:
        default:
            pDataBuf = (char*)&recvbuffer[i*BLOCK_SIZE];
            DataLen = BLOCK_SIZE;

            /************************************************************************/
            /*                                                                      */
            /************************************************************************/
            if ((restPackageCard[nIndex] < singlePackageSum)
                || ((restFftPackageCard[nIndex] >= singleFftPackageSum)
                && (((*(unsigned short *)&recvbuffer[i*BLOCK_SIZE]) & 0xC000) == 0x8000)))   //Realtime Wave
            {
                //pRestPackageSum = &restPackageCard[nIndex];
                restPackageSum = restPackageCard[nIndex];
            
                while(curRawBufLength >= maxRawBufLength)
                {
                    if (!ThreadFlag)
                    {
                        return;
                    }
                }
                if(WAIT_OBJECT_0 != WaitForSingleObject(rawMutex, 1000))
                    continue;
                if(i + restPackageSum <= allPackageSum) {  // copy all singlerawbuf
                    if(restPackageSum == singlePackageSum)
                    {
                        memcpy(&rawBuf[curRawBufLength * singleChannelRawDataLen], &recvbuffer[i*BLOCK_SIZE],singleChannelRawDataLen);
                    }
                    else {
                        memcpy(&rawBuf[curRawBufLength * singleChannelRawDataLen], restPackageData[nIndex], (singlePackageSum - restPackageSum) * BLOCK_SIZE );
                        memcpy(&rawBuf[curRawBufLength * singleChannelRawDataLen + (singlePackageSum - restPackageSum)* BLOCK_SIZE], &recvbuffer[i*BLOCK_SIZE],singleChannelRawDataLen - (singlePackageSum - restPackageSum) * BLOCK_SIZE );				
                    }
                    curRawBufLength ++;
                    i +=  restPackageSum;
                    restPackageSum = singlePackageSum;
                }
                else {  // not enough a singleraw buf
                    memcpy(restPackageData[nIndex] + (singlePackageSum - restPackageSum)* BLOCK_SIZE, &recvbuffer[i*BLOCK_SIZE], (allPackageSum -i) * BLOCK_SIZE );
                    restPackageSum -= (allPackageSum -i);
                    i = allPackageSum;
                }
                restPackageCard[nIndex] = restPackageSum;
                ReleaseMutex(rawMutex);
            }
            else if ((restFftPackageCard[nIndex] < singleFftPackageSum)
                || ((restPackageCard[nIndex] >= singlePackageSum)
			    && (((*(unsigned short *)&recvbuffer[i*BLOCK_SIZE]) & 0xC000) == 0xC000)))   //FFT Wave
            {
                UINT tmp1 = restFftPackageCard[nIndex];
			    //pRestPackageSum = &restFftPackageCard[nIndex];
			    restPackageSum = restFftPackageCard[nIndex];
			    
                while(curFftBufLength >= maxFftBufLength)
                {
                    if (!ThreadFlag)
                    {
                        return;
                    }
                }
                if(WAIT_OBJECT_0 != WaitForSingleObject(fftMutex, 1000))
                    continue;
                if(i + restPackageSum <= allPackageSum) {  // copy all singlerawbuf
                    if(restPackageSum == singleFftPackageSum)
                        memcpy(&fftBuf[curFftBufLength * singleFftBufLen], &recvbuffer[i*BLOCK_SIZE],singleFftBufLen);
                    else {
                        memcpy(&fftBuf[curFftBufLength * singleFftBufLen], restFftPackageData[nIndex], (singleFftPackageSum - restPackageSum) * BLOCK_SIZE );
                        memcpy(&fftBuf[curFftBufLength * singleFftBufLen + (singleFftPackageSum - restPackageSum)* BLOCK_SIZE], &recvbuffer[i*BLOCK_SIZE],singleFftBufLen - (singleFftPackageSum - restPackageSum) * BLOCK_SIZE );				
                    }
                    curFftBufLength ++;
                    i +=  restPackageSum;
                    restPackageSum = singleFftPackageSum;
                }
                else {  // not enough a singleraw buf
                    memcpy(restFftPackageData[nIndex] + (singleFftPackageSum - restPackageSum)* BLOCK_SIZE, &recvbuffer[i*BLOCK_SIZE], (allPackageSum -i) * BLOCK_SIZE );
                    restPackageSum -= (allPackageSum -i);
                    i = allPackageSum;
                }
			    restFftPackageCard[nIndex] = restPackageSum;
                ReleaseMutex(fftMutex);			
            }
            else// if (((*(unsigned short *)&recvbuffer[i*BLOCK_SIZE]) & 0xC000) == 0x4000)   //Hit Data
            {
				if(WAIT_OBJECT_0 !=WaitForSingleObject(paraMutex, 1000))
					continue;

// 				DWORD nBreak = 0;
// 				PARAM *curParam =(PARAM*)&recvbuffer[i*BLOCK_SIZE];
// 				for( j= 0;  j < PARAM_SUM_EACH_PACKAGE; j++, curParam ++)
// 				{
// 					FRAME_FLAG *pFrmFlag = (FRAME_FLAG *)curParam;
// 					ULONGLONG X1 = curParam->endTime.Time2;
// 					X1 = curParam->endTime.Time1 + X1 << 32;
// 					ULONGLONG X2 = curParam->ArriveTime.Time2;
// 					X2 = curParam->ArriveTime.Time1 + X2 << 32;
// 		
// 					DWORD chno = pFrmFlag->spec.card * CHANNEL_NUMBER_PERCARD + pFrmFlag->spec.ChOfCard;
// 					if ((curParam->ChNo & 0xE000) == STATE_FLAG || (curParam->ChNo & 0xE000) == SYSTIME_FLAG 
// 						|| (curParam->ChNo & 0xE000) == EXPARA_FLAG 
// 						|| (curParam->ChNo ) == 0 
// 						|| (chno < MAX_CARDNUM*CHANNEL_NUMBER_PERCARD  && curParam->MaxAmp >0 && curParam->MaxAmp <= 32768 &&
// 						curParam->AllRing >= curParam->riseRing && X1 > X2 && curParam->riseRing > 0))
// 					{
// 
// 					}else
// 					{
// 						i++; 
// 						ReleaseMutex(paraMutex);
// 						return;					
// 					}
// 				}
				
				PARAM *curParam =(PARAM*)&recvbuffer[i*BLOCK_SIZE];
				for( j= 0;  j < PARAM_SUM_EACH_PACKAGE; j++, curParam ++)
				{
				   if ((curParam->ArriveTime.Time1 == 0) && (curParam->ArriveTime.Time2 == 0))
					   break;
				   //curSysTime = *(ULONGLONG*)(&curParam->ArriveTime) & PARAM_TIME_MASK;		//zch_2011_12_24 �κβ���֡�����µ�ǰʱ��
				   FRAME_FLAG *pFrmFlag = (FRAME_FLAG *)curParam;
				   if ((curParam->ChNo & 0xE000) == STATE_FLAG)
				   {
					   //״̬֡
					   STPARAM_TYPE_0 *tempStParam = (STPARAM_TYPE_0 *)curParam;
					   DWORD cardno = pFrmFlag->spec.card;
					   ChStreamingState[cardno * CHANNEL_NUMBER_PERCARD + 1] = tempStParam->Ch0_State;
					   ChStreamingState[cardno * CHANNEL_NUMBER_PERCARD ] = tempStParam->Ch1_State;
				   }
				   else if ((curParam->ChNo & 0xE000) == SYSTIME_FLAG)
				   {
					   //ʱ��֡
					   if (!bChEnabled[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1])
					   {
						   continue;
                       }
					   unsigned __int64 xtime = (((unsigned __int64)curParam->ArriveTime.Time2) << 32) + curParam->ArriveTime.Time1;
					   if( xtime < m_ullLastSystime)
					   {
						   //����ʱ���С��ʱ��֡
					   }else
					   {
						   m_ullLastSystime = xtime;
						   
					   }
					   chParamFIFO[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1].pushsingle(curParam);
				
					   
                           /****************************����ת����**********************************/
                           if (!bHardParam)
                           {
                               int k, m;
                               ULONGLONG tmptm = 100 * chParamFIFO[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD + 1].GetSysTime();
                               for (k = 0; k < MAX_CARDNUM * CHANNEL_NUMBER_PERCARD; k++)
                               {
                                   if (bParamEn[k])
                                   {
                                       WaitForSingleObject(hWaveToHitSemaph, INFINITE);
                                       I32 prm_num = WaveToHitFlushIfTimeout(WthMdl, k, tmptm);
                                       if (prm_num > 0)
                                       {
                                           prm_num = WaveToHitGetParam(WthMdl, prm_num, (I8*)paraBuf);
                                           for (m = 0; m < prm_num; m++)
                                           {
                                               chParamFIFO[k].pushsingle(&paraBuf[m]);
                                           }
                                       }
                                       ReleaseSemaphore(hWaveToHitSemaph, 1, NULL);
                                   }
                               }
                           }
                           /************************************************************************/

					   }
				   else if ((curParam->ChNo & 0xE000) == EXPARA_FLAG)
				   {
					   //���֡
					   DWORD cardno = pFrmFlag->spec.card;
					   if (cardno > 0)
					   {
						   continue;
					   }
					   exParamBuf[cardno * 4    ] = curParam->exparam[0];
					   exParamBuf[cardno * 4 + 1] = curParam->exparam[1];
					   exParamBuf[cardno * 4 + 2] = curParam->exparam[2];
					   exParamBuf[cardno * 4 + 3] = curParam->exparam[3];
					   memset(&curParam->MaxAmp, 0, sizeof(PARAM) - sizeof(TIME) - sizeof(unsigned short));
					   memcpy(curParam->exparam, exParamBuf, sizeof(short) * 12);
					   if (!bChEnabled[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD])
					   {
						   continue;
                       }
					   chParamFIFO[MAX_CARDNUM*CHANNEL_NUMBER_PERCARD].pushsingle(curParam);
				   }
				   else
				   {
					   //��ͨ����֡
					   DWORD chno = pFrmFlag->spec.card * CHANNEL_NUMBER_PERCARD + pFrmFlag->spec.ChOfCard;
					   if (chno >= MAX_CARDNUM*CHANNEL_NUMBER_PERCARD)
					   {
						   continue;
                       }
					   if (exParamEn)
					   {
						   if (fftEn)
						   {
							   memcpy(curParam->exparam, exParamBuf, sizeof(short) * 5);
						   }
						   else
						   {
							   memcpy(curParam->exparam, exParamBuf, sizeof(short) * 12);
						   }
					   }
					   if (!bChEnabled[chno])
                       {
							continue;
                       }
					   chParamFIFO[chno].pushsingle(curParam);
				   }					   
				}
				i++; 
			    ReleaseMutex(paraMutex);
            }
		break;
        }
	}
}

/*++
����:
	д�Ĵ���������д�Ĵ���ÿ�η���33�ֽ����ݣ���һ�ֽ�ΪUSB�������ͣ��ڶ��ֽ�ΪFPGA�������ͣ������ֽ�Ϊ�Ĵ�����ַ
	����ͷΪ 0A 01 XX [DATA]
����:
	__in  CardId - ����
	__in  addr   - �Ĵ�����ַ
	__in  value  - ��д��Ĵ�����ֵ
����ֵ:
	VOID
--*/
void UsbaeHardware16BitNew::WriteRegister(short CardId,UCHAR addr, UINT value)
{
	UCHAR bufOutput[33];

	memset(&bufOutput,0,sizeof(bufOutput));
	bufOutput[0] = 10 ;					// USB��������
	bufOutput[1]  = 1;					// FPGA��������
	bufOutput[2]  = addr;		        // �Ĵ�����ַ
	
	char *valuebuf =(char*)&value;
    
	bufOutput[3] = valuebuf[3];
	bufOutput[4] = valuebuf[2];
	bufOutput[5] = valuebuf[1];
	bufOutput[6] = valuebuf[0];

    USBWriteEP(CardId,0,33,bufOutput);	
}

/*++
����:
	���Ĵ������������Ĵ����ȷ���10�ֽڵĶ�������յ�4�ֽڵĵ�����
	��дָ�� 0D 02 XX [DATA]
	  ��ָ�� [DATA]
����:
	__in  CardId - ����
	__in  addr   - �Ĵ�����ַ
	__out value  - ����ָ�룬��ȡ���Ĵ�����ֵ
����ֵ:
	VOID
--*/
void UsbaeHardware16BitNew::ReadRegister(short CardId,UCHAR addr, UINT *value)
{
    
    UCHAR bufOutput[33];

	memset(&bufOutput,0,sizeof(bufOutput));	
	
	bufOutput[0] = 13;
	bufOutput[1] = 2;
	bufOutput[2] = addr;

    USBWriteEP(CardId,0,10,bufOutput);
	memset(&bufOutput,0,sizeof(bufOutput));	
	USBReadEP(CardId,2,4,bufOutput);

    *value = *(UINT *)&bufOutput[0];
}

//�������еĵ���ʽ�忨
int UsbaeHardware16BitNew::FindAllSinglePointCard(BOOL *bDeviceFlag)
{
	return 0;
}

//���ͨ�������ɼ�״̬������ֵ��16λ��ʾCH0��ʧ����������16λ��ʾCH1��ʧ������
BOOL UsbaeHardware16BitNew::GetCardStreamingState(DWORD CardNo, unsigned long *states)
{
    *states = ( unsigned long)ChStreamingState[CardNo * CHANNEL_NUMBER_PERCARD    ] + 
			  ((unsigned long)ChStreamingState[CardNo * CHANNEL_NUMBER_PERCARD + 1] << 16);
	return TRUE;
}

//�������
//DWORD ChNo  -- ͨ����
//DWORD mode  -- ����ģʽ
int UsbaeHardware16BitNew::OutputChAlarm(DWORD ChNo, DWORD mode)
{
    unsigned short CardNo;
    unsigned char addr;
    
    CardNo = ChNo / CHANNEL_NUMBER_PERCARD;
    //ChNo = ChNo % CHANNEL_NUMBER_PERCARD;
    
    if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
    {
        return -1;
    }

    GLB_ALARM_CMD RegVal;
    RegVal.cmd = 0;
    RegVal.spec.CmdVld = 1;
    if (mode & enuAlarmBuzzer)
    {
        RegVal.spec.EnableBuzzer = 1;
    }
    if (mode & enuAlarmLight)
    {
        RegVal.spec.EnableLight = 1;
    }
    if (mode & enuAlarmRelay)
    {
        RegVal.spec.EnableRelay = 1;
    }
    
    WriteRegister(CardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_ALARM_REG, RegVal.cmd);

    return 0;
}

//ֹͣ�������
int UsbaeHardware16BitNew::StopChAlarm(DWORD ChNo)
{
    unsigned short CardNo;
    
    CardNo = ChNo / CHANNEL_NUMBER_PERCARD;
    
    if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
    {
        return -1;
    }
    
    GLB_ALARM_CMD RegVal;
    RegVal.cmd = 0;
    RegVal.spec.CmdVld = 1;
    RegVal.spec.ResetAlarm = 1;

    WriteRegister(CardNo, CMD_GLB_REG_BASEADDR + CMD_GLB_ALARM_REG, RegVal.cmd);
    
    return 0;
}

//���ñ���ʧЧʱ��
//DWORD CardNo  -- ����
//DWORD ms      -- ����ʱ�䣬��λms
int UsbaeHardware16BitNew::SetCardAlarmTimeout(DWORD CardNo, DWORD ms)
{  
    if(CardNo >= MAX_CARDNUM || bDeviceOpenFlag[CardNo] == FALSE)
    {
        return -1;
    }
    
    GLB_ALARM_TIMEOUT_PROP RegVal;
    RegVal.cmd = 0;
    RegVal.spec.timeout = ms;
    
    WriteRegister(CardNo, PROP_GLB_REG_BASEADDR + PROP_GLB_ALARM_TIMEOUT_REG, RegVal.cmd);
    
    return 0;
}

//�������̼��汾��
BOOL UsbaeHardware16BitNew::GetMbFwVersion(short ChassisId, UINT *val)
{
	return FALSE;
}

//����ӿ��̼��汾��
BOOL UsbaeHardware16BitNew::GetAECardFwVersion(short CardId, UINT *val)
{
#ifdef SINGLE_POINT_BUS_INTERFACE
// 	*val = 0;
// 	ReadRegister(CardId, AE_VERSION_REG, val);
	*val = card_ver[CardId];

	if (*val == 0)
	{
		return FALSE;
	}

	return true;
#else
//	*val = bHardParam;
	if(CardId >= MAX_CARDNUM)
		return FALSE;

	if (bHardParam)
	{
		*val = card_ver[CardId] | HARD_HIT_FLAG;
	}
	else
	{
		*val = card_ver[CardId];
	}

	return TRUE;
#endif
}

//���ָ���忨�Ĵ���ͳ������
BOOL UsbaeHardware16BitNew::GetTransmitStatisticData(unsigned short CardNo, unsigned __int64 val[4])
{
    return FALSE;
}


//���ָ���忨�Ĵ���ͳ������
BOOL UsbaeHardware16BitNew::ClearTransmitStatisticData(unsigned short CardNo)
{
    return FALSE;
}

//input[10] -- ������Ϣ
//pStrBuf -- �����Ϣ���ַ���buffer
//bufSize -- �����Ϣbuffer�ĳ��ȣ���λ���ֽ�
void UsbaeHardware16BitNew::GetOutputInfo(UINT input[10], PCHAR pStrBuf, int bufSize)
{
    memset(pStrBuf, 0, bufSize);

    //����
    UINT val = 0;
    
    ReadRegister(0, 0, &val);

    //�����Ϣ�ַ������ȱ���С��bufSize
    sprintf(pStrBuf, "%x \n", val);
}

//input[10] -- ������Ϣ
//����ֵ    -- �ַ�����Ϣͷָ�룬ʹ������Ҫ�ⲿ�ͷ��ַ���ռ�õ��ڴ�
char * UsbaeHardware16BitNew::GetOutputInfo(UINT input[10])
{
    PCHAR pStrBuf;
    int bufSize;

    bufSize = 1024 * 4;

    pStrBuf = (char*)GlobalAlloc(GPTR, bufSize);

    memset(pStrBuf, 0, bufSize);

    //����
    UINT val = 0;
    
    ReadRegister(0, 0, &val);

    //�����Ϣ�ַ������ȱ���С��bufSize
    sprintf(pStrBuf, "%x \n", val);

    return pStrBuf;
}

//��StartSample����֮ǰ����
void UsbaeHardware16BitNew::ConfigureBeforeStart()
{
    
}

//��StartSample����֮�����
void UsbaeHardware16BitNew::ConfigureAfterStart()
{
}

/*++
����:
	DPCM���α���ת��������DPCM���뷽ʽ�Ĳ�������ת������������Ĳ�������
����:
	__out des     - Ŀ�����ݻ�������ַ
	__in  src     - ԭ���ݻ�������ַ
	__in  frm_num - ��Ҫת�������ݳ���
����ֵ:
	VOID
--*/
void UsbaeHardware16BitNew::DpcmWaveConvert(char* des, char* src, DWORD frm_num)
{

}

/*++
����:
	PCM16λ��������ת��
����:
	__out des     - Ŀ���������ַ
	__in  src     - ԭʼ���ݻ����ַ
	__in  frm_num - ��ת����֡��
����ֵ:
	VOID
--*/
void UsbaeHardware16BitNew::Pcm16bitWaveConvert(char* des, char* src, DWORD frm_num)
{
    if ((FrmVer[0] != 0) || ((FrmEncodeType[0] != en16BitsPcm) && (FrmEncodeType[0] != en18BitsPcm)))
    {
        return;
    }

    int i, k;

    int *pData;
    short *pDpcm;


    for (i = 0; i < frm_num; i++)
    {
        memcpy(&des[i * singleChannelBufLen], &src[i * singleChannelRawDataLen], 8);

        pData = (int*)&des[i * singleChannelBufLen + 8];
        pDpcm = (short*)&src[i * singleChannelRawDataLen + 8];
        
        for (k = 0; k < SampleLen; k++)
        {
			if (FrmEncodeType[0] == en16BitsPcm)
				pData[k] = (int)pDpcm[k];
			else if(FrmEncodeType[0] == en18BitsPcm)
				pData[k] = ((int)(pDpcm[k] & 0xFFF8) << 16) >> (19 - (pDpcm[k] & 0x0007)) >> 2;//18λת��16λֵ
        }
    }
}

/*++
����:
	���ð忨ͨ�Ż������������汾�š�֡�汾�š�֡���뷽ʽ�Լ�DPCM����λ��
����:
	__in  CardNo     - ����
	__in  PackingVer - ���汾
	__in  FramingVer - ֡�汾
	__in  encoding   - ֡���뷽ʽ
	__in  bits       - DPCM����λ��
����ֵ:
	VOID
--*/
void UsbaeHardware16BitNew::SetEncoding(unsigned short CardNo, DWORD PackingVer, DWORD FramingVer, DWORD encoding, DWORD bits)
{
    if (CardNo >= MAX_CARDNUM)
    {
        return;
    }

    PackVer[CardNo] = PackingVer;
    FrmVer[CardNo] = FramingVer;
    FrmEncodeType[CardNo] = encoding;
    FrmDpcmBits[CardNo] = bits;
}

//��ò���ת����ģ�����
PWAVETOHIT_STRUCT UsbaeHardware16BitNew::GetWaveToHitEntry()
{
    return WthMdl;
}
