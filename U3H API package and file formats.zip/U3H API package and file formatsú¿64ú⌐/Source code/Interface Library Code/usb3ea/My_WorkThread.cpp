// WLan_DataMonitor_Thread.cpp : implementation file
//

#include "My_WorkThread.h"
#include "process.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


unsigned __stdcall CMy_WorkThread::ThreadStaticEntryPoint(void* pParam)  
{ 
	_MY_THREAD_STARTUP* pStartup = (_MY_THREAD_STARTUP*)pParam;
	if(pStartup == NULL) return 1;	
	if(pStartup->pThread == NULL) return 1;
	if(pStartup->hEvent == NULL) return 1;

	CMy_WorkThread* pThread = (CMy_WorkThread*)pStartup->pThread;

		// pStartup is invlaid after the following
		// SetEvent (but hEvent2 is valid)
	HANDLE hEvent2 = pStartup->hEvent2;

	// allow the creating thread to return from CWinThread::CreateThread
	::SetEvent(pStartup->hEvent);

	// wait for thread to be resumed
	::WaitForSingleObject(hEvent2, INFINITE);
	::CloseHandle(hEvent2);

	// first -- check for simple worker thread
	DWORD nResult = 0;

	pThread->InitInstance();
    nResult = pThread->ExitInstance();
	::SetEvent(pThread->m_hEventDead);
	// cleanup and shutdown the thread
	_endthreadex(nResult);
	
	return 0;   // not reached
}  


// CMy_WorkThread


CMy_WorkThread::CMy_WorkThread()
{
	//m_bAutoDelete = FALSE;
	m_hEventKill = CreateEvent(NULL, TRUE, FALSE, NULL);
	m_hEventDead = CreateEvent(NULL, TRUE, FALSE, NULL);
	m_nThreadID = 0;
}

CMy_WorkThread::~CMy_WorkThread()
{
	CloseHandle(m_hEventKill);
	CloseHandle(m_hEventDead);
}

BOOL CMy_WorkThread::InitInstance()
{
	// thread setup

	// loop but check for kill notification
	while (WaitForSingleObject(m_hEventKill, 0) == WAIT_TIMEOUT)
		DoWork();

	// thread cleanup


	// avoid entering standard message loop by returning FALSE
	return FALSE;

}

int CMy_WorkThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return 0;
}



// CMy_WorkThread message handlers


void CMy_WorkThread::KillThread( BOOL bDelete /*= TRUE */)
{
	// Note: this function is called in the context of other threads,
	//  not the thread itself.

	// reset the m_hEventKill which signals the thread to shutdown
	SetEvent(m_hEventKill);

	// allow thread to run at higher priority during kill process
	if( m_hThread )
	{
		SetThreadPriority(m_hThread, THREAD_PRIORITY_ABOVE_NORMAL);
		WaitForSingleObject(m_hEventDead, INFINITE);
		WaitForSingleObject(m_hThread, INFINITE);
	}


	// now delete CWinThread object since no longer necessary
	if( bDelete )
		delete this;
}

void CMy_WorkThread::Delete()
{
	// calling the base here won't do anything but it is a good habit
	

	// acknowledge receipt of kill notification
	SetEvent(m_hEventDead);	
}

void CMy_WorkThread::DoWork()
{
	Sleep(100000000);
}

DWORD CMy_WorkThread::SuspendThread()
{
	if( m_hThread )
		return ::SuspendThread(m_hThread);
	return 	(DWORD)-1;

}

DWORD CMy_WorkThread::ResumeThread()
{
	if( m_hThread )
		return ::ResumeThread(m_hThread);
	return 	(DWORD)-1;
}


BOOL CMy_WorkThread::CreateThread(DWORD dwCreateFlags, UINT nStackSize,
	LPSECURITY_ATTRIBUTES lpSecurityAttrs)
{

	// setup startup structure for thread initialization
	_MY_THREAD_STARTUP startup; memset(&startup, 0, sizeof(startup));
	startup.pThread = this;
	startup.hEvent = ::CreateEvent(NULL, TRUE, FALSE, NULL);
	startup.hEvent2 = ::CreateEvent(NULL, TRUE, FALSE, NULL);
	startup.dwCreateFlags = dwCreateFlags;
	if (startup.hEvent == NULL || startup.hEvent2 == NULL)
	{
		if (startup.hEvent != NULL)
			::CloseHandle(startup.hEvent);
		if (startup.hEvent2 != NULL)
			::CloseHandle(startup.hEvent2);
		return FALSE;
	}

	// create the thread (it may or may not start to run)
	m_hThread = (HANDLE)(ULONG_PTR)_beginthreadex(lpSecurityAttrs, nStackSize,  
		&ThreadStaticEntryPoint, &startup, dwCreateFlags | CREATE_SUSPENDED, (UINT*)&m_nThreadID);
	if (m_hThread == NULL)
	{
		::CloseHandle(startup.hEvent);
		::CloseHandle(startup.hEvent2);
		return FALSE;
	}

	// start the thread just for MFC initialization
	if(ResumeThread() == (DWORD)-1)
		return FALSE;
	if(::WaitForSingleObject(startup.hEvent, INFINITE) != WAIT_OBJECT_0)
		return FALSE;
	::CloseHandle(startup.hEvent);

	// if created suspended, suspend it until resume thread wakes it up
	if (dwCreateFlags & CREATE_SUSPENDED)
		::SuspendThread(m_hThread);

	// if error during startup, shut things down
	if (startup.bError)
	{
		::WaitForSingleObject(m_hThread, INFINITE);
		::CloseHandle(m_hThread);
		m_hThread = NULL;
		::CloseHandle(startup.hEvent2);
		return FALSE;
	}

	// allow thread to continue, once resumed (it may already be resumed)
	::SetEvent(startup.hEvent2);
	return TRUE;

}